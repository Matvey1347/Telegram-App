Sensitive local review material. Do not commit or send automatically.
Only previously stored message URLs matching the workspace source and message ID are included. Null means unavailable or not verifiable. Links are not proof of reciprocal promotion.
Dev and holdout are separate; keep holdout blind until rules are frozen. The VP review hint is unvalidated and applies only to dev. Human review fields are blank.
JSONL preserves original text; CSV neutralizes spreadsheet formulas.
