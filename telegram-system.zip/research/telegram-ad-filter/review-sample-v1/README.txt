Local, sensitive review material. Do not commit or send automatically.
Frozen seed: lead-review-sample-v1. Heuristic labels are unvalidated suggestions, not ground truth. Human fields are blank.
Use review-dev for rule development. Keep review-holdout (test and source-holdout) blind during rule selection; review and evaluate it only after rules are frozen.
Allowed human labels: AD, VP_POSSIBLE, VP_CONFIRMED, ORGANIC, UNKNOWN. VP_CONFIRMED requires verifiable reciprocal posts and evidence references; otherwise use VP_POSSIBLE.
The JSONL contains the exact original text. CSV prefixes formula-like cells with an apostrophe for spreadsheet safety.
Review labels are not automatically imported into the separate labeling workflow; retain reviewer, reason and evidence for validation.
