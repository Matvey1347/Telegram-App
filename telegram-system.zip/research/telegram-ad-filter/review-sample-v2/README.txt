Sensitive local review material; do not commit or send automatically.
Development and test/source-holdout are separate; keep holdout blind until rules are frozen.
Heuristic labels and vp_review_hint are unvalidated hypotheses, not ground truth. The VP review hint is computed only for dev: a Telegram link plus a call to action can be a footer or self-promotion; it does not establish reciprocity or VP.
Human label, reason, evidence and reviewer are blank. Allowed labels: AD, VP_POSSIBLE, VP_CONFIRMED, ORGANIC, UNKNOWN. VP_CONFIRMED requires independently verifiable reciprocal posts.
JSONL preserves original text; CSV prefixes spreadsheet-formula cells with an apostrophe. Review records are not automatically imported into the labeling workflow.
