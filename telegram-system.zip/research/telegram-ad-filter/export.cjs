const { createHash } = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { config } = require(require.resolve('dotenv', { paths: [path.resolve('apps/api')] }));
const { Client } = require(require.resolve('pg', { paths: [path.resolve('apps/api')] }));
const out = path.resolve('research/telegram-ad-filter');
const sha = s => createHash('sha256').update(s).digest('hex');
const sourceInputs = [
  ['Психология · приватный канал 1', 'invite', 'rm0NjY-YY3E3ZTNi'],
  ['Психология · приватный канал 2', 'invite', 'EquNF29-blUxMjNi'],
  ['Психология · приватный канал 3', 'invite', 'zA1juHSKHxc0NmQy'],
  ['Психология · приватный канал 4', 'invite', 'IbPSMzbJ2pJjZWYy'],
  ['ИИ · приватный канал', 'invite', 'wsMYXTthzas5MDA6'],
  ['Психология · ce_znack', 'username', 'ce_znack'],
  ['Психология · beinprogress', 'username', 'beinprogress'],
  ['Психология · psychology_uk', 'username', 'psychology_uk'],
  ['Психология · WebPsychology', 'username', 'webpsychology'],
].map(([label, kind, value], i) => ({ label, id:`source-${String(i+1).padStart(2,'0')}`, category:i===4?'ai':'psychology', key:kind==='invite'?'telegram:invite:'+sha(JSON.stringify(value)):'telegram:username:'+value }));
function redact(text) {
  return text
    .replace(/(?:https?:\/\/)?(?:t\.me|telegram\.me)\/(?:\+|joinchat\/)[^\s<>"']+/giu, '[приватное приглашение скрыто]')
    .replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/giu, '[email скрыт]')
    .replace(/(?<![\p{L}\p{N}_])@[\p{L}\p{N}_]{4,}/gu, '[контакт скрыт]')
    .replace(/(?<![\p{L}\p{N}])\+?\d[\d\s().-]{7,}\d(?![\p{L}\p{N}])/gu, '[номер скрыт]')
    .replace(/\b(?:sk|rk|pk)-(?:proj-)?[A-Za-z0-9_-]{16,}\b/g, '[ключ скрыт]')
    .replace(/https?:\/\/[^\s<>"']+/giu, raw => {
      try { const u = new URL(raw); if (u.username || u.password || !/^https?:$/.test(u.protocol)) return '[ссылка скрыта]'; return u.origin + '/[путь скрыт]'; }
      catch { return '[ссылка скрыта]'; }
    });
}
function linkData(values) {
  return (Array.isArray(values)?values:[]).flatMap(raw=>{
    if(typeof raw!=='string') return [];
    try { const u=new URL(raw); if(!/^https?:$/.test(u.protocol)||u.username||u.password) return [];
      const domain=u.hostname.toLowerCase(); if(!domain || /^\d+(?:\.\d+){3}$/.test(domain)) return [];
      const telegram=['t.me','telegram.me','www.t.me'].includes(domain);
      if(telegram && /^\/(?:\+|joinchat\/)/i.test(u.pathname)) return [];
      return [{type:telegram?'TELEGRAM':/(^|\.)instagram\.com$/.test(domain)?'INSTAGRAM':'WEBSITE',domain}];
    } catch { return []; }
  });
}
async function main() {
  config({path:'.env',quiet:true});
  const grants=JSON.parse(process.env.INTERNAL_LEAD_DISCOVERY_GRANTS||'[]');
  const client=new Client({connectionString:process.env.DATABASE_URL,connectionTimeoutMillis:12000});
  const wid='cmptsyujx0001flritxdrq84b', start=Date.now(); let queries=0; const records=[]; const sourceReport=[];
  await client.connect();
  try {
    await client.query('BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY');
    const selected=await client.query('SELECT id,"title","normalizedKey","workspaceId","accountId","channelId","processingReference","allowOwnChannel","monitoringState" FROM "TelegramLeadSource" WHERE "workspaceId"=$1 AND "normalizedKey"=ANY($2::text[])',[wid,sourceInputs.map(x=>x.key)]); queries++;
    for(const spec of sourceInputs) {
      const s=selected.rows.find(x=>x.normalizedKey===spec.key); let n=0, pages=0;
      if(!s) {sourceReport.push({sourceId:spec.id,channel:spec.label,exported:0,reason:'SOURCE_NOT_FOUND'}); continue;}
      spec.label = redact(s.title || spec.label) + (spec.category === 'ai' ? ' · ИИ' : '');
      const granted=grants.some(g=>g.workspaceId===wid && g.sourceKey===s.normalizedKey && g.accountId===s.accountId && g.channelId===s.channelId && g.reference===s.processingReference && g.ingest===true && (!s.allowOwnChannel||g.allowOwnChannel===true) && Number.isFinite(Date.parse(g.expiresAt)) && Date.parse(g.expiresAt)>Date.now());
      if(!granted || ['DISABLED','ACCESS_LOST'].includes(s.monitoringState)) {sourceReport.push({sourceId:spec.id,channel:spec.label,exported:0,reason:'SOURCE_GRANT_OR_ACCESS_UNAVAILABLE'});continue;}
      let beforeTime=null,beforeId=null;
      while(n<300) {
        const q=await client.query(`SELECT id,"publishedAt","editedAt",text,links,classification FROM "TelegramLeadObservation" WHERE "workspaceId"=$1 AND "sourceId"=$2 AND "publishedAt">=NOW()-interval '90 days' AND "publishedAt"<=NOW() AND "expiresAt">NOW() AND "originalStatus"='OBSERVED' AND ($3::timestamp IS NULL OR ("publishedAt",id)<($3::timestamp,$4::text)) ORDER BY "publishedAt" DESC,id DESC LIMIT $5`,[wid,s.id,beforeTime,beforeId,Math.min(100,300-n)]);queries++;pages++;
        for(const row of q.rows) {
          const text=redact(row.text||''); const cls=row.classification?.classification;
          records.push({id:'post-'+sha(wid+':'+s.id+':'+row.id).slice(0,24),sourceId:spec.id,channel:spec.label,sourceCategory:spec.category,publishedAt:row.publishedAt.toISOString(),text,textLength:[...text].length,links:linkData(row.links),hasMedia:null,mediaType:null,hasForwardMetadata:null,isEdited:!!row.editedAt,existingAiClassification:['ADVERTISEMENT','MUTUAL_PROMOTION','ORGANIC_CONTENT','UNKNOWN'].includes(cls)?cls:null,manualLabel:null}); n++;
        }
        if(q.rows.length<100 || n>=300) break;const last=q.rows.at(-1);beforeTime=last.publishedAt;beforeId=last.id;
      }
      if(n===300) throw Error('SOURCE_REQUIRES_REPRESENTATIVE_SAMPLING');
      sourceReport.push({sourceId:spec.id,channel:spec.label,exported:n,pages,coverage:'UNPROVEN',belowRequested300:n<300});
    }
    await client.query('ROLLBACK');
  } finally { await client.end(); }
  records.sort((a,b)=>a.sourceId.localeCompare(b.sourceId)||a.publishedAt.localeCompare(b.publishedAt)||a.id.localeCompare(b.id));
  if(new Set(records.map(x=>x.id)).size!==records.length) throw Error('DUPLICATE_RECORD_ID');
  const bytes=Buffer.from(records.map(x=>JSON.stringify(x)).join('\n')+(records.length?'\n':''));
  const csv='id,AD,MUTUAL,ORGANIC,UNKNOWN,notes\n'+records.map(x=>`${x.id},,,,,`).join('\n')+(records.length?'\n':'');
  const lengths=records.map(x=>x.textLength).sort((a,b)=>a-b), dates=records.map(x=>x.publishedAt).sort(); const share=n=>records.length?n/records.length:null;
  const countType=type=>records.filter(x=>x.links.some(l=>l.type===type)).length;
  const summary={status:'local_export_requires_manual_privacy_review',sources:sourceReport.filter(x=>x.exported).length,exportedPosts:records.length,postsPerSource:Object.fromEntries(sourceReport.map(x=>[x.sourceId,x.exported])),minPublishedAt:dates[0]||null,maxPublishedAt:dates.at(-1)||null,withLinksShare:share(records.filter(x=>x.links.length).length),withoutLinksShare:share(records.filter(x=>!x.links.length).length),telegramLinks:countType('TELEGRAM'),externalWebsiteLinks:countType('WEBSITE'),instagramLinks:countType('INSTAGRAM'),meanTextLength:lengths.length?lengths.reduce((a,b)=>a+b,0)/lengths.length:null,medianTextLength:lengths.length?(lengths[Math.floor((lengths.length-1)/2)]+lengths[Math.floor(lengths.length/2)])/2:null,forwardedShare:null,mediaShare:null,editedShare:share(records.filter(x=>x.isEdited).length),existingAiLabels:records.reduce((a,x)=>{if(x.existingAiClassification)a[x.existingAiClassification]=(a[x.existingAiClassification]||0)+1;return a},{}),coverageGaps:['Source coverage is unproven; all saved eligible observations up to 300 per source were read.','Media and forwarding metadata are not stored in the observation model.'],externalTransferAuthorization:'User selected sources; manual privacy review required before transfer.',datasetBytes:bytes.length,peakMemoryBytes:process.memoryUsage().rss,dbReadQueries:queries,telegramCalls:0,aiCalls:0,databaseWrites:0};
  const report={status:summary.status,periodDays:90,sources:sourceReport,exportedPosts:records.length,actualPeriod:{from:summary.minPublishedAt,to:summary.maxPublishedAt},selection:'All eligible saved observations per source, capped defensively; the exporter refuses to sample a source reaching 300. Coverage is not proven.',samplingSeed:null,elapsedMs:Date.now()-start};
  for(const [name,value] of [['dataset.jsonl',bytes],['labeling.csv',csv],['summary.json',JSON.stringify(summary,null,2)+'\n'],['export-report.json',JSON.stringify(report,null,2)+'\n']]) {const temp=path.join(out,name+'.tmp');fs.writeFileSync(temp,value,{mode:0o600});fs.renameSync(temp,path.join(out,name));}
  console.log(JSON.stringify({exportedPosts:records.length,sources:summary.sources,bytes:bytes.length,dbReadQueries:queries,from:summary.minPublishedAt,to:summary.maxPublishedAt,bySource:sourceReport.map(s=>({sourceId:s.sourceId,exported:s.exported,reason:s.reason}))}));
}
if(require.main===module) main().catch(e=>{console.error('Export failed:',e.code||e.name);process.exitCode=1});
module.exports={redact,linkData};
