import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  FinanceExpenseNecessity,
  FinanceTransactionPurpose,
  FinanceTransactionSource,
  Prisma,
} from '@prisma/client';
import { PrismaService } from '@api/prisma/prisma.service';
import { CurrencyConversionService } from '@api/common/currency-conversion.service';
import { FINANCE_UNDO_TTL_MS } from '@consumer-finance/api/catalog/finance-defaults';
import { financeAccountView } from '@consumer-finance/api/catalog/finance-account-view';
import {
  financeHistoryDateRange,
  financeOccurredAtFilter,
} from '@consumer-finance/api/ledger/finance-history-date-range';
import { FinanceAnalyticsService } from '@consumer-finance/api/analytics/finance-analytics.service';
import {
  financeTransactionSearchFilter,
  financeTransactionSelect,
  financeTransactionView,
} from '@consumer-finance/api/ledger/finance-transaction-view';
import type {
  CreateFinanceTransactionDto,
  FinanceHistoryQueryDto,
  UpdateFinanceTransactionDto,
} from '@consumer-finance/api/http/finance.dto';
import {
  financeAccountEmoji,
  financeIconPresentation,
} from '@consumer-finance/api/catalog/finance-entity-emoji';
import {
  financeDefaultCurrencySnapshot,
  financeValuationSnapshot,
  prepareFinanceAccountRates,
  prepareFinanceTransactionRates,
  prepareFinanceTransactionWriteContext,
  type FinanceProfileContext,
  type FinanceTransactionRateSource,
  type FinanceTransactionWriteContext,
} from '@consumer-finance/api/ledger/finance-transaction-valuation';
import {
  normalizeFinanceMerchant,
  writeFinanceMerchantMapping,
} from '@consumer-finance/api/ledger/finance-merchant-mapping';
import {
  assertFinanceTransactionMutable,
  assertFinanceTransactionRemoved,
} from '@consumer-finance/api/ledger/finance-generated-transaction-policy';
import {
  findLinkedInvestmentTransaction,
  lockLinkedInvestment,
  removeLinkedInvestmentTransaction,
  refreshLinkedInvestmentTransaction,
  syncLinkedInvestmentEdit,
} from '@consumer-finance/api/ledger/finance-investment-transaction-mutation';
import { FinanceAssetSummaryService } from '@consumer-finance/api/assets/finance-asset-summary.service';
import { financeLedgerStats } from '@consumer-finance/api/ledger/finance-ledger-stats';
import { prepareFinanceDebtOriginReplacement, type FinanceDebtOriginSyncInput } from '@consumer-finance/api/ledger/finance-debt-origin-sync';
import { assertFinancePurposeDirection } from '@consumer-finance/api/ledger/finance-transaction-purpose';
@Injectable()
export class FinanceLedgerService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly conversion?: CurrencyConversionService,
    private readonly analyticsService?: FinanceAnalyticsService,
    private readonly assets?: FinanceAssetSummaryService,
  ) {}
  async profileContext(profileId: string): Promise<FinanceProfileContext> {
    const profile = await this.prisma.financeProfile.findUnique({
      where: { id: profileId },
      select: {
        id: true,
        defaultCurrency: true,
        timezone: true,
        botIntegration: { select: { workspaceId: true } },
      },
    });
    if (!profile) throw new NotFoundException('Finance profile not found');
    return {
      id: profile.id,
      defaultCurrency: profile.defaultCurrency,
      timezone: profile.timezone,
      workspaceId: profile.botIntegration.workspaceId,
    };
  }
  async accounts(
    profileId: string,
    profileCurrency?: string,
    workspaceId?: string,
  ) {
    const [accounts, transactions, outgoing, incoming, missingContext] =
      await Promise.all([
        this.prisma.financeAccount.findMany({
          where: { profileId },
          select: {
            id: true,
            name: true,
            emoji: true,
            type: true,
            currency: true,
            openingBalance: true,
            archivedAt: true,
          },
          orderBy: [{ archivedAt: 'asc' }, { createdAt: 'asc' }],
        }),
        this.prisma.financeTransaction.groupBy({
          by: ['accountId', 'type'],
          where: { profileId, deletedAt: null },
          _sum: { amount: true },
        }),
        this.prisma.financeTransfer.groupBy({
          by: ['fromAccountId'],
          where: { profileId, deletedAt: null },
          _sum: { fromAmount: true },
        }),
        this.prisma.financeTransfer.groupBy({
          by: ['toAccountId'],
          where: { profileId, deletedAt: null },
          _sum: { toAmount: true },
        }),
        !profileCurrency || !workspaceId
          ? this.prisma.financeProfile.findUnique({
              where: { id: profileId },
              select: {
                defaultCurrency: true,
                botIntegration: { select: { workspaceId: true } },
              },
            })
          : Promise.resolve(null),
      ]);
    const defaultCurrency =
      profileCurrency || missingContext?.defaultCurrency || 'USD';
    const resolvedWorkspaceId =
      workspaceId || missingContext?.botIntegration.workspaceId;
    const equivalents = await prepareFinanceAccountRates({
      conversion: this.conversion,
      workspaceId: resolvedWorkspaceId,
      currencies: accounts.map((account) => account.currency),
      defaultCurrency,
    });
    const transactionDelta = new Map<string, Prisma.Decimal>();
    for (const row of transactions) {
      const amount = row._sum.amount || new Prisma.Decimal(0);
      const previous = transactionDelta.get(row.accountId) || new Prisma.Decimal(0);
      transactionDelta.set(
        row.accountId,
        row.type === 'INCOME' ? previous.plus(amount) : previous.minus(amount),
      );
    }
    const outgoingByAccount = new Map(outgoing.map((row) => [row.fromAccountId, row._sum.fromAmount]));
    const incomingByAccount = new Map(incoming.map((row) => [row.toAccountId, row._sum.toAmount]));
    return accounts.map((account) => {
      const balance = new Prisma.Decimal(account.openingBalance)
        .plus(transactionDelta.get(account.id) || 0)
        .minus(outgoingByAccount.get(account.id) || 0)
        .plus(incomingByAccount.get(account.id) || 0);
      return {
        id: account.id,
        name: account.name,
        iconPresentation: financeIconPresentation(
          account.emoji,
          financeAccountEmoji(account.type),
        ),
        type: account.type,
        currency: account.currency,
        openingBalance: account.openingBalance.toString(),
        balance: balance.toString(),
        defaultCurrency,
        equivalentBalance:
          account.currency === defaultCurrency
            ? null
            : (() => {
                const result = equivalents.get(account.currency);
                return result?.available
                  ? {
                      amount: balance
                        .mul(result.rate)
                        .toDecimalPlaces(2)
                        .toString(),
                      currency: defaultCurrency,
                      rate: String(result.rate),
                      rateAsOf: result.rateAt.toISOString(),
                    }
                  : null;
              })(),
        archivedAt: account.archivedAt,
      };
    });
  }
  async account(profileId: string, accountId: string) {
    return financeAccountView(
      this.prisma,
      this.conversion,
      profileId,
      accountId,
    );
  }

  prepareTransactionRateSource(
    profile: FinanceProfileContext,
    operations: Array<{ currency: string; occurredAt: string }>,
  ) {
    return prepareFinanceTransactionRates({
      profile,
      operations,
      conversion: this.conversion,
      resolveWorkspaceId: (profileId) => this.workspaceId(profileId),
    });
  }

  async prepareTransactionWriteContext(
    tx: Prisma.TransactionClient,
    profileId: string,
    operations: CreateFinanceTransactionDto[],
    rates: FinanceTransactionRateSource,
  ): Promise<FinanceTransactionWriteContext> {
    return prepareFinanceTransactionWriteContext({
      tx,
      profileId,
      operations,
      rates,
    });
  }

  async createTransaction(
    profile: FinanceProfileContext,
    dto: CreateFinanceTransactionDto,
    source: FinanceTransactionSource = 'MINI_APP',
    id?: string,
  ) {
    return this.prisma.$transaction((tx) =>
      this.createTransactionInTransaction(tx, profile, dto, source, id),
    );
  }

  async createTransactionInTransaction(
    tx: Prisma.TransactionClient,
    profile: FinanceProfileContext,
    dto: CreateFinanceTransactionDto,
    source: FinanceTransactionSource = 'MINI_APP',
    id?: string,
    writeContext?: FinanceTransactionWriteContext,
    options?: {
      suppressMerchantMapping?: boolean;
      purpose?: FinanceTransactionPurpose;
    },
  ) {
    const amount = this.positive(dto.amount, 'amount');
    const purpose = options?.purpose ?? dto.purpose ?? 'ORDINARY';
    const economicAmount = this.resolveEconomicAmount(
      amount,
      dto.economicAmount,
      purpose,
    );
    assertFinancePurposeDirection(purpose, dto.type, dto.categoryId);
    const account = writeContext
      ? writeContext.accounts.get(dto.accountId)
      : await tx.financeAccount.findFirst({
          where: {
            id: dto.accountId,
            profileId: profile.id,
            archivedAt: null,
          },
        });
    if (!account) throw new NotFoundException('Finance account not found');
    const currency = account.currency;
    const category = dto.categoryId
      ? writeContext
        ? writeContext.categories.get(dto.categoryId)
        : await tx.financeCategory.findFirst({
            where: {
              id: dto.categoryId,
              profileId: profile.id,
              archivedAt: null,
            },
          })
      : null;
    if (dto.categoryId && !category)
      throw new NotFoundException('Finance category not found');
    if (category && category.type !== dto.type)
      throw new BadRequestException(
        'Category type does not match transaction type',
      );
    const necessity =
      dto.type === 'EXPENSE' && purpose === 'ORDINARY'
        ? (dto.necessity ??
          category?.necessity ??
          FinanceExpenseNecessity.UNSPECIFIED)
        : FinanceExpenseNecessity.UNSPECIFIED;
    const occurredAt = new Date(dto.occurredAt);
    const [valuation, defaultSnapshot] = await Promise.all([
      financeValuationSnapshot(
        profile,
        currency,
        occurredAt,
        this.rateDependencies(),
        writeContext?.rates,
      ),
      financeDefaultCurrencySnapshot(
        profile,
        currency,
        occurredAt,
        this.rateDependencies(),
        writeContext?.rates,
      ),
    ]);
    const description = dto.description?.trim() || null;
    const merchantDisplay = dto.merchantDisplay?.trim() || null;
    const items = await this.items(
      tx,
      profile.id,
      dto.type,
      dto.items,
      writeContext?.categories,
    );
    const created = await tx.financeTransaction.create({
      data: {
        ...(id ? { id } : {}),
        profileId: profile.id,
        accountId: account.id,
        categoryId: category?.id || null,
        type: dto.type,
        purpose,
        amount,
        economicAmount,
        currency,
        // These retain their original meaning: a snapshot in the profile's
        // default currency at write time. USD valuations live only below.
        exchangeRateToDefault: defaultSnapshot.rate,
        amountInDefaultCurrency: amount.mul(defaultSnapshot.rate),
        valuationCurrency: 'USD',
        amountInValuationCurrency: amount.mul(valuation.rate),
        economicAmountInValuationCurrency: economicAmount.mul(valuation.rate),
        exchangeRateToValuation: valuation.rate,
        valuationRateAt: valuation.rateAt,
        occurredAt,
        description,
        merchantDisplay,
        merchantNormalized:
          merchantDisplay || description
            ? this.normalizeMerchant(merchantDisplay || description || '')
            : null,
        source,
        necessity,
        items: items.length ? { create: items } : undefined,
      },
      select: financeTransactionSelect,
    });
    const merchantMappingKey = merchantDisplay || description;
    if (!options?.suppressMerchantMapping)
      await writeFinanceMerchantMapping(
        tx,
        profile.id,
        merchantMappingKey,
        category?.id || null,
      );
    return financeTransactionView(created);
  }

  async updateTransaction(
    profile: FinanceProfileContext,
    id: string,
    dto: UpdateFinanceTransactionDto,
  ) {
    return this.prisma.$transaction(async (tx) => {
      const existing = await tx.financeTransaction.findFirst({
        where: { id, profileId: profile.id, deletedAt: null },
        select: {
          id: true,
          accountId: true,
          categoryId: true,
          merchantDisplay: true,
          profileId: true,
          currency: true,
          occurredAt: true,
          type: true,
          amountInValuationCurrency: true,
          debtSettlement: { select: { id: true } },
          recurringPaymentOccurrence: { select: { id: true } },
          investmentCashFlow: {
            select: {
              id: true,
              investmentId: true,
              kind: true,
              amountInInvestmentCurrency: true,
              exchangeRateToInvestment: true,
            },
          },
          originatedDebts: { select: { id: true }, take: 1 },
        },
      });
      if (!existing)
        throw new NotFoundException('Finance transaction not found');
      if (!existing.investmentCashFlow) {
        assertFinanceTransactionMutable(existing);
        return this.createReplacement(tx, profile, existing, dto);
      }
      if (existing.debtSettlement || existing.recurringPaymentOccurrence || existing.originatedDebts.length)
        throw new BadRequestException('Transaction has other linked records');
      if (dto.type !== existing.type || dto.categoryId)
        throw new BadRequestException('Investment cash flow type and category cannot be changed');
      await lockLinkedInvestment(tx, profile.id, existing.investmentCashFlow.investmentId);
      const current = await refreshLinkedInvestmentTransaction(tx, existing);
      const updated = await this.createReplacement(
        tx,
        profile,
        current,
        dto,
        current.investmentCashFlow!.kind === 'CONTRIBUTION'
          ? FinanceTransactionPurpose.INVESTMENT_CONTRIBUTION
          : FinanceTransactionPurpose.INVESTMENT_RETURN,
      );
      await syncLinkedInvestmentEdit(tx, current, updated);
      return updated;
    });
  }

  async syncDebtOriginInTransaction(
    tx: Prisma.TransactionClient,
    profile: FinanceProfileContext,
    input: FinanceDebtOriginSyncInput,
  ) {
    const replacement = await prepareFinanceDebtOriginReplacement(tx, profile, input);
    if (!replacement) return;
    await this.createReplacement(tx, profile, replacement.origin, replacement.dto, replacement.purpose, true);
  }

  private async createReplacement(
    tx: Prisma.TransactionClient,
    profile: FinanceProfileContext,
    existing: {
      id: string;
      accountId: string;
      categoryId: string | null;
      merchantDisplay: string | null;
    },
    dto: UpdateFinanceTransactionDto,
    purposeOverride?: FinanceTransactionPurpose,
    suppressMerchantMapping = false,
  ) {
    const amount = this.positive(dto.amount, 'amount');
    const purpose = purposeOverride ?? dto.purpose ?? 'ORDINARY';
    const economicAmount = this.resolveEconomicAmount(
      amount,
      dto.economicAmount,
      purpose,
    );
    assertFinancePurposeDirection(purpose, dto.type, dto.categoryId);
    const account = await tx.financeAccount.findFirst({
      where: {
        id: dto.accountId,
        profileId: profile.id,
        ...(dto.accountId === existing.accountId ? {} : { archivedAt: null }),
      },
    });
    if (!account) throw new NotFoundException('Finance account not found');
    const currency = account.currency;
    const category = dto.categoryId
      ? await tx.financeCategory.findFirst({
          where: {
            id: dto.categoryId,
            profileId: profile.id,
            ...(dto.categoryId === existing.categoryId
              ? {}
              : { archivedAt: null }),
          },
        })
      : null;
    if (dto.categoryId && !category)
      throw new NotFoundException('Finance category not found');
    if (category && category.type !== dto.type)
      throw new BadRequestException(
        'Category type does not match transaction type',
      );
    const necessity =
      dto.type === 'EXPENSE' && purpose === 'ORDINARY'
        ? (dto.necessity ??
          category?.necessity ??
          FinanceExpenseNecessity.UNSPECIFIED)
        : FinanceExpenseNecessity.UNSPECIFIED;
    const occurredAt = new Date(dto.occurredAt);
    const [valuation, defaultSnapshot] = await Promise.all([
      financeValuationSnapshot(
        profile,
        currency,
        occurredAt,
        this.rateDependencies(),
      ),
      financeDefaultCurrencySnapshot(
        profile,
        currency,
        occurredAt,
        this.rateDependencies(),
      ),
    ]);
    const description = dto.description?.trim() || null;
    const merchantDisplay =
      dto.merchantDisplay === undefined
        ? existing.merchantDisplay
        : dto.merchantDisplay.trim() || null;
    const items =
      dto.items === undefined
        ? undefined
        : await this.items(tx, profile.id, dto.type, dto.items);
    const updated = await tx.financeTransaction.update({
      where: { id: existing.id },
      data: {
        accountId: account.id,
        categoryId: category?.id || null,
        type: dto.type,
        purpose,
        amount,
        economicAmount,
        currency,
        exchangeRateToDefault: defaultSnapshot.rate,
        amountInDefaultCurrency: amount.mul(defaultSnapshot.rate),
        valuationCurrency: 'USD',
        amountInValuationCurrency: amount.mul(valuation.rate),
        economicAmountInValuationCurrency: economicAmount.mul(valuation.rate),
        exchangeRateToValuation: valuation.rate,
        valuationRateAt: valuation.rateAt,
        necessity,
        occurredAt,
        description,
        merchantDisplay,
        merchantNormalized:
          merchantDisplay || description
            ? this.normalizeMerchant(merchantDisplay || description || '')
            : null,
        ...(items === undefined
          ? {}
          : {
              items: {
                deleteMany: {},
                ...(items.length ? { create: items } : {}),
              },
            }),
      },
      select: financeTransactionSelect,
    });
    const merchantMappingKey = merchantDisplay || description;
    if (!suppressMerchantMapping) await writeFinanceMerchantMapping(
      tx,
      profile.id,
      merchantMappingKey,
      category?.id || null,
    );
    return financeTransactionView(updated);
  }

  async removeTransaction(profileId: string, id: string) {
    const linked = await findLinkedInvestmentTransaction(this.prisma, profileId, id);
    if (linked?.investmentCashFlow)
      return this.prisma.$transaction((tx) =>
        removeLinkedInvestmentTransaction(tx, linked),
      );
    const result = await this.prisma.financeTransaction.updateMany({
      where: {
        id,
        profileId,
        deletedAt: null,
        debtSettlement: { is: null },
        recurringPaymentOccurrence: { is: null },
        investmentCashFlow: { is: null },
        originatedDebts: { none: {} },
      },
      data: { deletedAt: new Date() },
    });
    await assertFinanceTransactionRemoved(
      this.prisma,
      profileId,
      id,
      result.count,
    );
    return { deleted: true };
  }

  async undo(profileId: string, id: string) {
    const investment = await this.prisma.financeTransaction.findFirst({
      where: { id, profileId },
      select: { purpose: true },
    });
    if (investment?.purpose === FinanceTransactionPurpose.INVESTMENT_CONTRIBUTION ||
        investment?.purpose === FinanceTransactionPurpose.INVESTMENT_RETURN)
      throw new BadRequestException('Investment cash flows cannot be restored through transaction undo');
    const cutoff = new Date(Date.now() - FINANCE_UNDO_TTL_MS);
    const result = await this.prisma.financeTransaction.updateMany({
      where: { id, profileId, deletedAt: { gte: cutoff } },
      data: { deletedAt: null },
    });
    const restored = await this.prisma.financeTransaction.findFirst({
      where: { id, profileId },
      select: financeTransactionSelect,
    });
    if (result.count && restored)
      return {
        undone: true,
        duplicate: false,
        transaction: financeTransactionView(restored),
      };
    if (restored?.deletedAt === null)
      return {
        undone: true,
        duplicate: true,
        transaction: financeTransactionView(restored),
      };
    throw new BadRequestException(
      'Undo window has expired or transaction does not exist',
    );
  }

  async history(
    profileId: string,
    query: FinanceHistoryQueryDto,
    timezone = 'UTC',
  ) {
    const range = financeHistoryDateRange(query.from, query.to, timezone);
    const rows = await this.prisma.financeTransaction.findMany({
      where: {
        profileId,
        deletedAt: null,
        ...(query.type ? { type: query.type } : {}),
        ...(query.categoryId ? { categoryId: query.categoryId } : {}),
        ...(query.accountId ? { accountId: query.accountId } : {}),
        ...financeTransactionSearchFilter(query.search),
        ...financeOccurredAtFilter(range),
      },
      select: financeTransactionSelect,
      orderBy: [{ occurredAt: 'desc' }, { id: 'desc' }],
      cursor: query.cursor ? { id: query.cursor } : undefined,
      skip: query.cursor ? 1 : 0,
      take: query.limit + 1,
    });
    const hasMore = rows.length > query.limit;
    const items = rows
      .slice(0, query.limit)
      .map((row) => financeTransactionView(row));
    return { items, nextCursor: hasMore ? items.at(-1)?.id || null : null };
  }

  async detail(profileId: string, id: string) {
    const row = await this.prisma.financeTransaction.findFirst({
      where: { id, profileId, deletedAt: null },
      select: {
        ...financeTransactionSelect,
        items: {
          select: {
            id: true,
            displayName: true,
            normalizedName: true,
            quantity: true,
            unitPrice: true,
            totalAmount: true,
            currency: true,
            category: {
              select: { id: true, name: true, key: true, type: true },
            },
          },
          orderBy: { createdAt: 'asc' },
        },
      },
    });
    if (!row) throw new NotFoundException('Finance transaction not found');
    return {
      ...financeTransactionView(row),
      items: row.items.map((item) => ({
        ...item,
        quantity: item.quantity?.toString() || null,
        unitPrice: item.unitPrice?.toString() || null,
        totalAmount: item.totalAmount.toString(),
      })),
    };
  }

  private async items(
    tx: Prisma.TransactionClient,
    profileId: string,
    type: CreateFinanceTransactionDto['type'],
    items: CreateFinanceTransactionDto['items'],
    preparedCategories?: FinanceTransactionWriteContext['categories'],
  ) {
    if (!items?.length) return [];
    const categoryIds = [
      ...new Set(items.map((item) => item.categoryId).filter(Boolean)),
    ] as string[];
    if (categoryIds.length) {
      const categories = preparedCategories
        ? categoryIds
            .map((categoryId) => preparedCategories.get(categoryId))
            .filter((category) => category !== undefined)
        : await tx.financeCategory.findMany({
            where: { id: { in: categoryIds }, profileId, archivedAt: null },
            select: { id: true, type: true },
          });
      if (
        categories.length !== categoryIds.length ||
        categories.some((category) => category.type !== type)
      )
        throw new NotFoundException('Finance item category not found');
    }
    return items.map((item) => ({
      displayName: item.displayName.trim(),
      normalizedName: this.normalizeMerchant(item.displayName),
      quantity: item.quantity
        ? this.positive(item.quantity, 'item quantity')
        : null,
      unitPrice: item.unitPrice
        ? this.positive(item.unitPrice, 'item unit price')
        : null,
      totalAmount: this.positive(item.totalAmount, 'item total amount'),
      currency: item.currency.toUpperCase(),
      categoryId: item.categoryId || null,
    }));
  }

  async stats(profileId: string, from: Date, to: Date) {
    return financeLedgerStats({
      prisma: this.prisma,
      analytics: this.analyticsService!,
      assets: this.assets,
      profileId,
      from,
      to,
      loadAccounts: (id, currency, workspaceId) =>
        this.accounts(id, currency, workspaceId),
    });
  }

  private rateDependencies() {
    return {
      conversion: this.conversion,
      resolveWorkspaceId: (profileId: string) => this.workspaceId(profileId),
    };
  }

  private async workspaceId(profileId: string) {
    const profile = await this.prisma.financeProfile.findUnique({
      where: { id: profileId },
      select: { botIntegration: { select: { workspaceId: true } } },
    });
    return profile?.botIntegration.workspaceId;
  }

  normalizeMerchant(value: string) {
    return normalizeFinanceMerchant(value);
  }
  private positive(value: string | undefined, field: string) {
    try {
      const amount = new Prisma.Decimal(value || '');
      if (!amount.isFinite() || amount.lte(0)) throw new Error();
      return amount;
    } catch {
      throw new BadRequestException(`${field} must be a positive decimal`);
    }
  }

  private resolveEconomicAmount(
    amount: Prisma.Decimal,
    value: string | undefined,
    purpose: FinanceTransactionPurpose,
  ) {
    if (purpose !== FinanceTransactionPurpose.ORDINARY) {
      if (value !== undefined && !new Prisma.Decimal(value).isZero())
        throw new BadRequestException(
          'Balance-only transactions cannot have an economic amount',
        );
      return new Prisma.Decimal(0);
    }
    const economicAmount =
      value === undefined ? amount : new Prisma.Decimal(value || '');
    if (
      !economicAmount.isFinite() ||
      economicAmount.isNegative() ||
      economicAmount.gt(amount)
    )
      throw new BadRequestException(
        'Economic amount must be between zero and the cash amount',
      );
    return economicAmount;
  }


}
