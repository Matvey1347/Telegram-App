import { BadRequestException, ForbiddenException } from '@nestjs/common';
import { FinanceAssistantEntryService, stripExplicitCategoryLabel } from '@consumer-finance/api/ultimate/finance-assistant-entry.service';

const identity = {
  profileId: 'profile-1',
  botIntegrationId: 'bot-1',
  telegramBotUserId: 'user-1',
  workspaceId: 'workspace-1',
};

function setup() {
  const prisma = {
    financeProfile: {
      findUnique: jest.fn().mockResolvedValue({
        id: 'profile-1',
        defaultCurrency: 'PLN',
        timezone: 'Europe/Warsaw',
      }),
    },
  };
  const ai = {
    extractText: jest.fn().mockResolvedValue([
      {
        type: 'EXPENSE',
        amount: '100',
        economicAmount: '25',
        currency: 'PLN',
        description: 'Dinner',
        occurredAt: '2026-09-12T12:00:00.000Z',
      },
    ]),
    extractReceipt: jest.fn(),
    extractReceipts: jest.fn().mockResolvedValue([]),
    transcribeVoice: jest.fn(),
  };
  const proposals = {
    createBatch: jest.fn().mockResolvedValue({
      token: 'safe-token',
      preview: [
        {
          payload: {
            type: 'EXPENSE',
            amount: '100',
            economicAmount: '25',
            currency: 'PLN',
            description: 'Dinner',
            occurredAt: '2026-09-12T12:00:00.000Z',
            accountId: 'account-1',
            categoryId: 'category-1',
          },
          accountName: 'Card',
          categoryName: 'Restaurants',
        },
      ],
    }),
    confirm: jest.fn().mockResolvedValue({
      transactionIds: ['transaction-1'],
      duplicate: false,
    }),
    cancel: jest.fn(),
  };
  const entitlements = {
    hasCapability: jest.fn().mockResolvedValue(true),
  };
  return {
    service: new FinanceAssistantEntryService(
      prisma as never,
      ai as never,
      proposals as never,
      entitlements as never,
    ),
    prisma,
    ai,
    proposals,
    entitlements,
  };
}

describe('FinanceAssistantEntryService', () => {
  it('returns a reviewable proposal and performs no ledger write', async () => {
    const { service, ai, proposals } = setup();
    await expect(
      service.fromText(identity, 'Paid for dinner'),
    ).resolves.toEqual({
      token: 'safe-token',
      operations: [
        expect.objectContaining({
          amount: '100',
          economicAmount: '25',
          accountName: 'Card',
        }),
      ],
    });
    expect(ai.extractText).toHaveBeenCalledWith(
      expect.objectContaining({
        profileId: 'profile-1',
        timezone: 'Europe/Warsaw',
      }),
    );
    expect(proposals.confirm).not.toHaveBeenCalled();
  });

  it('passes an explicitly named category to proposal resolution', async () => {
    const { service, proposals } = setup();
    await service.fromText(identity, 'привет я потратил 9zł на булочку с банка вчера категория kity');
    expect(proposals.createBatch).toHaveBeenCalledWith(expect.objectContaining({
      operations: [expect.objectContaining({ categoryHint: 'kity' })],
    }));
  });

  it('reports only completed work and finishes after the proposal is saved', async () => {
    const { service, proposals } = setup();
    const progress: Array<[number, string]> = [];
    proposals.createBatch.mockImplementationOnce(async () => {
      expect(progress).toEqual([
        [0, 'UNDERSTANDING'],
        [1, 'PREPARING'],
        [2, 'CHECKING'],
      ]);
      return { token: 'safe-token', preview: [] };
    });
    await service.fromText(identity, 'Paid for dinner', (completed, stage) => {
      progress.push([completed, stage]);
    });
    expect(progress.at(-1)).toEqual([3, 'CHECKING']);
  });

  it('keeps the purchase description separate from an explicit category label', () => {
    expect(stripExplicitCategoryLabel('булочка (категория: kity)')).toBe('булочка');
    expect(stripExplicitCategoryLabel('булочка, категория kity')).toBe('булочка');
  });

  it('requires a bounded uploaded file before calling AI', async () => {
    const { service, ai } = setup();
    await expect(service.fromFile(identity, undefined)).rejects.toBeInstanceOf(
      BadRequestException,
    );
    expect(ai.extractReceipt).not.toHaveBeenCalled();
    expect(ai.transcribeVoice).not.toHaveBeenCalled();
  });

  it('rejects voice uploads when the plan has no voice capability', async () => {
    const { service, ai, entitlements } = setup();
    entitlements.hasCapability.mockResolvedValue(false);
    await expect(
      service.fromFile(identity, {
        buffer: Buffer.from('voice'),
        mimetype: 'audio/webm',
      } as Express.Multer.File),
    ).rejects.toBeInstanceOf(ForbiddenException);
    expect(ai.transcribeVoice).not.toHaveBeenCalled();
  });

  it('extracts up to five receipt images together as one reviewable proposal', async () => {
    const { service, ai, proposals } = setup();
    const files = ['front.png', 'back.png'].map(
      (originalname) =>
        ({
          originalname,
          buffer: Buffer.from(originalname),
          mimetype: 'image/png',
        }) as Express.Multer.File,
    );

    await service.fromFiles(identity, files);

    expect(ai.extractReceipts).toHaveBeenCalledWith(
      expect.objectContaining({
        files: files.map((file) => ({
          bytes: file.buffer,
          mime: 'image/png',
        })),
      }),
    );
    expect(proposals.createBatch).toHaveBeenCalledTimes(1);
  });

  it('rejects mixed image and audio batches before calling AI', async () => {
    const { service, ai } = setup();

    await expect(
      service.fromFiles(identity, [
        {
          buffer: Buffer.from('receipt'),
          mimetype: 'image/png',
        } as Express.Multer.File,
        {
          buffer: Buffer.from('voice'),
          mimetype: 'audio/webm',
        } as Express.Multer.File,
      ]),
    ).rejects.toBeInstanceOf(BadRequestException);
    expect(ai.extractReceipts).not.toHaveBeenCalled();
    expect(ai.transcribeVoice).not.toHaveBeenCalled();
  });

  it('confirms with the authenticated profile and its real currency', async () => {
    const { service, proposals } = setup();
    await service.confirm(identity, 'safe-token');
    expect(proposals.confirm).toHaveBeenCalledWith({
      token: 'safe-token',
      botIntegrationId: 'bot-1',
      telegramBotUserId: 'user-1',
      profile: {
        id: 'profile-1',
        defaultCurrency: 'PLN',
        workspaceId: 'workspace-1',
      },
    });
  });
});
