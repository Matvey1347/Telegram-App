import { Type } from "class-transformer";
import {
  ArrayMaxSize,
  ArrayMinSize,
  IsArray,
  IsBoolean,
  IsDateString,
  IsIn,
  IsInt,
  IsNumberString,
  IsOptional,
  IsString,
  Matches,
  Max,
  MaxLength,
  Min,
  MinLength,
  ValidateNested,
} from "class-validator";

const DATE_ONLY = /^\d{4}-\d{2}-\d{2}$/u;

export class FinanceDebtInputDto {
  @IsIn(["I_OWE", "OWED_TO_ME"]) direction!: "I_OWE" | "OWED_TO_ME";
  @IsString() @MinLength(1) @MaxLength(120) @Matches(/\S/u) name!: string;
  @IsOptional() @IsString() @MaxLength(2048) emoji?: string | null;
  @IsNumberString() amount!: string;
  @IsString() accountId!: string;
  @IsOptional() @IsBoolean() recordTransaction?: boolean;
  @IsString() @Matches(DATE_ONLY) dueDate!: string;
  @IsOptional() @IsString() @MaxLength(500) note?: string | null;
}

export class FinanceDebtQueryDto {
  @IsOptional() @IsString() @Matches(/\S/u) id?: string;
  @IsOptional() @IsIn(["OPEN", "SETTLED"]) status?: "OPEN" | "SETTLED";
  @IsOptional() @IsString() cursor?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(100) limit = 30;
}

export class FinanceDebtSettlementDto {
  @IsOptional() @IsString() accountId?: string;
  @IsOptional() @IsNumberString() amount?: string;
  @IsOptional() @IsString() @Matches(DATE_ONLY) settlementDate?: string;
}

export class FinanceSharedExpenseParticipantDto {
  @IsString() @MinLength(1) @MaxLength(120) @Matches(/\S/u) name!: string;
  @IsNumberString() amount!: string;
  @IsString() @Matches(DATE_ONLY) dueDate!: string;
}

export class FinanceSharedExpenseInputDto {
  @IsString() accountId!: string;
  @IsOptional() @IsString() categoryId?: string;
  @IsNumberString() amount!: string;
  @IsNumberString() ownShare!: string;
  @IsOptional() @IsString() @MaxLength(240) description?: string;
  @IsDateString() occurredAt!: string;
  @IsOptional()
  @IsIn(["UNSPECIFIED", "REQUIRED", "DISCRETIONARY"])
  necessity?: "UNSPECIFIED" | "REQUIRED" | "DISCRETIONARY";
  @IsArray()
  @ArrayMinSize(1)
  @ArrayMaxSize(20)
  @ValidateNested({ each: true })
  @Type(() => FinanceSharedExpenseParticipantDto)
  participants!: FinanceSharedExpenseParticipantDto[];
}

export class FinanceRegularPaymentInputDto {
  @IsString() @MinLength(1) @MaxLength(120) @Matches(/\S/u) name!: string;
  @IsOptional() @IsString() @MaxLength(120) emoji?: string | null;
  @IsNumberString() amount!: string;
  @IsString() accountId!: string;
  @IsOptional() @IsString() categoryId?: string | null;
  @IsIn(["DAILY", "WEEKLY", "MONTHLY", "YEARLY"]) recurrence!:
    | "DAILY"
    | "WEEKLY"
    | "MONTHLY"
    | "YEARLY";
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(3650)
  intervalCount?: number = 1;
  @IsString() @Matches(DATE_ONLY) nextPaymentDate!: string;
  @IsOptional() @IsString() @MaxLength(500) note?: string | null;
  @IsOptional()
  @IsIn(["UNSPECIFIED", "REQUIRED", "DISCRETIONARY"])
  necessity?: "UNSPECIFIED" | "REQUIRED" | "DISCRETIONARY";
}

export class FinanceRegularPaymentQueryDto {
  @IsOptional() @IsString() @Matches(/\S/u) id?: string;
  @IsOptional()
  @IsIn(["ACTIVE", "PAUSED", "CANCELED"])
  status?: "ACTIVE" | "PAUSED" | "CANCELED";
  @IsOptional() @IsString() cursor?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(100) limit = 30;
}

export class FinanceRegularPaymentRevisionQueryDto {
  @IsOptional() @IsString() cursor?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(100) limit = 30;
}

export class FinanceRegularPaymentConfirmDto {
  @IsDateString() expectedOccurrenceAt!: string;
  @Type(() => Number) @IsInt() @Min(1) expectedVersion!: number;
  @IsOptional() @IsNumberString() amount?: string;
  @IsOptional() @IsString() accountId?: string;
  @IsOptional() @IsString() categoryId?: string | null;
  @IsOptional() @IsString() @MaxLength(240) description?: string;
  @IsOptional() @IsString() @MaxLength(2048) emoji?: string | null;
  @IsOptional() @IsDateString() occurredAt?: string;
  /** Record an early payment without consuming or moving the planned occurrence. */
  @IsOptional() @IsIn([true, false]) preserveSchedule?: boolean;
  @IsOptional()
  @IsIn(["UNSPECIFIED", "REQUIRED", "DISCRETIONARY"])
  necessity?: "UNSPECIFIED" | "REQUIRED" | "DISCRETIONARY";
}

export class FinanceApplyOccurrenceAmountDto {
  @Type(() => Number) @IsInt() @Min(1) expectedVersion!: number;
}
