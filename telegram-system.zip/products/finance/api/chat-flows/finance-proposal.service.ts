import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { FinanceProposalStatus, Prisma } from '@prisma/client';
import { createHash, randomBytes } from 'crypto';
import { PrismaService } from '@api/prisma/prisma.service';
import {
  DEFAULT_FINANCE_CATEGORIES,
  FINANCE_PROPOSAL_TTL_MS,
} from '@consumer-finance/api/catalog/finance-defaults';
import { FinanceLedgerService } from '@consumer-finance/api/ledger/finance-ledger.service';

type ProposalPayload = {
  type: 'INCOME' | 'EXPENSE';
  amount: string;
  economicAmount?: string;
  purpose?: 'ORDINARY' | 'REIMBURSEMENT' | 'PASS_THROUGH' | 'DEBT_REPAYMENT';
  necessity?: 'UNSPECIFIED' | 'REQUIRED' | 'DISCRETIONARY';
  currency: string;
  description: string | null;
  accountHint?: string;
  merchantDisplay?: string;
  items?: Array<{
    displayName: string;
    quantity?: string;
    unitPrice?: string;
    totalAmount: string;
    currency: string;
  }>;
  accountId: string;
  categoryId: string | null;
  occurredAt: string;
};
type StoredProposal =
  | ProposalPayload
  | { operations: ProposalPayload[]; source?: 'AI' | 'RECEIPT' };

@Injectable()
export class FinanceProposalService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly ledger: FinanceLedgerService,
  ) {}

  async createQuick(input: {
    profile: { id: string; defaultCurrency: string };
    botIntegrationId: string;
    telegramBotUserId: string;
    type: 'INCOME' | 'EXPENSE';
    amount: string;
    description: string | null;
  }) {
    const amount = new Prisma.Decimal(input.amount);
    if (!amount.isFinite() || amount.lte(0))
      throw new BadRequestException('Amount must be positive');
    const account = await this.prisma.financeAccount.findFirst({
      where: { profileId: input.profile.id, archivedAt: null },
      orderBy: { createdAt: 'asc' },
    });
    if (!account)
      throw new BadRequestException(
        'Create an account before adding a transaction',
      );
    const category = await this.resolveCategory(
      input.profile.id,
      input.type,
      input.description,
    );
    const token = randomBytes(18).toString('base64url');
    const payload: ProposalPayload = {
      type: input.type,
      amount: amount.toString(),
      currency: account.currency,
      description: input.description,
      accountId: account.id,
      categoryId: category?.id || null,
      occurredAt: new Date().toISOString(),
    };
    await this.prisma.financePendingProposal.create({
      data: {
        profileId: input.profile.id,
        telegramBotUserId: input.telegramBotUserId,
        botIntegrationId: input.botIntegrationId,
        tokenHash: this.hash(token),
        payload,
        expiresAt: new Date(Date.now() + FINANCE_PROPOSAL_TTL_MS),
      },
    });
    return { token, payload, account, category };
  }

  async confirm(input: {
    token: string;
    botIntegrationId: string;
    telegramBotUserId: string;
    profile: { id: string; defaultCurrency: string; workspaceId?: string };
  }) {
    const tokenHash = this.hash(input.token);
    const candidate = await this.prisma.financePendingProposal.findUnique({
      where: { tokenHash },
    });
    if (!candidate || !this.belongsToInput(candidate, input))
      throw new NotFoundException('Finance proposal not found');
    if (
      candidate.status === FinanceProposalStatus.CONFIRMED &&
      candidate.transactionId
    )
      return this.duplicateResult(candidate.transactionId);
    if (
      candidate.status !== FinanceProposalStatus.PENDING ||
      candidate.expiresAt <= new Date()
    )
      throw new BadRequestException(
        'Finance proposal has expired or was cancelled',
      );
    const rates = await this.ledger.prepareTransactionRateSource(
      input.profile,
      this.operations(candidate.payload as StoredProposal),
    );
    return this.prisma.$transaction(async (tx) => {
      const proposal = await tx.financePendingProposal.findUnique({
        where: { tokenHash },
      });
      if (!proposal || !this.belongsToInput(proposal, input))
        throw new NotFoundException('Finance proposal not found');
      if (
        proposal.status === FinanceProposalStatus.CONFIRMED &&
        proposal.transactionId
      )
        return this.duplicateResult(proposal.transactionId);
      if (
        proposal.status !== FinanceProposalStatus.PENDING ||
        proposal.expiresAt <= new Date()
      )
        throw new BadRequestException(
          'Finance proposal has expired or was cancelled',
        );
      const claimed = await tx.financePendingProposal.updateMany({
        where: {
          id: proposal.id,
          status: FinanceProposalStatus.PENDING,
          expiresAt: { gt: new Date() },
        },
        data: { status: FinanceProposalStatus.CONFIRMED },
      });
      if (!claimed.count) {
        const completed = await tx.financePendingProposal.findUnique({
          where: { id: proposal.id },
          select: { status: true, transactionId: true },
        });
        if (
          completed?.status === FinanceProposalStatus.CONFIRMED &&
          completed.transactionId
        )
          return this.duplicateResult(completed.transactionId);
        throw new BadRequestException(
          'Finance proposal is no longer available',
        );
      }
      const payload = proposal.payload as StoredProposal;
      const operations = this.operations(payload);
      const transactionInputs = operations.map((operation) => ({
        ...operation,
        categoryId: operation.categoryId || undefined,
        description: operation.description || undefined,
      }));
      const writeContext = await this.ledger.prepareTransactionWriteContext(
        tx,
        input.profile.id,
        transactionInputs,
        rates,
      );
      const transactions: Array<{ id: string }> = [];
      const source = 'operations' in payload ? payload.source || 'AI' : 'CHAT';
      for (const operation of transactionInputs)
        transactions.push(
          await this.ledger.createTransactionInTransaction(
            tx,
            input.profile,
            operation,
            source,
            undefined,
            writeContext,
          ),
        );
      const transactionId = transactions.map((item) => item.id).join(',');
      await tx.financePendingProposal.update({
        where: { id: proposal.id },
        data: { transactionId },
      });
      return {
        transactionId,
        transactionIds: transactions.map((item) => item.id),
        duplicate: false,
      };
    });
  }

  async revise(input: {
    token: string;
    botIntegrationId: string;
    telegramBotUserId: string;
    profile: { id: string };
    operations: Array<{
      amount: string;
      economicAmount?: string;
      accountId?: string;
      categoryId?: string | null;
      description?: string;
      occurredAt: string;
      purpose?: ProposalPayload['purpose'];
      necessity?: ProposalPayload['necessity'];
    }>;
    keepIndices?: number[];
  }) {
    const candidate = await this.prisma.financePendingProposal.findUnique({
      where: { tokenHash: this.hash(input.token) },
    });
    if (!candidate || !this.belongsToInput(candidate, input))
      throw new NotFoundException('Finance proposal not found');
    if (
      candidate.status !== FinanceProposalStatus.PENDING ||
      candidate.expiresAt <= new Date()
    )
      throw new BadRequestException('Finance proposal has expired or was cancelled');
    const stored = candidate.payload as StoredProposal;
    const current = this.operations(stored);
    const selected = input.keepIndices
      ? input.keepIndices.map((index) => current[index])
      : current;
    if (selected.some((operation) => !operation) || new Set(input.keepIndices).size !== (input.keepIndices?.length ?? 0))
      throw new BadRequestException('Invalid proposal operation selection');
    if (selected.length !== input.operations.length || !selected.length)
      throw new BadRequestException('Proposal operation count cannot be changed');
    const [accounts, categories] = await Promise.all([
      this.prisma.financeAccount.findMany({ where: { profileId: input.profile.id, archivedAt: null }, select: { id: true, currency: true } }),
      this.prisma.financeCategory.findMany({ where: { profileId: input.profile.id, archivedAt: null }, select: { id: true, parentId: true, type: true } }),
    ]);
    const parentIds = new Set(categories.flatMap((category) => category.parentId ? [category.parentId] : []));
    const operations = selected.map((operation, index) => {
      const revision = input.operations[index];
      const accountId = revision.accountId ?? operation.accountId;
      if (!accounts.some((account) => account.id === accountId && account.currency === operation.currency))
        throw new BadRequestException('Select an account in the proposal currency');
      const categoryId = revision.categoryId === undefined ? operation.categoryId : revision.categoryId;
      if (categoryId && !categories.some((category) => category.id === categoryId && category.type === operation.type && !parentIds.has(category.id)))
        throw new BadRequestException('Select a leaf category of the matching type');
      const amount = new Prisma.Decimal(revision.amount);
      if (!amount.isFinite() || amount.lte(0))
        throw new BadRequestException('Amount must be positive');
      const oldAmount = new Prisma.Decimal(operation.amount);
      const economicAmount = revision.economicAmount ?? (
        operation.economicAmount &&
        new Prisma.Decimal(operation.economicAmount).equals(oldAmount)
          ? amount.toString()
          : operation.economicAmount);
      if (
        economicAmount &&
        new Prisma.Decimal(economicAmount).gt(amount) &&
        (revision.purpose ?? operation.purpose ?? 'ORDINARY') === 'ORDINARY'
      )
        throw new BadRequestException('Economic amount cannot exceed the amount');
      return {
        ...operation,
        accountId,
        categoryId,
        amount: amount.toString(),
        economicAmount,
        description: revision.description?.trim() || null,
        occurredAt: revision.occurredAt,
        purpose: revision.purpose ?? operation.purpose,
        necessity: revision.necessity ?? operation.necessity,
      };
    });
    const payload: StoredProposal = 'operations' in stored
      ? { ...stored, operations }
      : operations[0];
    const changed = await this.prisma.financePendingProposal.updateMany({
      where: { id: candidate.id, status: FinanceProposalStatus.PENDING, expiresAt: { gt: new Date() } },
      data: { payload: payload as Prisma.InputJsonValue },
    });
    if (changed.count !== 1)
      throw new BadRequestException('Finance proposal is no longer available');
    return { updated: true };
  }

  private belongsToInput(
    proposal: {
      botIntegrationId: string;
      telegramBotUserId: string;
      profileId: string;
    } | null,
    input: {
      botIntegrationId: string;
      telegramBotUserId: string;
      profile: { id: string };
    },
  ) {
    return Boolean(
      proposal &&
      proposal.botIntegrationId === input.botIntegrationId &&
      proposal.telegramBotUserId === input.telegramBotUserId &&
      proposal.profileId === input.profile.id,
    );
  }

  private operations(payload: StoredProposal) {
    const operations = 'operations' in payload ? payload.operations : [payload];
    if (!operations.length || operations.length > 10)
      throw new BadRequestException(
        'A proposal must contain 1 to 10 operations',
      );
    return operations;
  }

  private duplicateResult(transactionId: string) {
    return {
      transactionId,
      transactionIds: transactionId.split(','),
      duplicate: true,
    };
  }

  async createBatch(input: {
    profile: { id: string; defaultCurrency: string };
    botIntegrationId: string;
    telegramBotUserId: string;
    source?: 'AI' | 'RECEIPT';
    operations: Array<{
      type: 'INCOME' | 'EXPENSE';
      amount: string;
      economicAmount?: string;
      purpose?:
        | 'ORDINARY'
        | 'REIMBURSEMENT'
        | 'PASS_THROUGH'
        | 'DEBT_REPAYMENT';
      necessity?: 'UNSPECIFIED' | 'REQUIRED' | 'DISCRETIONARY';
      currency: string;
      description: string;
      occurredAt: string;
      accountHint?: string;
      merchantDisplay?: string;
      categoryHint?: string;
      items?: Array<{
        displayName: string;
        quantity?: string;
        unitPrice?: string;
        totalAmount: string;
        currency: string;
      }>;
    }>;
  }) {
    if (!input.operations.length || input.operations.length > 10)
      throw new BadRequestException(
        'A proposal must contain 1 to 10 operations',
      );
    const accounts = await this.prisma.financeAccount.findMany({
      where: { profileId: input.profile.id, archivedAt: null },
      orderBy: { createdAt: 'asc' },
    });
    const operations: ProposalPayload[] = [];
    const preview: Array<{
      payload: ProposalPayload;
      accountName: string;
      categoryName: string | null;
    }> = [];
    for (const item of input.operations) {
      const account = this.resolveAccount(
        accounts,
        item.accountHint,
        item.currency,
      );
      if (!account)
        throw new BadRequestException(
          'Create an account before adding transactions',
        );
      if (account.currency !== item.currency)
        throw new BadRequestException(
          `No ${item.currency} account is available for an AI proposal`,
        );
      const category =
        !item.purpose || item.purpose === 'ORDINARY'
          ? await this.resolveCategory(
              input.profile.id,
              item.type,
              item.merchantDisplay || item.description,
              item.categoryHint,
            )
          : null;
      const payload = {
        ...item,
        accountId: account.id,
        categoryId: category?.id || null,
      };
      operations.push(payload);
      preview.push({
        payload,
        accountName: account.name,
        categoryName: category?.name || null,
      });
    }
    const token = randomBytes(18).toString('base64url');
    await this.prisma.financePendingProposal.create({
      data: {
        profileId: input.profile.id,
        telegramBotUserId: input.telegramBotUserId,
        botIntegrationId: input.botIntegrationId,
        tokenHash: this.hash(token),
        payload: { operations, source: input.source || 'AI' },
        expiresAt: new Date(Date.now() + FINANCE_PROPOSAL_TTL_MS),
      },
    });
    return { token, operations, preview };
  }

  async cancel(input: {
    token: string;
    botIntegrationId: string;
    telegramBotUserId: string;
  }) {
    const result = await this.prisma.financePendingProposal.updateMany({
      where: {
        tokenHash: this.hash(input.token),
        botIntegrationId: input.botIntegrationId,
        telegramBotUserId: input.telegramBotUserId,
        status: FinanceProposalStatus.PENDING,
      },
      data: { status: FinanceProposalStatus.CANCELLED },
    });
    return { cancelled: true, duplicate: result.count === 0 };
  }

  private async resolveCategory(
    profileId: string,
    type: 'INCOME' | 'EXPENSE',
    description: string | null,
    explicitHint?: string,
  ) {
    const merchant = description
      ? this.ledger.normalizeMerchant(description)
      : '';
    const categories = await this.prisma.financeCategory.findMany({
      where: { profileId, type, archivedAt: null },
    });
    const parentIds = new Set(
      categories.flatMap((category) => category.parentId ? [category.parentId] : []),
    );
    const leafCategories = categories.filter((category) => !parentIds.has(category.id));
    if (explicitHint) {
      const normalizedHint = this.ledger.normalizeMerchant(explicitHint);
      return leafCategories.find((category) =>
        this.ledger.normalizeMerchant(category.name) === normalizedHint,
      ) || null;
    }
    if (merchant) {
      const mapping = await this.prisma.financeMerchantMapping.findUnique({
        where: {
          profileId_merchantNormalized: {
            profileId,
            merchantNormalized: merchant,
          },
        },
      });
      if (mapping) {
        const mapped = leafCategories.find((item) => item.id === mapping.categoryId);
        if (mapped) return mapped;
      }
      const history = await this.prisma.financeTransaction.findFirst({
        where: {
          profileId,
          type,
          merchantNormalized: merchant,
          categoryId: { not: null },
          deletedAt: null,
        },
        include: { category: true },
        orderBy: { occurredAt: 'desc' },
      });
      if (
        history?.category &&
        !history.category.archivedAt &&
        leafCategories.some((item) => item.id === history.categoryId)
      )
        return history.category;
    }
    const defaultMatch = DEFAULT_FINANCE_CATEGORIES.find(
      (item) =>
        item.type === type &&
        item.keywords.some((keyword) => merchant.includes(keyword)),
    );
    return (
      leafCategories.find((item) => item.name === defaultMatch?.name) ||
      leafCategories.find(
        (item) =>
          defaultMatch &&
          defaultMatch.keywords.some((keyword) =>
            this.ledger.normalizeMerchant(item.name).includes(keyword),
          ),
      ) ||
      leafCategories.find(
        (item) => item.name === (type === 'INCOME' ? 'Other income' : 'Other'),
      ) ||
      null
    );
  }

  private resolveAccount(
    accounts: Array<{ id: string; name: string; currency: string }>,
    hint: string | undefined,
    currency: string,
  ) {
    const normalizedHint = hint ? this.ledger.normalizeMerchant(hint) : '';
    const hinted = normalizedHint
      ? accounts.filter(
          (account) =>
            this.ledger
              .normalizeMerchant(account.name)
              .includes(normalizedHint) ||
            normalizedHint.includes(
              this.ledger.normalizeMerchant(account.name),
            ),
        )
      : [];
    if (hinted.length === 1) return hinted[0];
    // Accounts are already ordered by creation time. A note without an exact
    // account name must stay capturable: use that stable default rather than
    // turning an everyday expense into a blocking question.
    if (hinted.length > 1) return hinted[0];
    const currencyMatches = accounts.filter(
      (account) => account.currency === currency,
    );
    if (currencyMatches.length === 1) return currencyMatches[0];
    if (currencyMatches.length > 1) return currencyMatches[0];
    return accounts[0];
  }
  private hash(token: string) {
    return createHash('sha256').update(token).digest('hex');
  }
}
