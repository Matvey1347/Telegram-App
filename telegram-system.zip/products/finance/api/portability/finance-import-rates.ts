import { BadRequestException } from '@nestjs/common';
import type { ConsumerFinanceImportDocumentV1 } from '@telegram-system/shared';
import type {
  CurrencyConversionService,
  PreparedCurrencyRateSource,
} from '@api/common/currency-conversion.service';
import { financeRateDateForWrite } from '@consumer-finance/api/ledger/finance-transaction-valuation';
import type { HistoricalExchangeRateService } from '@api/common/historical-exchange-rate.service';

type RateValue = { rate: string; rateAt: Date };

export type FinanceImportRates = {
  transactions: Map<string, { default: RateValue; usd: RateValue }>;
  savingsMovements: Map<string, { usd: RateValue }>;
  investmentCashFlows: Map<
    string,
    { investment: RateValue; default: RateValue; usd: RateValue }
  >;
  investmentValuations: Map<string, { usd: RateValue }>;
};

function unavailable(path: string, from: string, to: string): never {
  throw new BadRequestException({
    code: 'FINANCE_IMPORT_RATE_UNAVAILABLE',
    message: `No historical exchange rate is available for ${from} to ${to}`,
    path,
  });
}

export async function prepareFinanceImportRates(input: {
  document: ConsumerFinanceImportDocumentV1;
  workspaceId: string;
  defaultCurrency: string;
  conversion: CurrencyConversionService;
  historicalRates: HistoricalExchangeRateService;
  signal: AbortSignal;
}): Promise<FinanceImportRates> {
  const accounts = new Map(
    (input.document.data.accounts ?? []).map((row) => [row.ref, row.currency]),
  );
  const investments = new Map(
    (input.document.data.investments ?? []).map((row) => [
      row.ref,
      row.currency,
    ]),
  );
  const sources = new Map<string, Promise<PreparedCurrencyRateSource>>();
  const rates = new Map<string, Promise<RateValue>>();
  const historicalDates: Date[] = [];
  const currentRateDate = new Date();
  const requiredCurrencies = new Set<string>();
  const collectHistorical = (
    currency: string,
    targets: string[],
    at: string,
  ) => {
    if (targets.every((target) => target === currency)) return;
    requiredCurrencies.add(currency);
    targets.forEach((target) => requiredCurrencies.add(target));
    const asOf = financeRateDateForWrite(new Date(at));
    historicalDates.push(asOf ?? currentRateDate);
  };
  for (const row of input.document.data.transactions ?? [])
    collectHistorical(
      accounts.get(row.accountRef)!,
      [input.defaultCurrency, 'USD'],
      row.occurredAt,
    );
  for (const row of input.document.data.savingsMovements ?? [])
    collectHistorical(accounts.get(row.accountRef)!, ['USD'], row.occurredAt);
  for (const row of input.document.data.investmentCashFlows ?? [])
    collectHistorical(
      accounts.get(row.accountRef)!,
      [investments.get(row.investmentRef)!, input.defaultCurrency, 'USD'],
      row.occurredAt,
    );
  for (const row of input.document.data.investmentValuations ?? [])
    collectHistorical(
      investments.get(row.investmentRef)!,
      ['USD'],
      row.valuedAt,
    );
  if (input.signal.aborted) {
    const error = new Error('Import cancelled');
    error.name = 'AbortError';
    throw error;
  }
  if (requiredCurrencies.size) {
    try {
      await input.historicalRates.ensureCurrentRates({
        currencies: [...requiredCurrencies],
        signal: input.signal,
      });
    } catch (error) {
      if ((error as Error).name === 'AbortError') throw error;
      // Historical rows may still be imported. Current reads keep their
      // explicit RATE_STALE error if every live provider is unavailable.
    }
  }
  let historicalSources = await input.conversion.prepareHistoricalRateSources(
    input.workspaceId,
    historicalDates,
  );
  if (input.signal.aborted) {
    const error = new Error('Import cancelled');
    error.name = 'AbortError';
    throw error;
  }
  const distinctHistoricalDates = [
    ...new Map(
      historicalDates.map((date) => [date.toISOString(), date]),
    ).values(),
  ];
  const requirementsMissing = await Promise.all(
    distinctHistoricalDates.map(async (date) => {
      const source = historicalSources.get(date.toISOString());
      if (!source) return true;
      for (const from of requiredCurrencies) {
        for (const to of requiredCurrencies) {
          if (
            from !== to &&
            !(await source.getRateMetadata(from, to)).available
          )
            return true;
        }
      }
      return false;
    }),
  );
  if (requirementsMissing.some(Boolean)) {
    try {
      await input.historicalRates.ensureRates({
        dates: distinctHistoricalDates,
        currencies: [...requiredCurrencies],
        signal: input.signal,
      });
      historicalSources = await input.conversion.prepareHistoricalRateSources(
        input.workspaceId,
        distinctHistoricalDates,
      );
    } catch (error) {
      if ((error as Error).name === 'AbortError') throw error;
      // Resolution below keeps the public error stable when the provider is
      // temporarily unavailable or does not cover an imported currency/date.
    }
  }
  for (const [key, source] of historicalSources)
    sources.set(key, Promise.resolve(source));

  const resolve = (from: string, to: string, at: string, path: string) => {
    const occurredAt = new Date(at);
    const asOf = financeRateDateForWrite(occurredAt);
    const sourceKey = asOf?.toISOString() ?? 'CURRENT';
    const rateKey = `${sourceKey}:${from}:${to}`;
    const existing = rates.get(rateKey);
    if (existing) return existing;
    const promise = (async () => {
      if (input.signal.aborted) {
        const error = new Error('Import cancelled');
        error.name = 'AbortError';
        throw error;
      }
      if (from === to) return { rate: '1', rateAt: occurredAt };
      let source = sources.get(sourceKey);
      if (!source) {
        source = input.conversion.prepareRateSource(input.workspaceId, asOf);
        sources.set(sourceKey, source);
      }
      const result = await (await source).getRateMetadata(from, to);
      if (!result.available) unavailable(path, from, to);
      return { rate: String(result.rate), rateAt: result.rateAt };
    })();
    rates.set(rateKey, promise);
    return promise;
  };

  const transactionRates = new Map<
    string,
    { default: RateValue; usd: RateValue }
  >();
  await Promise.all(
    (input.document.data.transactions ?? []).map(async (row, index) => {
      const currency = accounts.get(row.accountRef)!;
      const [defaultRate, usd] = await Promise.all([
        resolve(
          currency,
          input.defaultCurrency,
          row.occurredAt,
          `data.transactions[${index}].occurredAt`,
        ),
        resolve(
          currency,
          'USD',
          row.occurredAt,
          `data.transactions[${index}].occurredAt`,
        ),
      ]);
      transactionRates.set(row.ref, { default: defaultRate, usd });
    }),
  );

  const savingsRates = new Map<string, { usd: RateValue }>();
  await Promise.all(
    (input.document.data.savingsMovements ?? []).map(async (row, index) => {
      const currency = accounts.get(row.accountRef)!;
      savingsRates.set(row.ref, {
        usd: await resolve(
          currency,
          'USD',
          row.occurredAt,
          `data.savingsMovements[${index}].occurredAt`,
        ),
      });
    }),
  );

  const cashFlowRates = new Map<
    string,
    { investment: RateValue; default: RateValue; usd: RateValue }
  >();
  await Promise.all(
    (input.document.data.investmentCashFlows ?? []).map(async (row, index) => {
      const currency = accounts.get(row.accountRef)!;
      const investmentCurrency = investments.get(row.investmentRef)!;
      const [investment, defaultRate, usd] = await Promise.all([
        resolve(
          currency,
          investmentCurrency,
          row.occurredAt,
          `data.investmentCashFlows[${index}].occurredAt`,
        ),
        resolve(
          currency,
          input.defaultCurrency,
          row.occurredAt,
          `data.investmentCashFlows[${index}].occurredAt`,
        ),
        resolve(
          currency,
          'USD',
          row.occurredAt,
          `data.investmentCashFlows[${index}].occurredAt`,
        ),
      ]);
      cashFlowRates.set(row.ref, {
        investment,
        default: defaultRate,
        usd,
      });
    }),
  );

  const valuationRates = new Map<string, { usd: RateValue }>();
  await Promise.all(
    (input.document.data.investmentValuations ?? []).map(async (row, index) => {
      const currency = investments.get(row.investmentRef)!;
      valuationRates.set(row.ref, {
        usd: await resolve(
          currency,
          'USD',
          row.valuedAt,
          `data.investmentValuations[${index}].valuedAt`,
        ),
      });
    }),
  );

  return {
    transactions: transactionRates,
    savingsMovements: savingsRates,
    investmentCashFlows: cashFlowRates,
    investmentValuations: valuationRates,
  };
}
