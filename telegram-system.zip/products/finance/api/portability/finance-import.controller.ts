import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Param,
  Post,
  Req,
  Res,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import type { Response } from 'express';
import { StreamResponseService } from '@api/common/stream/stream-response.service';
import {
  FinanceConsumerAuthGuard,
  type FinanceImportRequest,
} from '@consumer-finance/api/portability/finance-consumer-auth.guard';
import { FinanceImportService } from '@consumer-finance/api/portability/finance-import.service';

const MAX_IMPORT_BYTES = 10 * 1024 * 1024;

@Controller('finance-bots/:botId')
@UseGuards(FinanceConsumerAuthGuard)
export class FinanceImportController {
  constructor(
    private readonly imports: FinanceImportService,
    private readonly streams: StreamResponseService,
  ) {}

  @Post('import-stream')
  @UseInterceptors(
    FileInterceptor('file', {
      limits: { fileSize: MAX_IMPORT_BYTES, files: 1 },
      fileFilter: (_request, file, callback) => {
        const accepted =
          file.mimetype === 'application/json' ||
          file.mimetype === 'text/json' ||
          file.mimetype === 'text/plain' ||
          file.originalname.toLowerCase().endsWith('.json');
        callback(
          accepted
            ? null
            : new BadRequestException('Only JSON files are supported'),
          accepted,
        );
      },
    }),
  )
  streamImport(
    @Req() request: FinanceImportRequest,
    @Res() response: Response,
    @UploadedFile() file: Express.Multer.File | undefined,
    @Body('mode') requestedMode?: string,
  ) {
    return this.streams.stream(response, {
      eventPrefix: 'consumer-finance.import',
      persistLifecycleLogs: false,
      action: async (onProgress, signal) => {
        if (!file) throw new BadRequestException('Import file is required');
        let document: unknown;
        try {
          document = JSON.parse(file.buffer.toString('utf8')) as unknown;
        } catch {
          throw new BadRequestException({
            code: 'FINANCE_IMPORT_INVALID_JSON',
            message: 'The import file is not valid JSON',
            path: '$',
          });
        }
        if (requestedMode != null) {
          if (requestedMode !== 'ADD' && requestedMode !== 'REPLACE') {
            throw new BadRequestException({
              code: 'FINANCE_IMPORT_INVALID_MODE',
              message: 'Import mode must be ADD or REPLACE',
              path: 'mode',
            });
          }
          if (
            !document ||
            typeof document !== 'object' ||
            Array.isArray(document)
          ) {
            throw new BadRequestException('Import document must be an object');
          }
          document = { ...document, mode: requestedMode };
        }
        return this.imports.import(
          request.financeConsumerSession.profileId,
          document,
          onProgress,
          signal,
          file.originalname,
        );
      },
    });
  }

  @Get('portability-history')
  history(@Req() request: FinanceImportRequest) {
    return this.imports.history(request.financeConsumerSession.profileId);
  }

  @Post('imports/:importId/rollback')
  rollback(
    @Req() request: FinanceImportRequest,
    @Param('importId') importId: string,
    @Body('confirmation') confirmation?: string,
  ) {
    if (confirmation !== 'ROLLBACK FINANCE IMPORT') {
      throw new BadRequestException('Invalid rollback confirmation');
    }
    return this.imports.rollback(
      request.financeConsumerSession.profileId,
      importId,
    );
  }
}
