import { BadRequestException } from '@nestjs/common';
import { FinanceAiProviderService } from '@consumer-finance/api/ai/finance-ai.provider';

describe('FinanceAiProviderService', () => {
  const originalFetch = global.fetch;

  afterEach(() => {
    global.fetch = originalFetch;
  });

  function createService(options?: { fileSize?: number; text?: string }) {
    const prisma = {
      financeProfile: {
        findUnique: jest.fn().mockResolvedValue({
          telegramBotUserId: 'user-1',
          botIntegration: { workspaceId: 'workspace-1' },
          telegramUser: { runtimeInstanceId: 'runtime-1' },
        }),
      },
      aiUsageEvent: {
        create: jest.fn().mockResolvedValue({}),
        update: jest.fn().mockResolvedValue({}),
      },
      aiProviderConfig: {
        findMany: jest.fn().mockResolvedValue([
          {
            botIntegrationId: 'bot-1',
            apiKeyEncrypted: 'encrypted-key',
            apiKeyIv: 'iv',
            apiKeyAuthTag: 'tag',
          },
        ]),
      },
    };
    const credentials = { key: jest.fn().mockResolvedValue('openai-key') };
    const botApi = {
      getFile: jest.fn().mockResolvedValue({
        file_id: 'voice-file',
        file_path: 'voices/voice.ogg',
        file_size: options?.fileSize ?? 1024,
      }),
      downloadFile: jest.fn().mockResolvedValue({
        bytes: Buffer.from('voice-bytes'),
        contentType: 'audio/ogg',
      }),
    };
    const entitlements = { reserve: jest.fn().mockResolvedValue({ id: 'reservation-1' }) };
    const service = new FinanceAiProviderService(
      prisma as never,
      credentials as never,
      entitlements as never,
      botApi as never,
    );
    return { service, botApi, credentials, entitlements, prisma };
  }

  it('downloads a bounded Telegram voice note and transcribes it through the configured provider', async () => {
    const { service, botApi, credentials } = createService();
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({
        text: '  250 грн Bolt с mono  ',
        usage: { input_tokens: 100, output_tokens: 5 },
      }),
    }) as never;

    await expect(
      service.extractVoiceTranscription({
        profileId: 'profile-1',
        botIntegrationId: 'bot-1',
        telegramToken: 'telegram-token',
        fileId: 'voice-file',
        mime: 'audio/ogg',
      }),
    ).resolves.toBe('250 грн Bolt с mono');

    expect(botApi.getFile).toHaveBeenCalledWith('telegram-token', 'voice-file');
    expect(botApi.downloadFile).toHaveBeenCalledWith(
      'telegram-token',
      'voices/voice.ogg',
      8 * 1024 * 1024,
    );
    expect(credentials.key).toHaveBeenCalledWith('profile-1', 'bot-1');
    expect(global.fetch).toHaveBeenCalledWith(
      'https://api.openai.com/v1/audio/transcriptions',
      expect.objectContaining({
        headers: { Authorization: 'Bearer openai-key' },
        method: 'POST',
      }),
    );
  });

  it('rejects an oversized voice before Telegram download', async () => {
    const { service, botApi } = createService();

    await expect(
      service.extractVoiceTranscription({
        profileId: 'profile-1',
        botIntegrationId: 'bot-1',
        telegramToken: 'telegram-token',
        fileId: 'voice-file',
        fileSize: 8 * 1024 * 1024 + 1,
      }),
    ).rejects.toBeInstanceOf(BadRequestException);

    expect(botApi.getFile).not.toHaveBeenCalled();
    expect(botApi.downloadFile).not.toHaveBeenCalled();
  });

  it('rejects an empty transcription without producing a text proposal', async () => {
    const { service } = createService();
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({ text: '   ' }),
    }) as never;

    await expect(
      service.extractVoiceTranscription({
        profileId: 'profile-1',
        botIntegrationId: 'bot-1',
        telegramToken: 'telegram-token',
        fileId: 'voice-file',
      }),
    ).rejects.toThrow('Finance AI returned an invalid transcription');
  });

  it('accepts one proposed expense per image in a two-receipt batch', async () => {
    const { service, entitlements } = createService();
    const operation = (description: string) => ({
      type: 'EXPENSE', amount: '10', economicAmount: null, purpose: null,
      necessity: null, currency: 'UAH', description,
      occurredAt: new Date().toISOString(), accountHint: null,
      merchantDisplay: null, items: null,
    });
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({ output_text: JSON.stringify({ operations: [operation('First'), operation('Second')] }), usage: { input_tokens: 80, output_tokens: 60 } }),
    }) as never;
    await expect(service.extractReceipts({
      profileId: 'profile-1', botIntegrationId: 'bot-1',
      files: [{ bytes: Buffer.from('first'), mime: 'image/png' }, { bytes: Buffer.from('second'), mime: 'image/png' }],
      timezone: 'Europe/Kyiv', defaultCurrency: 'UAH',
    })).resolves.toEqual([expect.objectContaining({ description: 'First' }), expect.objectContaining({ description: 'Second' })]);
    expect(entitlements.reserve).toHaveBeenCalledTimes(1);
    expect(global.fetch).toHaveBeenCalledTimes(1);
  });
});
