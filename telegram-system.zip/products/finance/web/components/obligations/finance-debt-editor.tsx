"use client";

import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import type {
  ConsumerFinanceDebt,
  ConsumerFinanceDebtDirection,
} from "@telegram-system/shared";
import {
  Button,
  DateInput,
  ErrorState,
  FormField,
  Input,
  LoadingState,
  Modal,
  Select,
  Textarea,
} from "@consumer-finance/web/components/ui";
import { consumerFinanceLedgerApi } from "@consumer-finance/web/lib/api/consumer-finance-ledger-api";
import { consumerFinanceObligationsApi } from "@consumer-finance/web/lib/api/consumer-finance-obligations-api";
import { consumerFinanceKeys } from "@consumer-finance/web/lib/query/consumer-finance-query-keys";
import { financeCalendarDate } from "@consumer-finance/web/lib/formatters/consumer-finance-date";
import type { FinanceLocale } from "@consumer-finance/web/components/i18n/core";
import { financeDebtsCopy } from "@consumer-finance/web/components/i18n/debts";
import { financeAccountSelectEmoji } from "@consumer-finance/web/components/accounts/finance-account-select-icon";

export function FinanceDebtEditor({
  botId,
  editing,
  locale,
  onClose,
  onSaved,
}: {
  botId: string;
  editing: ConsumerFinanceDebt | null;
  locale: FinanceLocale;
  timezone: string;
  onClose: () => void;
  onSaved: (debt: ConsumerFinanceDebt) => void;
}) {
  const t = financeDebtsCopy(locale);
  const accounts = useQuery({
    queryKey: consumerFinanceKeys.accounts(botId),
    queryFn: () => consumerFinanceLedgerApi.accounts(botId),
  });
  const [direction, setDirection] = useState<ConsumerFinanceDebtDirection>(
    editing?.direction ?? "I_OWE",
  );
  const [name, setName] = useState(editing?.name ?? "");
  const [amount, setAmount] = useState(editing?.amount ?? "");
  const [accountId, setAccountId] = useState(editing?.accountId ?? "");
  const [dueDate, setDueDate] = useState(
    editing ? financeCalendarDate(editing.dueAt, editing.scheduleTimezone) : "",
  );
  const [note, setNote] = useState(editing?.note ?? "");
  const [recordTransaction, setRecordTransaction] = useState(true);
  const rows = (accounts.data ?? []).filter(
    (account) => !account.archivedAt || account.id === editing?.accountId,
  );
  const selectedAccountId =
    accountId && rows.some((account) => account.id === accountId)
      ? accountId
      : (rows[0]?.id ?? "");
  const selectedAccount = rows.find((account) => account.id === selectedAccountId);
  const save = useMutation({
    mutationFn: () => {
      const input = {
        direction,
        name: name.trim(),
        amount,
        accountId: selectedAccountId,
        dueDate,
        note: note.trim() || null,
        ...(!editing ? { recordTransaction } : {}),
      };
      return editing
        ? consumerFinanceObligationsApi.updateDebt(botId, editing.id, input)
        : consumerFinanceObligationsApi.createDebt(botId, input);
    },
    onSuccess: (saved) => onSaved(saved),
  });
  if (accounts.isLoading) return <LoadingState text={t.loadingAccounts} />;
  if (accounts.isError)
    return (
      <div className="grid gap-3 sm:grid-cols-2">
        <ErrorState text={t.accountLoadError} />
        <Button onClick={() => accounts.refetch()}>{t.retry}</Button>
      </div>
    );
  const valid =
    !!name.trim() &&
    Number(amount) > 0 &&
    !!selectedAccountId &&
    /^\d{4}-\d{2}-\d{2}$/.test(dueDate);
  return (
    <Modal
      open
      onClose={onClose}
      closeLabel={t.close}
      title={editing ? t.editDebt : t.addDebt}
    >
      <div className="space-y-3">
        <FormField label={t.direction}>
          <Select
            uiLocale={locale}
            value={direction}
            onChange={(event) =>
              setDirection(event.target.value as ConsumerFinanceDebtDirection)
            }
          >
            <option value="I_OWE">{t.iOwe}</option>
            <option value="OWED_TO_ME">{t.owedToMe}</option>
          </Select>
        </FormField>
        <FormField label={t.debtName}>
          <Input
            autoFocus
            value={name}
            onChange={(event) => setName(event.target.value)}
          />
        </FormField>
        <FormField label={t.amount}>
          <Input
            inputMode="decimal"
            suffix={selectedAccount?.currency}
            value={amount}
            onChange={(event) => setAmount(event.target.value)}
          />
        </FormField>
        <FormField label={t.account}>
          <Select
            uiLocale={locale}
            value={selectedAccountId}
            onChange={(event) => setAccountId(event.target.value)}
          >
            {rows.map((account) => (
              <option
                key={account.id}
                value={account.id}
                data-icon-emoji={financeAccountSelectEmoji(account)}
                data-option-meta={account.currency}
              >
                {account.name}
              </option>
            ))}
          </Select>
        </FormField>
        {!editing ? (
          <div className="flex items-center justify-between gap-4 rounded-2xl border border-[#cbdcc7] bg-[#edf3eb] px-4 py-3">
            <span id="debt-record-transaction-label" className="text-sm font-semibold text-[#18382d]">
              {t.recordTransaction}
            </span>
            <button
              type="button"
              role="switch"
              aria-labelledby="debt-record-transaction-label"
              aria-checked={recordTransaction}
              className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${recordTransaction ? "bg-[#194d38]" : "bg-[#9aaba0]"}`}
              onClick={() => setRecordTransaction((current) => !current)}
            >
              <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow-sm transition-transform ${recordTransaction ? "left-1 translate-x-5" : "left-1"}`} />
            </button>
          </div>
        ) : null}
        <FormField label={t.dueDate}>
          <DateInput
            lang={locale}
            value={dueDate}
            onChange={(event) => setDueDate(event.target.value)}
          />
        </FormField>
        <FormField label={t.note} className="sm:col-span-2">
          <Textarea
            value={note}
            onChange={(event) => setNote(event.target.value)}
          />
        </FormField>
        <Button
          className="w-full sm:col-span-2"
          disabled={!valid || save.isPending}
          onClick={() => save.mutate()}
        >
          {save.isPending ? t.saving : t.save}
        </Button>
        {save.isPending ? (
          <div role="status" aria-live="polite" className="flex items-center gap-2 rounded-xl border border-[#cbdcc7] bg-[#edf3eb] px-3 py-2 text-sm text-[#194d38]">
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-[#194d38] border-r-transparent" aria-hidden="true" />
            {t.saving}
          </div>
        ) : null}
        {save.isError ? (
          <div className="sm:col-span-2">
            <ErrorState text={t.debtSaveError} />
          </div>
        ) : null}
      </div>
    </Modal>
  );
}
