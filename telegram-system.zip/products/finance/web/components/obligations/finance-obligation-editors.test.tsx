import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  fireEvent,
  render,
  screen,
  waitFor,
  within,
} from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import type {
  ConsumerFinanceAccount,
  ConsumerFinanceCategory,
  ConsumerFinanceDebt,
  ConsumerFinanceRegularPayment,
} from "@telegram-system/shared";
import { FinanceDebtEditor } from "@consumer-finance/web/components/obligations/finance-debt-editor";
import { FinanceDebtCreateModal } from "@consumer-finance/web/components/obligations/finance-debt-create-modal";
import { FinanceRegularPaymentEditor } from "@consumer-finance/web/components/obligations/finance-regular-payment-editor";

const api = vi.hoisted(() => ({
  accounts: vi.fn(),
  categories: vi.fn(),
  createDebt: vi.fn(),
  updateDebt: vi.fn(),
  createRegularPayment: vi.fn(),
  updateRegularPayment: vi.fn(),
}));

vi.mock("@consumer-finance/web/lib/api/consumer-finance-ledger-api", () => ({
  consumerFinanceLedgerApi: {
    accounts: api.accounts,
    categories: api.categories,
  },
}));
vi.mock("@consumer-finance/web/lib/api/consumer-finance-obligations-api", () => ({
  consumerFinanceObligationsApi: api,
}));

const account: ConsumerFinanceAccount = {
  id: "cash",
  name: "Cash wallet",
  type: "CASH",
  currency: "USD",
  openingBalance: "0",
  balance: "200",
  defaultCurrency: "USD",
  iconPresentation: { type: "unicode", value: "💵" },
};
const category: ConsumerFinanceCategory = {
  id: "home",
  name: "Home",
  type: "EXPENSE",
  iconPresentation: { type: "unicode", value: "🏠" },
};
const debt: ConsumerFinanceDebt = {
  id: "debt",
  direction: "I_OWE",
  status: "OPEN",
  name: "Alex",
  amount: "42",
  currency: "USD",
  accountId: "cash",
  account,
  dueAt: "2026-09-12T00:00:00.000Z",
  scheduleTimezone: "UTC",
  note: "Dinner",
  isOverdue: false,
  version: 1,
  createdAt: "2026-09-01T00:00:00.000Z",
  updatedAt: "2026-09-01T00:00:00.000Z",
};
const payment: ConsumerFinanceRegularPayment = {
  id: "rent",
  name: "Rent",
  amount: "100",
  currency: "USD",
  accountId: "cash",
  account,
  categoryId: "home",
  category,
  recurrence: "MONTHLY",
  nextOccurrenceAt: "2026-10-01T00:00:00.000Z",
  scheduleTimezone: "UTC",
  note: "Flat",
  status: "ACTIVE",
  isDue: false,
  version: 3,
  createdAt: "2026-09-01T00:00:00.000Z",
  updatedAt: "2026-09-01T00:00:00.000Z",
};

function wrapper(children: React.ReactNode) {
  return render(
    <QueryClientProvider client={new QueryClient()}>
      {children}
    </QueryClientProvider>,
  );
}

beforeEach(() => {
  vi.clearAllMocks();
  api.accounts.mockResolvedValue([account]);
  api.categories.mockResolvedValue([category]);
});

describe("consumer finance obligation editors", () => {
  it("lets the add-debt modal settle an existing open debt", async () => {
    const onSettle = vi.fn();
    wrapper(
      <FinanceDebtCreateModal
        debts={[debt]}
        locale="en"
        onClose={vi.fn()}
        onCreateNew={vi.fn()}
        onSettle={onSettle}
      />,
    );

    const dialog = await screen.findByRole("dialog", { name: "Add debt" });
    fireEvent.click(
      within(dialog).getByRole("button", { name: "New debt" }),
    );
    fireEvent.click(
      await screen.findByRole("option", {
        name: "Settlement of an existing debt",
      }),
    );
    fireEvent.click(
      within(dialog).getByRole("button", { name: "Choose a debt" }),
    );
    fireEvent.click(await screen.findByRole("option", { name: /Alex/ }));
    fireEvent.click(
      within(dialog).getByRole("button", { name: "Create transaction" }),
    );

    expect(onSettle).toHaveBeenCalledWith(debt);
  });

  it("creates a debt with the exact calendar-date contract", async () => {
    api.createDebt.mockResolvedValue(debt);
    const onSaved = vi.fn();
    wrapper(
      <FinanceDebtEditor
        botId="bot"
        editing={null}
        locale="en"
        timezone="UTC"
        onClose={vi.fn()}
        onSaved={onSaved}
      />,
    );
    const dialog = await screen.findByRole("dialog");
    const inputs = dialog.querySelectorAll("input:not([type='hidden'])");
    fireEvent.change(inputs[0]!, { target: { value: "Alex" } });
    fireEvent.change(inputs[1]!, { target: { value: "42" } });
    fireEvent.click(
      within(dialog).getByRole("button", { name: "Select date" }),
    );
    fireEvent.click(await screen.findByRole("button", { name: "Today" }));
    fireEvent.change(dialog.querySelector("textarea")!, {
      target: { value: "Dinner" },
    });
    fireEvent.click(within(dialog).getByRole("button", { name: "Save" }));

    await waitFor(() => expect(api.createDebt).toHaveBeenCalledOnce());
    expect(api.createDebt).toHaveBeenCalledWith("bot", {
      direction: "I_OWE",
      name: "Alex",
      amount: "42",
      accountId: "cash",
      recordTransaction: true,
      dueDate: expect.stringMatching(/^\d{4}-\d{2}-\d{2}$/),
      note: "Dinner",
    });
    expect(onSaved).toHaveBeenCalledWith(debt);
  });

  it("lets a debt be created without an account transaction", async () => {
    api.createDebt.mockResolvedValue({ ...debt, originTransactionId: null });
    wrapper(
      <FinanceDebtEditor
        botId="bot" editing={null} locale="en" timezone="UTC"
        onClose={vi.fn()} onSaved={vi.fn()}
      />,
    );
    const dialog = await screen.findByRole("dialog");
    fireEvent.change(dialog.querySelector("input:not([type='hidden'])")!, {
      target: { value: "Item" },
    });
    const inputs = dialog.querySelectorAll("input:not([type='hidden'])");
    fireEvent.change(inputs[1]!, { target: { value: "42" } });
    fireEvent.click(within(dialog).getByRole("button", { name: "Select date" }));
    fireEvent.click(await screen.findByRole("button", { name: "Today" }));
    fireEvent.click(within(dialog).getByRole("switch", {
      name: "Record money movement in this account",
    }));
    fireEvent.click(within(dialog).getByRole("button", { name: "Save" }));

    await waitFor(() => expect(api.createDebt).toHaveBeenCalledWith("bot",
      expect.objectContaining({ recordTransaction: false })));
  });

  it("shows a loading alert until debt creation finishes", async () => {
    let finish!: (value: ConsumerFinanceDebt) => void;
    api.createDebt.mockImplementation(() => new Promise((resolve) => { finish = resolve; }));
    wrapper(
      <FinanceDebtEditor
        botId="bot" editing={null} locale="en" timezone="UTC"
        onClose={vi.fn()} onSaved={vi.fn()}
      />,
    );
    const dialog = await screen.findByRole("dialog");
    const inputs = dialog.querySelectorAll("input:not([type='hidden'])");
    fireEvent.change(inputs[0]!, { target: { value: "Item" } });
    fireEvent.change(inputs[1]!, { target: { value: "42" } });
    fireEvent.click(within(dialog).getByRole("button", { name: "Select date" }));
    fireEvent.click(await screen.findByRole("button", { name: "Today" }));
    fireEvent.click(within(dialog).getByRole("button", { name: "Save" }));
    await waitFor(() => expect(api.createDebt).toHaveBeenCalledOnce());
    expect(within(dialog).getByRole("status")).toHaveTextContent("Saving");
    expect(within(dialog).getByRole("button", { name: "Saving…" })).toBeDisabled();
    finish(debt);
    await waitFor(() => expect(within(dialog).queryByRole("status")).not.toBeInTheDocument());
  });

  it("updates a debt without changing its existing relation defaults", async () => {
    api.updateDebt.mockResolvedValue({ ...debt, name: "Alex R." });
    wrapper(
      <FinanceDebtEditor
        botId="bot"
        editing={debt}
        locale="en"
        timezone="UTC"
        onClose={vi.fn()}
        onSaved={vi.fn()}
      />,
    );
    const dialog = await screen.findByRole("dialog");
    fireEvent.change(
      dialog.querySelectorAll("input:not([type='hidden'])")[0]!,
      {
        target: { value: "Alex R." },
      },
    );
    fireEvent.click(within(dialog).getByRole("button", { name: "Save" }));

    await waitFor(() =>
      expect(api.updateDebt).toHaveBeenCalledWith("bot", "debt", {
        direction: "I_OWE",
        name: "Alex R.",
        amount: "42",
        accountId: "cash",
        dueDate: "2026-09-12",
        note: "Dinner",
      }),
    );
  });

  it("starts regular-payment references together and creates the exact input", async () => {
    let resolveAccounts!: (value: ConsumerFinanceAccount[]) => void;
    let resolveCategories!: (value: ConsumerFinanceCategory[]) => void;
    api.accounts.mockReturnValue(
      new Promise((resolve) => {
        resolveAccounts = resolve;
      }),
    );
    api.categories.mockReturnValue(
      new Promise((resolve) => {
        resolveCategories = resolve;
      }),
    );
    api.createRegularPayment.mockResolvedValue(payment);
    const onSaved = vi.fn();
    wrapper(
      <FinanceRegularPaymentEditor
        botId="bot"
        editing={null}
        locale="en"
        timezone="UTC"
        onClose={vi.fn()}
        onSaved={onSaved}
      />,
    );
    await waitFor(() => {
      expect(api.accounts).toHaveBeenCalledOnce();
      expect(api.categories).toHaveBeenCalledOnce();
    });
    resolveAccounts([account]);
    resolveCategories([category]);

    const dialog = await screen.findByRole("dialog");
    const inputs = dialog.querySelectorAll("input:not([type='hidden'])");
    fireEvent.change(inputs[0]!, { target: { value: "Rent" } });
    fireEvent.change(inputs[1]!, { target: { value: "100" } });
    fireEvent.change(inputs[2]!, { target: { value: "2" } });
    fireEvent.click(within(dialog).getByRole("button", { name: "month(s)" }));
    fireEvent.click(await screen.findByRole("option", { name: "week(s)" }));
    fireEvent.click(
      within(dialog).getByRole("button", { name: "Select date" }),
    );
    fireEvent.click(await screen.findByRole("button", { name: "Today" }));
    fireEvent.change(dialog.querySelector("textarea")!, {
      target: { value: "Flat" },
    });
    fireEvent.click(within(dialog).getByRole("button", { name: "Save" }));

    await waitFor(() =>
      expect(api.createRegularPayment).toHaveBeenCalledOnce(),
    );
    expect(api.createRegularPayment).toHaveBeenCalledWith("bot", {
      name: "Rent",
      emoji: "🔁",
      amount: "100",
      accountId: "cash",
      categoryId: null,
      recurrence: "WEEKLY",
      intervalCount: 2,
      nextPaymentDate: expect.stringMatching(/^\d{4}-\d{2}-\d{2}$/),
      note: "Flat",
      necessity: "DISCRETIONARY",
    });
    expect(onSaved).toHaveBeenCalledWith(payment);
  });

  it("updates a regular payment with its stored category and schedule", async () => {
    api.updateRegularPayment.mockResolvedValue({
      ...payment,
      name: "New rent",
    });
    wrapper(
      <FinanceRegularPaymentEditor
        botId="bot"
        editing={payment}
        locale="en"
        timezone="UTC"
        onClose={vi.fn()}
        onSaved={vi.fn()}
      />,
    );
    const dialog = await screen.findByRole("dialog");
    fireEvent.change(
      dialog.querySelectorAll("input:not([type='hidden'])")[0]!,
      {
        target: { value: "New rent" },
      },
    );
    fireEvent.click(within(dialog).getByRole("button", { name: "Save" }));

    await waitFor(() =>
      expect(api.updateRegularPayment).toHaveBeenCalledWith("bot", "rent", {
        name: "New rent",
        emoji: "🔁",
        amount: "100",
        accountId: "cash",
        categoryId: "home",
        recurrence: "MONTHLY",
        intervalCount: 1,
        nextPaymentDate: "2026-10-01",
        note: "Flat",
        necessity: "DISCRETIONARY",
      }),
    );
  });
});
