"use client";

import { useState } from "react";
import {
  useInfiniteQuery,
  useMutation,
  useQueryClient,
} from "@tanstack/react-query";
import {
  CalendarCheck,
  History,
  Pause,
  Pencil,
  Play,
  SlidersHorizontal,
  Trash2,
} from "lucide-react";
import type {
  ConsumerFinanceRegularPayment,
  ConsumerFinanceRegularPaymentConfirmation,
} from "@telegram-system/shared";
import {
  Button,
  Card,
  EmptyState,
  ErrorState,
  FinanceCardActionsMenu,
  LoadingState,
  Select,
} from "@consumer-finance/web/components/ui";
import { FinanceConfirmModal } from "@consumer-finance/web/components/shared/finance-confirm-modal";
import { FinanceRegularPaymentConfirm } from "@consumer-finance/web/components/obligations/finance-regular-payment-confirm";
import { FinanceRegularPaymentEditor } from "@consumer-finance/web/components/obligations/finance-regular-payment-editor";
import { FinanceRegularPaymentHistory } from "@consumer-finance/web/components/obligations/finance-regular-payment-history";
import { IconAvatar } from "@consumer-finance/web/components/ui/finance-icon-avatar";
import { consumerFinanceObligationsApi } from "@consumer-finance/web/lib/api/consumer-finance-obligations-api";
import { consumerFinanceKeys } from "@consumer-finance/web/lib/query/consumer-finance-query-keys";
import {
  invalidateConsumerFinanceLedgerReads,
  reconcileConsumerRegularPaymentPages,
} from "@consumer-finance/web/lib/cache/consumer-finance-obligations-cache";
import { reconcileConsumerTransactionCaches } from "@consumer-finance/web/lib/cache/consumer-finance-cache";
import { formatMoney } from "@consumer-finance/web/lib/formatters/consumer-finance-money";
import type { ConsumerFinanceRegularPaymentTarget } from "@consumer-finance/web/components/app/consumer-finance-navigation";
import { localizeFinanceCategory } from "@consumer-finance/web/components/catalog/finance-category-i18n";
import {
  financeIntlLocale,
  type FinanceLocale,
} from "@consumer-finance/web/components/i18n/core";
import {
  financeRegularPaymentRecurrenceLabel,
  financeRegularPaymentsCopy,
} from "@consumer-finance/web/components/i18n/regular-payments";

type Payment = ConsumerFinanceRegularPayment;
type ConfirmationRequest = {
  payment: Payment;
  expectedOccurrenceAt: string;
  expectedVersion: number;
  isEarlyPayment: boolean;
};

export function FinanceRegularPayments({
  botId,
  locale,
  timezone,
  target,
  targetMalformed = false,
}: {
  botId: string;
  locale: FinanceLocale;
  timezone: string;
  target?: ConsumerFinanceRegularPaymentTarget | null;
  targetMalformed?: boolean;
}) {
  const t = financeRegularPaymentsCopy(locale);
  const client = useQueryClient();
  const [status, setStatus] = useState<"ACTIVE" | "PAUSED" | "CANCELED">(
    "ACTIVE",
  );
  const [editing, setEditing] = useState<Payment | "create" | null>(null);
  const [history, setHistory] = useState<Payment | null>(null);
  const [canceling, setCanceling] = useState<Payment | null>(null);
  const [confirmation, setConfirmation] = useState<ConfirmationRequest | null>(
    null,
  );
  const [dismissedTarget, setDismissedTarget] = useState<string | null>(null);
  const targetKey = target
    ? `${target.regularPaymentId}:${target.occurrenceAt}:${target.expectedVersion}`
    : null;
  const targetLookup = Boolean(target && targetKey !== dismissedTarget);
  const pageLimit = targetLookup ? 1 : 30;
  const queryStatus = targetLookup ? "ACTIVE" : status;
  const payments = useInfiniteQuery({
    queryKey: consumerFinanceKeys.regularPayments(botId, {
      status: queryStatus,
      ...(targetLookup ? { id: target!.regularPaymentId } : {}),
      limit: pageLimit,
    }),
    initialPageParam: undefined as string | undefined,
    queryFn: ({ pageParam }) =>
      consumerFinanceObligationsApi.regularPayments(botId, {
        status: queryStatus,
        ...(targetLookup ? { id: target!.regularPaymentId } : {}),
        limit: pageLimit,
        cursor: pageParam,
      }),
    getNextPageParam: (page) => page.nextCursor ?? undefined,
  });
  const items = payments.data?.pages.flatMap((page) => page.items) ?? [];
  const targetPayment = target
    ? items.find((payment) => payment.id === target.regularPaymentId)
    : undefined;
  const targetConfirmation =
    target && targetKey !== dismissedTarget && targetPayment
      ? {
          payment: targetPayment,
          expectedOccurrenceAt: target.occurrenceAt,
          expectedVersion: target.expectedVersion,
          isEarlyPayment: false,
        }
      : null;
  const activeConfirmation = confirmation ?? targetConfirmation;
  const closeConfirmation = () => {
    if (targetKey) setDismissedTarget(targetKey);
    setConfirmation(null);
  };
  const statusAction = useMutation({
    mutationFn: ({
      payment,
      action,
    }: {
      payment: ConsumerFinanceRegularPayment;
      action: "pause" | "resume" | "cancel";
    }) =>
      action === "pause"
        ? consumerFinanceObligationsApi.pauseRegularPayment(botId, payment.id)
        : action === "resume"
          ? consumerFinanceObligationsApi.resumeRegularPayment(
              botId,
              payment.id,
            )
          : consumerFinanceObligationsApi.cancelRegularPayment(
              botId,
              payment.id,
            ),
    onSuccess: (payment) => {
      reconcileConsumerRegularPaymentPages(client, botId, payment);
      void client.invalidateQueries({
        queryKey: consumerFinanceKeys.regularPaymentRevisions(
          botId,
          payment.id,
        ),
      });
      setCanceling(null);
    },
  });
  const reconcile = (payment: Payment) => {
    reconcileConsumerRegularPaymentPages(client, botId, payment);
    void client.invalidateQueries({
      queryKey: consumerFinanceKeys.regularPaymentRevisions(botId, payment.id),
    });
    setEditing(null);
  };
  const reconcileConfirmation = (
    result: ConsumerFinanceRegularPaymentConfirmation,
  ) => {
    reconcileConsumerRegularPaymentPages(client, botId, result.regularPayment);
    reconcileConsumerTransactionCaches(
      client,
      botId,
      result.transaction,
      timezone,
    );
    void invalidateConsumerFinanceLedgerReads(client, botId);
  };
  return (
    <div className="space-y-4">
      <div className="space-y-3">
        <Button className="w-full" onClick={() => setEditing("create")}>
          {t.addRegularPayment}
        </Button>
        <div className="w-full">
          <label className="mb-1 block text-sm text-neutral-300">
            {t.status}
          </label>
          <Select
            uiLocale={locale}
            value={status}
            onChange={(event) => setStatus(event.target.value as typeof status)}
          >
            <option value="ACTIVE">🟢 {t.active}</option>
            <option value="PAUSED">⏸️ {t.paused}</option>
            <option value="CANCELED">⛔ {t.canceled}</option>
          </Select>
        </div>
      </div>
      {targetMalformed ? (
        <p role="alert" className="text-sm text-amber-300">
          {t.malformedTarget}
        </p>
      ) : target && !targetPayment && payments.isSuccess ? (
        <p role="status" className="text-sm text-amber-300">
          {t.targetNotFound}
        </p>
      ) : null}
      {payments.isLoading ? (
        <LoadingState text={t.loadingPayments} />
      ) : payments.isError ? (
        <div className="space-y-3">
          <ErrorState text={t.paymentLoadError} />
          <Button onClick={() => payments.refetch()}>{t.retry}</Button>
        </div>
      ) : items.length ? (
        <div className="grid gap-3 lg:grid-cols-2">
          {items.map((payment) => (
            <RegularPaymentCard
              key={payment.id}
              payment={payment}
              locale={locale}
              busy={statusAction.isPending}
              onEdit={() => setEditing(payment)}
              onHistory={() => setHistory(payment)}
              onPause={() => statusAction.mutate({ payment, action: "pause" })}
              onResume={() =>
                statusAction.mutate({ payment, action: "resume" })
              }
              onCancel={() => setCanceling(payment)}
              onConfirm={(isEarlyPayment) =>
                setConfirmation({
                  payment,
                  expectedOccurrenceAt: payment.nextOccurrenceAt,
                  expectedVersion: payment.version,
                  isEarlyPayment,
                })
              }
            />
          ))}
        </div>
      ) : (
        <EmptyState text={t.noPayments} />
      )}
      {payments.hasNextPage ? (
        <Button
          className="w-full"
          variant="secondary"
          disabled={payments.isFetchingNextPage}
          onClick={() => payments.fetchNextPage()}
        >
          {payments.isFetchingNextPage ? t.loading : t.loadMore}
        </Button>
      ) : null}
      {editing ? (
        <FinanceRegularPaymentEditor
          key={editing === "create" ? "create" : editing.id}
          botId={botId}
          editing={editing === "create" ? null : editing}
          locale={locale}
          timezone={timezone}
          onClose={() => setEditing(null)}
          onSaved={reconcile}
        />
      ) : null}
      {history ? (
        <FinanceRegularPaymentHistory
          key={history.id}
          botId={botId}
          payment={history}
          locale={locale}
          timezone={timezone}
          onClose={() => setHistory(null)}
        />
      ) : null}
      {activeConfirmation ? (
        <FinanceRegularPaymentConfirm
          key={`${activeConfirmation.payment.id}:${activeConfirmation.expectedOccurrenceAt}:${activeConfirmation.isEarlyPayment}`}
          botId={botId}
          payment={activeConfirmation.payment}
          expectedOccurrenceAt={activeConfirmation.expectedOccurrenceAt}
          expectedVersion={activeConfirmation.expectedVersion}
          isEarlyPayment={activeConfirmation.isEarlyPayment}
          locale={locale}
          timezone={timezone}
          onClose={closeConfirmation}
          onConfirmed={reconcileConfirmation}
          onApplied={reconcile}
        />
      ) : null}
      <FinanceConfirmModal
        key={canceling?.id ?? "cancel-regular-payment"}
        open={!!canceling}
        locale={locale}
        entityName={canceling?.name ?? ""}
        actionLabel={t.cancelPayment}
        description={t.cancelDescription}
        onClose={() => setCanceling(null)}
        onConfirm={() =>
          canceling
            ? statusAction.mutateAsync({ payment: canceling, action: "cancel" })
            : undefined
        }
      />
      {statusAction.isError ? <ErrorState text={t.actionError} /> : null}
    </div>
  );
}

function RegularPaymentCard({
  payment,
  locale,
  busy,
  onEdit,
  onHistory,
  onPause,
  onResume,
  onCancel,
  onConfirm,
}: {
  payment: Payment;
  locale: FinanceLocale;
  busy: boolean;
  onEdit: () => void;
  onHistory: () => void;
  onPause: () => void;
  onResume: () => void;
  onCancel: () => void;
  onConfirm: (isEarlyPayment: boolean) => void;
}) {
  const t = financeRegularPaymentsCopy(locale);
  const recurrence = financeRegularPaymentRecurrenceLabel(
    payment.recurrence,
    payment.intervalCount ?? 1,
    locale,
  );
  return (
    <Card className={payment.isDue ? "border-amber-700" : ""}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 gap-3">
          <IconAvatar
            icon={
              payment.category?.iconPresentation ??
              payment.iconPresentation ??
              payment.account.iconPresentation
            }
            label={payment.category?.name ?? payment.name}
            size="sm"
            bordered={false}
          />
          <div className="min-w-0">
            <h2 className="truncate font-medium">{payment.name}</h2>
            <p className="text-xs text-neutral-400">{recurrence}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <strong className="shrink-0 tabular-nums">
            {formatMoney(payment.amount, payment.currency, "symbol")}
          </strong>
          <FinanceCardActionsMenu
            label={t.actions}
            actions={[
              ...(payment.status !== "CANCELED"
                ? [
                    {
                      label: t.edit,
                      icon: <Pencil size={16} />,
                      onSelect: onEdit,
                    },
                  ]
                : []),
              ...(payment.status === "ACTIVE"
                ? [
                    {
                      label: t.payEarly,
                      icon: <CalendarCheck size={16} />,
                      onSelect: () => onConfirm(true),
                      disabled: busy,
                    },
                    {
                      label: t.changeAmount,
                      icon: <SlidersHorizontal size={16} />,
                      onSelect: () => onConfirm(false),
                      disabled: busy,
                    },
                    {
                      label: t.pause,
                      icon: <Pause size={16} />,
                      onSelect: onPause,
                      disabled: busy,
                    },
                  ]
                : payment.status === "PAUSED"
                  ? [
                      {
                        label: t.resume,
                        icon: <Play size={16} />,
                        onSelect: onResume,
                        disabled: busy,
                      },
                    ]
                  : []),
              {
                label: t.history,
                icon: <History size={16} />,
                onSelect: onHistory,
              },
              ...(payment.status !== "CANCELED"
                ? [
                    {
                      label: t.cancelPayment,
                      icon: <Trash2 size={16} />,
                      onSelect: onCancel,
                      disabled: busy,
                      danger: true,
                    },
                  ]
                : []),
            ]}
          />
        </div>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-3 text-sm text-neutral-400">
        <div>
          <p className="text-xs text-neutral-500">{t.nextPayment}</p>
          <p className={payment.isDue ? "font-medium text-amber-300" : ""}>
            {payment.isDue ? `${t.due} · ` : ""}
            {new Intl.DateTimeFormat(financeIntlLocale(locale), {
              timeZone: payment.scheduleTimezone,
            }).format(new Date(payment.nextOccurrenceAt))}
          </p>
        </div>
        <div>
          <p className="text-xs text-neutral-500">{t.lastPayment}</p>
          <p>
            {payment.lastPaymentAt
              ? new Intl.DateTimeFormat(financeIntlLocale(locale), {
                  timeZone: payment.scheduleTimezone,
                }).format(new Date(payment.lastPaymentAt))
              : t.noPaymentYet}
          </p>
        </div>
      </div>
      {payment.category ? (
        <p className="mt-1 flex items-center gap-1 text-xs text-neutral-500">
          <IconAvatar
            icon={payment.category.iconPresentation}
            label={payment.category.name}
            size="xs"
          />
          {localizeFinanceCategory(
            payment.category.name,
            payment.category.key,
            locale,
          )}
        </p>
      ) : null}
      {payment.note ? (
        <p className="mt-2 line-clamp-2 text-sm text-neutral-400">
          {payment.note}
        </p>
      ) : null}
      {payment.status === "ACTIVE" && payment.isDue ? (
        <div className="mt-4 flex flex-wrap gap-2">
          <Button disabled={busy} onClick={() => onConfirm(false)}>
            {t.confirmPayment}
          </Button>
        </div>
      ) : null}
    </Card>
  );
}
