"use client";

import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import type {
  ConsumerFinanceAccount,
  ConsumerFinanceAccountType,
} from "@telegram-system/shared";
import {
  Button,
  Card,
  ErrorState,
  FormField,
  Input,
  LoadingState,
  Select,
} from "@consumer-finance/web/components/ui";
import { consumerFinanceLedgerApi } from "@consumer-finance/web/lib/api/consumer-finance-ledger-api";
import { consumerFinanceKeys } from "@consumer-finance/web/lib/query/consumer-finance-query-keys";
import { patchConsumerFinanceAccountCache } from "@consumer-finance/web/lib/cache/consumer-finance-cache";
import { type FinanceLocale } from "@consumer-finance/web/components/i18n/core";
import { financeAccountsCopy } from "@consumer-finance/web/components/i18n/accounts";
import { IconPicker } from "@consumer-finance/web/components/ui/finance-icon-picker";
import { FinanceCurrencySelect } from "@consumer-finance/web/components/ui/finance-currency-select";

const TYPES: ConsumerFinanceAccountType[] = [
  "CASH",
  "CARD",
  "SAVINGS",
  "OTHER",
];

export function FinanceAccountEditorScreen({
  botId,
  defaultCurrency,
  locale,
  accountId,
  onBack,
}: {
  botId: string;
  defaultCurrency: string;
  locale: FinanceLocale;
  accountId: string;
  onBack: () => void;
}) {
  const t = financeAccountsCopy(locale);
  const creating = accountId === "create";
  const accounts = useQuery({
    queryKey: consumerFinanceKeys.accounts(botId),
    queryFn: () => consumerFinanceLedgerApi.accounts(botId),
    enabled: !creating,
  });
  if (!creating && accounts.isLoading)
    return <LoadingState text={t.loadingReferences} />;
  if (!creating && accounts.isError)
    return (
      <div className="space-y-3">
        <ErrorState text={t.referencesUnavailable} />
        <Button onClick={() => accounts.refetch()}>{t.retry}</Button>
      </div>
    );
  const account = accounts.data?.find((item) => item.id === accountId);
  if (!creating && !account)
    return (
      <Card className="space-y-3">
        <ErrorState text={t.referencesUnavailable} />
        <Button variant="secondary" onClick={onBack}>
          {t.accounts}
        </Button>
      </Card>
    );
  return (
    <FinanceAccountEditor
      botId={botId}
      defaultCurrency={defaultCurrency}
      locale={locale}
      account={account}
      creating={creating}
      onBack={onBack}
    />
  );
}

export function FinanceAccountEditor({
  botId,
  defaultCurrency,
  locale,
  account,
  creating,
  onBack,
}: {
  botId: string;
  defaultCurrency: string;
  locale: FinanceLocale;
  account?: ConsumerFinanceAccount;
  creating: boolean;
  onBack: () => void;
}) {
  const t = financeAccountsCopy(locale);
  const client = useQueryClient();
  const [name, setName] = useState(account?.name ?? "");
  const [currency, setCurrency] = useState(
    account?.currency ?? defaultCurrency,
  );
  const [openingBalance, setOpeningBalance] = useState(
    account?.openingBalance ?? "0",
  );
  const [type, setType] = useState<ConsumerFinanceAccountType>(
    account?.type ?? "CARD",
  );
  // Keep an existing image untouched until the user explicitly picks a new icon.
  // This avoids needless writes and keeps historic image sources immutable.
  const [iconSource, setIconSource] = useState<string | null | undefined>(
    account?.iconPresentation.type === "unicode"
      ? account.iconPresentation.value
      : creating
        ? "💳"
        : undefined,
  );
  const mutation = useMutation({
    mutationFn: () =>
      creating
        ? consumerFinanceLedgerApi.createAccount(botId, {
            name: name.trim(),
            emoji: iconSource,
            type,
            currency,
            openingBalance,
          })
        : consumerFinanceLedgerApi.updateAccount(botId, account!.id, {
            name: name.trim(),
            type,
            currency,
            ...(iconSource === undefined ? {} : { emoji: iconSource }),
          }),
    onSuccess: (saved) => {
      patchConsumerFinanceAccountCache(client, botId, saved);
      const derivedInvalidations = [
        client.invalidateQueries({
          queryKey: consumerFinanceKeys.dashboard(botId),
        }),
        client.invalidateQueries({
          queryKey: consumerFinanceKeys.analyticsRoot(botId),
        }),
      ];
      if (!creating) {
        derivedInvalidations.push(
          client.invalidateQueries({
            queryKey: consumerFinanceKeys.transactionLists(botId),
          }),
          client.invalidateQueries({
            queryKey: consumerFinanceKeys.transferLists(botId),
          }),
        );
      }
      void Promise.all(derivedInvalidations);
      onBack();
    },
  });

  return (
    <div className="space-y-4">
      <Button variant="secondary" onClick={onBack}>
        <ArrowLeft size={16} aria-hidden="true" />
        {t.accounts}
      </Button>
      <Card className="mx-auto max-w-2xl">
        <h2 className="text-lg font-semibold">
          {creating ? t.addAccount : t.editAccount}
        </h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <IconPicker
              botId={botId}
              uiLocale={locale}
              source={
                iconSource ??
                (account?.iconPresentation.type === "image"
                  ? `image:${account.iconPresentation.url}`
                  : null)
              }
              onChange={setIconSource}
              buttonLabel={name.trim() || t.accountName}
            />
          </div>
          <FormField label={t.accountName}>
            <Input
              autoFocus
              value={name}
              onChange={(event) => setName(event.target.value)}
            />
          </FormField>
          <FormField label={t.accountType}>
            <Select
              uiLocale={locale}
              value={type}
              onChange={(event) =>
                setType(event.target.value as ConsumerFinanceAccountType)
              }
            >
              {TYPES.map((value) => (
                <option key={value} value={value}>
                  {
                    t[
                      value.toLowerCase() as
                        | "cash"
                        | "card"
                        | "savings"
                        | "other"
                    ]
                  }
                </option>
              ))}
            </Select>
          </FormField>
          <FormField label={t.currency}>
            <FinanceCurrencySelect
              value={currency}
              onChange={setCurrency}
              locale={locale}
            />
          </FormField>
          {creating ? (
            <>
              <FormField label={t.openingBalance}>
                <Input
                  inputMode="decimal"
                  suffix={currency}
                  value={openingBalance}
                  onChange={(event) => setOpeningBalance(event.target.value)}
                />
              </FormField>
            </>
          ) : null}
          <Button
            className="w-full sm:col-span-2"
            disabled={
              !name.trim() ||
              !currency.trim() ||
              !Number.isFinite(Number(openingBalance)) ||
              mutation.isPending
            }
            onClick={() => mutation.mutate()}
          >
            {mutation.isPending ? t.saving : t.save}
          </Button>
          {mutation.isError ? (
            <p className="text-sm text-rose-300 sm:col-span-2">
              {t.accountSaveError}
            </p>
          ) : null}
        </div>
      </Card>
    </div>
  );
}
