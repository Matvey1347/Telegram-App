import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  fireEvent,
  render,
  screen,
  waitFor,
  within,
} from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import type { ConsumerFinanceCategory } from "@telegram-system/shared";
import { FinanceCategories } from "@consumer-finance/web/components/catalog/finance-categories";

const apiMocks = vi.hoisted(() => ({
  categories: vi.fn(),
  createCategory: vi.fn(),
  updateCategory: vi.fn(),
  archiveCategory: vi.fn(),
  restoreCategory: vi.fn(),
}));

vi.mock("@consumer-finance/web/lib/api/consumer-finance-api", () => ({
  consumerFinanceApi: apiMocks,
}));

const category: ConsumerFinanceCategory = {
  id: "category-1",
  name: "Coffee",
  iconPresentation: { type: "unicode", value: "☕" },
  type: "EXPENSE",
  parentId: null,
  archivedAt: null,
};

function renderCategories(locale: "en" | "uk" = "en") {
  return render(
    <QueryClientProvider
      client={
        new QueryClient({ defaultOptions: { queries: { retry: false } } })
      }
    >
      <FinanceCategories botId="bot" locale={locale} />
    </QueryClientProvider>,
  );
}

beforeEach(() => {
  vi.clearAllMocks();
  apiMocks.categories.mockResolvedValue([category]);
});

describe("FinanceCategories CRUD", () => {
  it("lists and creates a category through the API", async () => {
    apiMocks.createCategory.mockResolvedValue({ ...category, id: "new" });
    renderCategories();

    expect(await screen.findByText("Coffee")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Add category" }));
    fireEvent.change(screen.getByRole("textbox"), {
      target: { value: "Dining" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Save" }));

    await waitFor(() => expect(apiMocks.createCategory).toHaveBeenCalledOnce());
    expect(apiMocks.createCategory).toHaveBeenCalledWith("bot", {
      name: "Dining",
      emoji: "🏷️",
      type: "EXPENSE",
      parentId: undefined,
      necessity: "DISCRETIONARY",
    });
  });

  it("updates an existing category", async () => {
    apiMocks.updateCategory.mockResolvedValue({ ...category, name: "Cafe" });
    renderCategories();

    fireEvent.click(
      await screen.findByRole("button", { name: "Edit category: Coffee" }),
    );
    fireEvent.change(screen.getByDisplayValue("Coffee"), {
      target: { value: "Cafe" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Save" }));

    await waitFor(() => expect(apiMocks.updateCategory).toHaveBeenCalledOnce());
    expect(apiMocks.updateCategory).toHaveBeenCalledWith("bot", "category-1", {
      name: "Cafe",
      emoji: "☕",
      type: "EXPENSE",
      parentId: null,
      necessity: "DISCRETIONARY",
    });
  });

  it("uses the shared localized icon picker with a populated emoji grid", async () => {
    renderCategories("uk");

    fireEvent.click(
      await screen.findByRole("button", {
        name: "Редагувати категорію: Coffee",
      }),
    );
    fireEvent.click(screen.getByRole("button", { name: "Змінити емодзі" }));

    expect(
      await screen.findByRole("button", { name: "Люди" }),
    ).toBeInTheDocument();
    expect(await screen.findByTitle("alien")).toHaveTextContent("👽");
    expect(screen.queryByText("People")).not.toBeInTheDocument();
  });

  it("archives after explicit confirmation", async () => {
    apiMocks.archiveCategory.mockResolvedValue({
      ...category,
      archivedAt: "2026-08-21T00:00:00.000Z",
    });
    renderCategories();

    fireEvent.click(
      await screen.findByRole("button", { name: "Archive category: Coffee" }),
    );
    fireEvent.click(screen.getByRole("button", { name: "Archive" }));

    await waitFor(() =>
      expect(apiMocks.archiveCategory).toHaveBeenCalledOnce(),
    );
    expect(apiMocks.archiveCategory).toHaveBeenCalledWith("bot", "category-1");
  });

  it("nests multilevel children inside their parent container exactly once", async () => {
    apiMocks.categories.mockResolvedValue([
      category,
      { ...category, id: "child", name: "Cafe", parentId: category.id },
      { ...category, id: "grandchild", name: "Latte", parentId: "child" },
    ]);
    const { container } = renderCategories();

    await screen.findByText("Latte");
    const parent = container.querySelector('[data-category-id="category-1"]')!;
    const child = parent.querySelector('[data-category-id="child"]')!;
    expect(child).toBeInTheDocument();
    expect(
      child.querySelector('[data-category-id="grandchild"]'),
    ).toBeInTheDocument();
    expect(
      child.querySelector('[data-category-connector="child"]'),
    ).toBeInTheDocument();
    expect(
      child.querySelector('[data-category-connector="grandchild"]'),
    ).toBeInTheDocument();
    expect(
      container.querySelectorAll('[data-category-id="child"]'),
    ).toHaveLength(1);
    expect(apiMocks.categories).toHaveBeenCalledOnce();
  });

  it("shows categories with invalid parent links as ordinary root rows", async () => {
    apiMocks.categories.mockResolvedValue([
      { ...category, id: "orphan", name: "Orphan", parentId: "missing" },
      { ...category, id: "cycle-a", name: "Cycle A", parentId: "cycle-b" },
      { ...category, id: "cycle-b", name: "Cycle B", parentId: "cycle-a" },
    ]);
    const { container } = renderCategories();

    expect(await screen.findByText("Orphan")).toBeInTheDocument();
    expect(screen.getByText("Cycle A")).toBeInTheDocument();
    expect(screen.getByText("Cycle B")).toBeInTheDocument();
    expect(
      screen.queryByRole("region", { name: "Legacy categories" }),
    ).not.toBeInTheDocument();
    for (const id of ["orphan", "cycle-a", "cycle-b"]) {
      expect(
        container.querySelectorAll(`[data-category-id="${id}"]`),
      ).toHaveLength(1);
    }
  });

  it("filters archived rows by type and restores a selected category", async () => {
    const archived = {
      ...category,
      id: "archived",
      name: "Old category",
      archivedAt: "2026-08-01T00:00:00.000Z",
    };
    apiMocks.categories.mockResolvedValue([
      category,
      archived,
    ]);
    apiMocks.restoreCategory.mockResolvedValue({ ...archived, archivedAt: null });
    const { container } = renderCategories();

    await screen.findByText("Coffee");
    expect(screen.queryByText("Old category")).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Archived" }));
    expect(await screen.findByText("Old category")).toBeInTheDocument();
    expect(
      container.querySelector('[data-archived-category-id="archived"]'),
    ).toBeInTheDocument();
    expect(
      container.querySelector('[data-category-id="archived"]'),
    ).not.toBeInTheDocument();
    fireEvent.click(
      screen.getByRole("button", { name: "Restore category" }),
    );
    await waitFor(() =>
      expect(apiMocks.restoreCategory).toHaveBeenCalledWith("bot", "archived"),
    );
  });

  it("excludes self and descendants from the editable parent relationship", async () => {
    apiMocks.categories.mockResolvedValue([
      category,
      { ...category, id: "child", name: "Cafe", parentId: category.id },
      { ...category, id: "grandchild", name: "Latte", parentId: "child" },
      { ...category, id: "other", name: "Groceries", parentId: null },
    ]);
    renderCategories();

    fireEvent.click(
      await screen.findByRole("button", { name: "Edit category: Coffee" }),
    );
    const dialog = screen.getByRole("dialog");
    fireEvent.click(
      within(dialog).getByRole("button", { name: "No parent category" }),
    );

    expect(
      within(dialog).queryByRole("option", { name: "Coffee" }),
    ).not.toBeInTheDocument();
    expect(
      within(dialog).queryByRole("option", { name: "Cafe" }),
    ).not.toBeInTheDocument();
    expect(
      within(dialog).queryByRole("option", { name: "Latte" }),
    ).not.toBeInTheDocument();
    expect(
      within(dialog).getByRole("option", { name: /Groceries/ }),
    ).toBeInTheDocument();
    expect(apiMocks.categories).toHaveBeenCalledOnce();
  });
});
