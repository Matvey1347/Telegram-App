import { render } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { FinancePlanVisual } from "@consumer-finance/web/components/planning/finance-plan-visual";

describe("FinancePlanVisual", () => {
  it.each([
    ["FREE", "daily-ledger"],
    ["PRO", "automated-ledger"],
    ["ULTIMATE", "finance-statement"],
  ] as const)("renders a dedicated detailed %s scene", (tier, scene) => {
    const { container } = render(<FinancePlanVisual tier={tier} />);

    expect(
      container.querySelector(`[data-finance-plan-visual='${tier}']`),
    ).toBeInTheDocument();
    expect(
      container.querySelector(`[data-finance-plan-scene='${scene}']`),
    ).toBeInTheDocument();
    expect(container.querySelector("svg")).toBeNull();
    expect(container).toHaveTextContent("₴");
  });
});
