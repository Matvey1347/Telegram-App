"use client";

import {
  Children,
  type CSSProperties,
  type PropsWithChildren,
  forwardRef,
  isValidElement,
  useEffect,
  useId,
  useRef,
  useState,
} from "react";
import {
  ArrowDown,
  ArrowLeftRight,
  ArrowUp,
  Check,
  ChevronDown,
  Eye,
  EyeOff,
} from "lucide-react";
import type { FinanceLocale } from "@consumer-finance/web/components/i18n/core";
import { financeUiTokens } from "@consumer-finance/web/components/ui/finance-ui-tokens";

const selectCopy = {
  en: { select: "Select", search: "Search…", empty: "No options found" },
  uk: { select: "Оберіть", search: "Пошук…", empty: "Нічого не знайдено" },
  ru: { select: "Выберите", search: "Поиск…", empty: "Ничего не найдено" },
} as const;

const optionToneByValue: Record<string, string> = {
  expense: "text-rose-300",
  income: "text-emerald-300",
  transfer: "text-sky-300",
  debt: "text-amber-300",
  debt_repayment: "text-amber-300",
  investment: "text-violet-300",
  investment_contribution: "text-violet-300",
  investment_return: "text-violet-300",
};

export function Button({
  variant = "primary",
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "outline" | "cancel" | "danger";
}) {
  const styles = {
    primary: "bg-[#194d38] text-white hover:bg-[#113e30]",
    secondary:
      "border border-[#e4ebe3] bg-[#edf3eb] text-[#18382d] hover:bg-[#e4f4c9]",
    outline:
      "border border-[#cbdcc7] bg-[#edf3eb] text-[#18382d] hover:bg-[#e4f4c9]",
    cancel: "bg-[#edf3eb] text-[#18382d] hover:bg-[#e4f4c9]",
    danger: "bg-[#fff0ec] text-[#a74343] hover:bg-[#ffe3dc]",
  }[variant];
  return (
    <button
      {...props}
      className={`inline-flex min-h-12 cursor-pointer items-center justify-center gap-2 whitespace-nowrap rounded-[17px] px-4 py-2 text-sm font-semibold disabled:opacity-50 ${styles} ${financeUiTokens.focus} ${props.className ?? ""}`}
    />
  );
}

export const Input = forwardRef<
  HTMLInputElement,
  React.InputHTMLAttributes<HTMLInputElement> & { suffix?: React.ReactNode }
>(function Input({ className, type, suffix, ...props }, ref) {
  const [passwordVisible, setPasswordVisible] = useState(false);
  const isPassword = type === "password";
  const input = (
    <input
      {...props}
      ref={ref}
      type={isPassword && passwordVisible ? "text" : type}
      className={`w-full px-3 py-2 text-sm ${financeUiTokens.control} ${isPassword || suffix ? "pr-16" : ""} ${className ?? ""}`}
    />
  );
  if (!isPassword) {
    if (!suffix) return input;
    return (
      <span className="relative block">
        {input}
        <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 rounded-md bg-neutral-800 px-2 py-1 text-xs font-medium text-neutral-300">
          {suffix}
        </span>
      </span>
    );
  }
  return (
    <span className="relative block">
      {input}
      <button
        type="button"
        disabled={props.disabled}
        onClick={() => setPasswordVisible((visible) => !visible)}
        className={`absolute right-1 top-1/2 inline-flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-md text-neutral-400 transition hover:bg-neutral-800 hover:text-white disabled:pointer-events-none disabled:opacity-50 ${financeUiTokens.focus}`}
        aria-label={passwordVisible ? "Hide password" : "Show password"}
        aria-pressed={passwordVisible}
      >
        {passwordVisible ? <EyeOff size={17} /> : <Eye size={17} />}
      </button>
    </span>
  );
});

export const Textarea = forwardRef<
  HTMLTextAreaElement,
  React.TextareaHTMLAttributes<HTMLTextAreaElement>
>(function Textarea({ className, ...props }, ref) {
  return (
    <textarea
      {...props}
      ref={ref}
      className={`w-full px-3 py-2 text-sm ${financeUiTokens.control} ${className ?? ""}`}
    />
  );
});

function OptionIcon({
  emoji,
  fallback,
  symbol,
  large = false,
}: {
  emoji?: string;
  fallback?: string;
  symbol?: "expense" | "income" | "transfer";
  large?: boolean;
}) {
  const Symbol =
    symbol === "expense"
      ? ArrowDown
      : symbol === "income"
        ? ArrowUp
        : symbol === "transfer"
          ? ArrowLeftRight
          : null;
  if (Symbol) {
    return (
      <Symbol
        size={large ? 22 : 18}
        className="shrink-0 text-sky-300"
        aria-hidden="true"
      />
    );
  }
  if (emoji) {
    return (
      <span
        className={`flex shrink-0 items-center justify-center leading-none ${large ? "h-7 w-7 text-[22px]" : "h-5 w-5 text-[15px]"}`}
      >
        {emoji}
      </span>
    );
  }
  if (!fallback) return null;
  return (
    <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-md border border-neutral-700 bg-neutral-800 text-[11px] font-semibold text-neutral-200">
      {fallback.trim().slice(0, 1).toUpperCase()}
    </span>
  );
}

export function Select(
  props: React.SelectHTMLAttributes<HTMLSelectElement> & {
    uiLocale?: FinanceLocale;
    triggerAriaLabel?: string;
    iconOnly?: boolean;
    hideSelectedOption?: boolean;
    largeOptionIcons?: boolean;
  },
) {
  const copy = selectCopy[props.uiLocale ?? "en"];
  const options = Children.toArray(props.children)
    .filter(isValidElement)
    .map((child, index) => {
      const optionProps =
        child.props as React.OptionHTMLAttributes<HTMLOptionElement>;
      const label = Children.toArray(optionProps.children)
        .filter((node) => typeof node === "string" || typeof node === "number")
        .join("");
      const value = String(optionProps.value ?? label);
      const symbol = optionProps[
        "data-icon-symbol" as keyof typeof optionProps
      ] as "expense" | "income" | "transfer" | undefined;
      return {
        key: `${value}-${index}`,
        value,
        label,
        disabled: Boolean(optionProps.disabled),
        hidden: Boolean(optionProps.hidden),
        emoji: optionProps["data-icon-emoji" as keyof typeof optionProps] as
          | string
          | undefined,
        fallback: optionProps[
          "data-icon-fallback" as keyof typeof optionProps
        ] as string | undefined,
        symbol,
        meta: optionProps["data-option-meta" as keyof typeof optionProps] as
          | string
          | undefined,
        className:
          symbol ? "text-white" : optionProps.className || optionToneByValue[value.toLowerCase()] || "",
      };
    });
  const [internalValue, setInternalValue] = useState(
    String(props.defaultValue ?? options[0]?.value ?? ""),
  );
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [menuPosition, setMenuPosition] = useState<CSSProperties>();
  const rootRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const listboxId = useId();
  const controlled = props.value !== undefined;
  const currentValue = String((controlled ? props.value : internalValue) ?? "");
  const selected = options.find((option) => option.value === currentValue);
  const menuOptions = options.filter(
    (option) =>
      !option.hidden &&
      (!props.hideSelectedOption || option.value !== currentValue),
  );
  const showSearch = menuOptions.length > 5;
  const filtered = showSearch
    ? menuOptions.filter((option) =>
        `${option.label} ${option.meta ?? ""} ${option.value}`
          .toLocaleLowerCase()
          .includes(search.trim().toLocaleLowerCase()),
      )
    : menuOptions;

  const updateMenuPosition = () => {
    const rect = triggerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const viewportPadding = 8;
    const preferredHeight = 264;
    const spaceBelow = window.innerHeight - rect.bottom - viewportPadding;
    const spaceAbove = rect.top - viewportPadding;
    const openUp =
      spaceBelow < Math.min(preferredHeight, spaceAbove) && spaceAbove > 120;
    setMenuPosition({
      left: rect.left,
      width: rect.width,
      ...(openUp
        ? { bottom: window.innerHeight - rect.top + 4 }
        : { top: rect.bottom + 4 }),
      maxHeight: Math.max(
        120,
        Math.min(preferredHeight, openUp ? spaceAbove : spaceBelow),
      ),
    });
  };

  const toggleMenu = () => {
    if (!open) updateMenuPosition();
    setOpen((value) => !value);
  };

  useEffect(() => {
    const close = (event: PointerEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) {
        setOpen(false);
        setSearch("");
      }
    };
    document.addEventListener("pointerdown", close);
    return () => document.removeEventListener("pointerdown", close);
  }, []);

  useEffect(() => {
    if (!open) return;
    updateMenuPosition();
    window.addEventListener("resize", updateMenuPosition);
    document.addEventListener("scroll", updateMenuPosition, true);
    return () => {
      window.removeEventListener("resize", updateMenuPosition);
      document.removeEventListener("scroll", updateMenuPosition, true);
    };
  }, [open]);

  const commit = (value: string) => {
    if (!controlled) setInternalValue(value);
    props.onChange?.({
      target: { name: props.name, value },
    } as React.ChangeEvent<HTMLSelectElement>);
    setOpen(false);
    setSearch("");
    window.requestAnimationFrame(() => triggerRef.current?.focus());
  };
  const optionButtons = () =>
    Array.from(
      rootRef.current?.querySelectorAll<HTMLButtonElement>(
        "[role='option']:not(:disabled)",
      ) ?? [],
    );
  const focusOption = (edge: "first" | "last") => {
    window.requestAnimationFrame(() => {
      const buttons = optionButtons();
      buttons[edge === "first" ? 0 : buttons.length - 1]?.focus();
    });
  };

  return (
    <div ref={rootRef} className="relative">
      <button
        ref={triggerRef}
        type="button"
        disabled={props.disabled}
        aria-label={props.triggerAriaLabel}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={listboxId}
        onClick={toggleMenu}
        onKeyDown={(event) => {
          if (event.key === "ArrowDown" && !open) {
            event.preventDefault();
            updateMenuPosition();
            setOpen(true);
            focusOption("first");
          } else if (event.key === "Escape") {
            setOpen(false);
            setSearch("");
          }
        }}
        className={`flex w-full items-center justify-between px-3 py-2 text-left text-sm disabled:opacity-50 ${props.iconOnly ? "relative !justify-start" : ""} ${financeUiTokens.control} ${props.className ?? ""}`}
      >
        <span
          className={`flex min-w-0 items-center gap-2 ${props.iconOnly ? "flex-none justify-start" : "flex-1"}`}
        >
          <OptionIcon
            emoji={selected?.emoji}
            fallback={selected?.fallback}
            symbol={selected?.symbol}
            large={props.largeOptionIcons}
          />
          <span
            data-select-trigger-label
            className={`${props.iconOnly ? "sr-only" : "truncate"} ${selected?.className || (selected ? "text-white" : "text-neutral-400")}`}
          >
            {selected?.label || copy.select}
          </span>
          {selected?.meta ? (
            <bdi className="ml-auto rounded-md bg-neutral-800 px-2 py-0.5 text-xs font-normal text-neutral-400">
              {selected.meta}
            </bdi>
          ) : null}
        </span>
        <ChevronDown
          size={16}
          className={
            props.iconOnly
              ? "absolute right-1.5 text-neutral-400"
              : "text-neutral-400"
          }
        />
      </button>
      {open ? (
        <div
          className="fixed z-[210] overflow-hidden rounded-lg border border-neutral-700 bg-neutral-900 shadow-xl"
          style={menuPosition}
        >
          {showSearch ? (
            <div className="border-b border-neutral-800 p-2">
              <input
                autoFocus
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Escape") {
                    event.preventDefault();
                    setOpen(false);
                    setSearch("");
                    triggerRef.current?.focus();
                  }
                  if (event.key === "ArrowDown") {
                    event.preventDefault();
                    focusOption("first");
                  }
                  if (event.key === "Enter") {
                    event.preventDefault();
                    const first = filtered.find((option) => !option.disabled);
                    if (first) commit(first.value);
                  }
                }}
                placeholder={copy.search}
                className="w-full rounded-md border border-neutral-700 bg-neutral-950 px-2.5 py-2 text-sm text-white outline-none placeholder:text-neutral-500 focus:border-blue-600"
              />
            </div>
          ) : null}
          <div
            id={listboxId}
            role="listbox"
            aria-label={props.triggerAriaLabel}
            className="max-h-60 overflow-auto"
          >
            {filtered.map((option) => (
              <button
                key={option.key}
                type="button"
                role="option"
                aria-selected={option.value === currentValue}
                aria-label={props.iconOnly ? option.label : undefined}
                disabled={option.disabled}
                onClick={() => commit(option.value)}
                onKeyDown={(event) => {
                  const buttons = optionButtons();
                  const index = buttons.indexOf(event.currentTarget);
                  if (event.key === "Escape") {
                    event.preventDefault();
                    setOpen(false);
                    triggerRef.current?.focus();
                  } else if (event.key === "ArrowDown") {
                    event.preventDefault();
                    buttons[Math.min(index + 1, buttons.length - 1)]?.focus();
                  } else if (event.key === "ArrowUp") {
                    event.preventDefault();
                    buttons[Math.max(index - 1, 0)]?.focus();
                  } else if (event.key === "Home") {
                    event.preventDefault();
                    buttons[0]?.focus();
                  } else if (event.key === "End") {
                    event.preventDefault();
                    buttons.at(-1)?.focus();
                  }
                }}
                className={`flex w-full items-center px-3 py-2 text-left text-sm text-neutral-200 hover:bg-neutral-800 disabled:opacity-50 ${props.iconOnly ? "justify-center" : "justify-between"}`}
              >
                <span
                  className={`flex min-w-0 items-center gap-2 ${props.iconOnly ? "flex-none justify-center" : "flex-1"}`}
                >
                  <OptionIcon
                    emoji={option.emoji}
                    fallback={option.fallback}
                    symbol={option.symbol}
                    large={props.largeOptionIcons}
                  />
                  <span
                    data-select-option-label
                    className={`${props.iconOnly ? "sr-only" : "truncate"} ${option.className}`}
                  >
                    {option.label}
                  </span>
                  {option.meta ? (
                    <bdi className="ml-auto rounded-md bg-neutral-800/80 px-2 py-0.5 text-xs font-normal text-neutral-400">
                      {option.meta}
                    </bdi>
                  ) : null}
                </span>
                {option.value === currentValue ? (
                  <Check size={14} className="text-blue-300" />
                ) : null}
              </button>
            ))}
            {!filtered.length ? (
              <p className="px-3 py-3 text-center text-sm text-neutral-500">
                {copy.empty}
              </p>
            ) : null}
          </div>
        </div>
      ) : null}
      <input type="hidden" name={props.name} value={currentValue} />
    </div>
  );
}

export function FormField({
  label,
  required,
  error,
  className = "",
  children,
}: PropsWithChildren<{
  label: React.ReactNode;
  required?: boolean;
  error?: string;
  className?: string;
}>) {
  return (
    <div className={`block min-w-0 text-sm ${className}`}>
      <span className="mb-1 block text-neutral-300">
        {label}
        {required ? <span className="ml-1 text-red-400">*</span> : null}
      </span>
      {children}
      {error ? <p className="mt-1 text-xs text-red-400">{error}</p> : null}
    </div>
  );
}
