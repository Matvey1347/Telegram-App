"use client";

import { ExternalLink } from "lucide-react";
import { useState } from "react";
import Image from "next/image";
import type { ConsumerFinanceProfile } from "@telegram-system/shared";
import type { FinanceCoreCopy, FinanceLocale } from "@consumer-finance/web/components/i18n/core";
import {
  financeScreenLabel,
  type ConsumerFinanceAction,
  type ConsumerFinanceScreen,
} from "@consumer-finance/web/components/app/consumer-finance-navigation";
import { ConsumerFinanceActionLauncher } from "@consumer-finance/web/components/app/consumer-finance-action-launcher";
import { FinanceLanguageSelect } from "@consumer-finance/web/components/ui/finance-language-select";
import { FinanceMobileNavigation } from "@consumer-finance/web/components/app/finance-mobile-navigation";
import { FinanceAccountMenu } from "@consumer-finance/web/components/accounts/finance-account-menu";
import financeStyles from "@consumer-finance/web/components/ui/finance-ui.module.css";

export function FinanceMiniAppShell({
  botId,
  logoUrl,
  screen,
  copy,
  locale,
  profile,
  onLocaleChange,
  localeChanging = false,
  localeDisabled = false,
  children,
  onNavigate,
  onOpenAssistant,
  onAction,
  onSignOut,
  signingOut = false,
  onOpenBrowser,
  browserUrl,
  openingBrowser = false,
  browserOpenError,
}: {
  botId: string;
  logoUrl?: string;
  screen: ConsumerFinanceScreen;
  copy: FinanceCoreCopy;
  locale: FinanceLocale;
  profile?: ConsumerFinanceProfile;
  onLocaleChange: (locale: FinanceLocale) => void;
  localeChanging?: boolean;
  localeDisabled?: boolean;
  children: React.ReactNode;
  onNavigate: (screen: ConsumerFinanceScreen) => void;
  onOpenAssistant?: () => void;
  onAction: (action: ConsumerFinanceAction) => void;
  onSignOut: () => void;
  signingOut?: boolean;
  onOpenBrowser?: () => boolean;
  browserUrl?: string;
  openingBrowser?: boolean;
  browserOpenError?: string;
}) {
  const [moreOpen, setMoreOpen] = useState(false);
  return (
    <main
      data-finance-surface="telegram"
      data-finance-shell="mini-app"
      className={`${financeStyles.pwaInset} ${financeStyles.groshlySurface} min-h-dvh bg-[#f7f8f4] pl-[env(safe-area-inset-left)] pr-[env(safe-area-inset-right)] text-[#18382d]`}
    >
      <div className="mx-auto flex min-h-dvh w-full max-w-2xl">
        <div className="min-w-0 flex-1">
          <header className="sticky top-0 z-30 flex min-h-16 items-center justify-between border-b border-[#e4ebe3] bg-[#f7f8f4]/95 px-4 pt-[env(safe-area-inset-top)] backdrop-blur">
            <div className="flex min-w-0 flex-1 items-center gap-3">
              <Image
                src={logoUrl || "/brand/finance-pwa-512.png"}
                alt=""
                width={36}
                height={36}
                unoptimized
                className="h-9 w-9 rounded-lg object-cover"
                onError={(event) => {
                  event.currentTarget.src = "/brand/finance-pwa-512.png";
                }}
              />
              <h1 className="truncate text-lg font-semibold tracking-tight">
                {financeScreenLabel(copy, screen)}
              </h1>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <FinanceLanguageSelect
                copy={copy}
                value={locale}
                onChange={onLocaleChange}
                disabled={localeChanging || localeDisabled}
              />
              {browserUrl ? (
                <a
                  href={browserUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(event) => {
                    if (onOpenBrowser?.() === false) event.preventDefault();
                  }}
                  className="inline-flex min-h-11 items-center gap-2 rounded-2xl border border-[#dce8db] bg-white px-3 text-sm text-[#315944] outline-none focus-visible:ring-2 focus-visible:ring-[#98c876] disabled:opacity-50"
                >
                  <ExternalLink size={17} aria-hidden="true" />
                  <span className="hidden sm:inline">{copy.openBrowser}</span>
                </a>
              ) : onOpenBrowser ? (
                <button
                  type="button"
                  disabled={openingBrowser}
                  onClick={onOpenBrowser}
                  className="inline-flex min-h-11 items-center gap-2 rounded-2xl border border-[#dce8db] bg-white px-3 text-sm text-[#315944] outline-none focus-visible:ring-2 focus-visible:ring-[#98c876] disabled:opacity-50"
                >
                  <ExternalLink size={17} aria-hidden="true" />
                  <span className="hidden sm:inline">
                    {openingBrowser ? copy.openingBrowser : copy.openBrowser}
                  </span>
                </button>
              ) : null}
              {profile ? (
                <FinanceAccountMenu
                  botId={botId}
                  profile={profile}
                  copy={copy}
                  screen={screen}
                  signingOut={signingOut}
                  onNavigate={onNavigate}
                  onSignOut={onSignOut}
                />
              ) : null}
            </div>
          </header>
          {browserOpenError ? (
            <p role="alert" className="px-4 pt-3 text-sm text-[#bb6b5c]">
              {browserOpenError}
            </p>
          ) : null}
          <div className="w-full px-4 pb-28 pt-5">{children}</div>
        </div>
      </div>

      {!moreOpen ? (
        <ConsumerFinanceActionLauncher
          compact
          showOnDesktop
          copy={copy}
          onAction={onAction}
        />
      ) : null}
      <FinanceMobileNavigation
        screen={screen}
        copy={copy}
        onNavigate={onNavigate}
        onOpenAssistant={onOpenAssistant}
        onMoreOpenChange={setMoreOpen}
        alwaysVisible
      />
    </main>
  );
}
