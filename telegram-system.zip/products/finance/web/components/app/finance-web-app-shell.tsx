"use client";

import { useState } from "react";
import { Bot } from "lucide-react";
import type { ConsumerFinanceProfile } from "@telegram-system/shared";
import Image from "next/image";
import type { FinanceCoreCopy } from "@consumer-finance/web/components/i18n/core";
import type { FinanceLocale } from "@consumer-finance/web/components/i18n/core";
import type {
  ConsumerFinanceAction,
  ConsumerFinanceScreen,
} from "@consumer-finance/web/components/app/consumer-finance-navigation";
import { financeScreenLabel } from "@consumer-finance/web/components/app/consumer-finance-navigation";
import { ConsumerFinanceActionLauncher } from "@consumer-finance/web/components/app/consumer-finance-action-launcher";
import { FinanceLanguageSelect } from "@consumer-finance/web/components/ui/finance-language-select";
import {
  FINANCE_NAVIGATION_GROUPS,
  FinanceNavigationButton,
  FinanceNavigationGroupHeader,
  isFinanceNavigationActive,
} from "@consumer-finance/web/components/app/finance-navigation-items";
import { FinanceAccountMenu } from "@consumer-finance/web/components/accounts/finance-account-menu";
import { FinanceMobileNavigation } from "@consumer-finance/web/components/app/finance-mobile-navigation";
import styles from "@consumer-finance/web/components/app/finance-navigation-groups.module.css";
import financeStyles from "@consumer-finance/web/components/ui/finance-ui.module.css";

export function FinanceWebAppShell({
  botId,
  logoUrl,
  screen,
  copy,
  profile,
  locale,
  onLocaleChange,
  localeChanging = false,
  localeDisabled = false,
  children,
  onNavigate,
  onOpenAssistant,
  onAction,
  onSignOut,
  signingOut = false,
}: {
  botId: string;
  logoUrl?: string;
  screen: ConsumerFinanceScreen;
  copy: FinanceCoreCopy;
  profile?: ConsumerFinanceProfile;
  locale: FinanceLocale;
  onLocaleChange: (locale: FinanceLocale) => void;
  localeChanging?: boolean;
  localeDisabled?: boolean;
  children: React.ReactNode;
  onNavigate: (screen: ConsumerFinanceScreen) => void;
  onOpenAssistant?: () => void;
  onAction: (action: ConsumerFinanceAction) => void;
  onSignOut: () => void;
  signingOut?: boolean;
}) {
  const title = financeScreenLabel(copy, screen);
  const [collapsedGroups, setCollapsedGroups] = useState<Set<string>>(
    () => new Set(),
  );
  const toggleGroup = (groupId: string) =>
    setCollapsedGroups((current) => {
      const next = new Set(current);
      if (next.has(groupId)) next.delete(groupId);
      else next.add(groupId);
      return next;
    });
  return (
    <main
      data-finance-surface="browser"
      data-finance-shell="web-app"
      className={`${financeStyles.pwaInset} ${financeStyles.groshlySurface} min-h-dvh bg-[#f7f8f4] text-[#18382d]`}
    >
      <div className="mx-auto flex min-h-dvh w-full max-w-[1800px]">
        <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 flex-col overflow-hidden border-r border-[#e4ebe3] bg-white px-4 py-5 md:flex">
          <div className="mb-5 flex shrink-0 items-center gap-3 px-3">
            <Image
              src={logoUrl || "/brand/finance-pwa-512.png"}
              alt=""
              width={40}
              height={40}
              unoptimized
              className="h-10 w-10 rounded-xl object-cover"
              onError={(event) => {
                event.currentTarget.src = "/brand/finance-pwa-512.png";
              }}
            />
            <p className="text-xl font-semibold tracking-tight">Groshly</p>
          </div>
          <nav
            aria-label={copy.financeNavigation}
            className="min-h-0 flex-1 space-y-0.5 overflow-y-auto pr-1 [scrollbar-color:#3a3a3a_transparent] [scrollbar-width:thin]"
          >
            {onOpenAssistant ? (
              <button
                type="button"
                onClick={onOpenAssistant}
                aria-current={screen === "assistant" ? "page" : undefined}
                className={`mb-3 flex min-h-11 w-full items-center gap-2 rounded-xl border px-2.5 text-sm outline-none transition focus-visible:ring-2 focus-visible:ring-cyan-300 ${screen === "assistant" ? "border-cyan-600 bg-cyan-500/20 text-cyan-100" : "border-cyan-800/60 bg-cyan-500/10 text-cyan-100 hover:border-cyan-700 hover:bg-cyan-500/15"}`}
              >
                <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-cyan-800/60 bg-cyan-950/70">
                  <Bot size={17} aria-hidden="true" />
                </span>
                <span className="truncate">{copy.assistant}</span>
              </button>
            ) : null}
            {FINANCE_NAVIGATION_GROUPS.map((group) => {
              const collapsed = collapsedGroups.has(group.id);
              const controls = `finance-sidebar-group-${group.id}`;
              return (
                <section key={group.id} className="mb-2 last:mb-0">
                  <FinanceNavigationGroupHeader
                    group={group}
                    label={copy[group.key]}
                    collapsed={collapsed}
                    controls={controls}
                    onToggle={() => toggleGroup(group.id)}
                  />
                  <div
                    id={controls}
                    aria-hidden={collapsed}
                    inert={collapsed ? true : undefined}
                    className={`${styles.groupBody} ${collapsed ? styles.groupBodyCollapsed : ""}`}
                  >
                    <div className={`${styles.groupBodyInner} space-y-0.5`}>
                      {group.items.map((item) => (
                        <FinanceNavigationButton
                          key={item.id}
                          item={item}
                          label={copy[item.key]}
                          active={isFinanceNavigationActive(screen, item.id)}
                          onClick={() => onNavigate(item.id)}
                        />
                      ))}
                    </div>
                  </div>
                </section>
              );
            })}
          </nav>
        </aside>

        <div className="min-w-0 flex-1">
          <header className="sticky top-0 z-30 flex min-h-16 items-center justify-between border-b border-[#e4ebe3] bg-[#f7f8f4]/95 px-4 pt-[env(safe-area-inset-top)] backdrop-blur md:px-8 xl:px-10">
            <div className="mx-auto flex w-full max-w-[1440px] items-center justify-between gap-3">
              <div className="flex min-w-0 flex-1 items-center gap-3">
                <Image
                  src={logoUrl || "/brand/finance-pwa-512.png"}
                  alt=""
                  width={36}
                  height={36}
                  unoptimized
                  className="h-9 w-9 rounded-lg object-cover"
                  onError={(event) => {
                    event.currentTarget.src = "/brand/finance-pwa-512.png";
                  }}
                />
                <h1 className="truncate text-lg font-semibold tracking-tight">{title}</h1>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <FinanceLanguageSelect
                  copy={copy}
                  value={locale}
                  onChange={onLocaleChange}
                  disabled={localeChanging || localeDisabled}
                />
                {profile ? (
                  <FinanceAccountMenu
                    botId={botId}
                    profile={profile}
                    copy={copy}
                    screen={screen}
                    signingOut={signingOut}
                    onNavigate={onNavigate}
                    onSignOut={onSignOut}
                  />
                ) : null}
              </div>
            </div>
          </header>
          <div className="mx-auto w-full max-w-[1440px] px-4 pb-24 pt-5 md:px-8 md:py-7 xl:px-10">
            {children}
          </div>
        </div>
      </div>
      <FinanceMobileNavigation
        screen={screen}
        copy={copy}
        onNavigate={onNavigate}
        onOpenAssistant={onOpenAssistant}
      />
      <ConsumerFinanceActionLauncher
        compact
        showOnDesktop
        copy={copy}
        onAction={onAction}
      />
    </main>
  );
}
