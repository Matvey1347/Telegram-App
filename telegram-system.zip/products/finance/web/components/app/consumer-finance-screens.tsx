"use client";

import { lazy, Suspense, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import type {
  ConsumerFinanceAnalyticsQuery,
  ConsumerFinanceProfile,
} from "@telegram-system/shared";
import { Button, ErrorState, LoadingState } from "@consumer-finance/web/components/ui";
import { consumerFinanceInsightsApi } from "@consumer-finance/web/lib/api/consumer-finance-insights-api";
import { consumerFinanceKeys } from "@consumer-finance/web/lib/query/consumer-finance-query-keys";
import { FinanceDashboard } from "@consumer-finance/web/components/dashboard/finance-dashboard";
import { financeCoreCopy, normalizeFinanceLocale } from "@consumer-finance/web/components/i18n/core";
import type {
  ConsumerFinanceAction,
  ConsumerFinanceDebtTarget,
  ConsumerFinanceRegularPaymentTarget,
  ConsumerFinanceScreen,
  ConsumerFinanceSurface,
} from "@consumer-finance/web/components/app/consumer-finance-navigation";
import { FinanceDebtEditor } from "@consumer-finance/web/components/obligations/finance-debt-editor";
import { FinanceInvestmentCreateModal } from "@consumer-finance/web/components/investments/finance-investment-create-modal";
export type { ConsumerFinanceScreen } from "@consumer-finance/web/components/app/consumer-finance-navigation";

const FinanceAccounts = lazy(() =>
  import("@consumer-finance/web/components/accounts/finance-accounts").then((module) => ({
    default: module.FinanceAccountsScreen,
  })),
);
const FinanceAccountEditor = lazy(() =>
  import("@consumer-finance/web/components/accounts/finance-account-editor").then((module) => ({
    default: module.FinanceAccountEditorScreen,
  })),
);
const FinanceAnalytics = lazy(() =>
  import("@consumer-finance/web/components/analytics/finance-analytics").then((module) => ({
    default: module.FinanceAnalytics,
  })),
);
const FinanceBudget = lazy(() =>
  import("@consumer-finance/web/components/planning/finance-budget").then((module) => ({
    default: module.FinanceBudget,
  })),
);
const FinanceCategories = lazy(() =>
  import("@consumer-finance/web/components/catalog/finance-categories").then((module) => ({
    default: module.FinanceCategories,
  })),
);
const FinanceOnboarding = lazy(() =>
  import("@consumer-finance/web/components/onboarding/finance-onboarding").then((module) => ({
    default: module.FinanceOnboardingScreen,
  })),
);
const FinanceLegacyBillingSummary = lazy(() =>
  import("@consumer-finance/web/components/planning/finance-legacy-billing-summary").then((module) => ({
    default: module.FinanceLegacyBillingSummary,
  })),
);
const FinanceReminders = lazy(() =>
  import("@consumer-finance/web/components/planning/finance-reminders").then((module) => ({
    default: module.FinanceReminders,
  })),
);
const FinanceSettings = lazy(() =>
  import("@consumer-finance/web/components/profile/finance-settings").then((module) => ({
    default: module.FinanceSettings,
  })),
);
const FinanceAccountCenter = lazy(() =>
  import("@consumer-finance/web/components/accounts/finance-account-center").then((module) => ({
    default: module.FinanceAccountCenter,
  })),
);
const FinanceTransactions = lazy(() =>
  import("@consumer-finance/web/components/ledger/finance-transactions").then((module) => ({
    default: module.FinanceTransactions,
  })),
);
const FinanceTransfers = lazy(() =>
  import("@consumer-finance/web/components/ledger/finance-transfers").then((module) => ({
    default: module.FinanceTransfers,
  })),
);
const FinanceDebts = lazy(() =>
  import("@consumer-finance/web/components/obligations/finance-debts").then((module) => ({
    default: module.FinanceDebts,
  })),
);
const FinanceRegularPayments = lazy(() =>
  import("@consumer-finance/web/components/obligations/finance-regular-payments").then((module) => ({
    default: module.FinanceRegularPayments,
  })),
);
const FinanceSavings = lazy(() =>
  import("@consumer-finance/web/components/savings/finance-savings").then((module) => ({
    default: module.FinanceSavings,
  })),
);
const FinanceInvestments = lazy(() =>
  import("@consumer-finance/web/components/investments/finance-investments").then((module) => ({
    default: module.FinanceInvestments,
  })),
);
const FinanceInvestmentDetail = lazy(() =>
  import("@consumer-finance/web/components/investments/finance-investment-detail").then((module) => ({
    default: module.FinanceInvestmentDetailScreen,
  })),
);
export function ConsumerFinanceScreens({
  botId,
  profile,
  screen,
  onScreenChange,
  surface,
  openTransfer = false,
  openTransaction = null,
  actionRequestId = 0,
  onActionClose = () => undefined,
  openEntityAction = null,
  onSpecialAction = () => undefined,
  regularPaymentTarget = null,
  regularPaymentTargetMalformed = false,
  debtTarget = null,
  debtTargetMalformed = false,
  accountId = null,
  onAccountEdit = () => undefined,
  onAccountBack = () => undefined,
  investmentId = null,
  onInvestmentOpen = () => undefined,
  onInvestmentBack = () => undefined,
  onTourStart,
}: {
  botId: string;
  profile: ConsumerFinanceProfile;
  screen: ConsumerFinanceScreen;
  onScreenChange: (screen: ConsumerFinanceScreen) => void;
  surface: ConsumerFinanceSurface;
  openTransfer?: boolean;
  openTransaction?: "EXPENSE" | "INCOME" | null;
  actionRequestId?: number;
  onActionClose?: () => void;
  openEntityAction?: "debt" | "investment" | null;
  onSpecialAction?: (
    action: ConsumerFinanceAction,
  ) => void;
  regularPaymentTarget?: ConsumerFinanceRegularPaymentTarget | null;
  regularPaymentTargetMalformed?: boolean;
  debtTarget?: ConsumerFinanceDebtTarget | null;
  debtTargetMalformed?: boolean;
  accountId?: string | null;
  onAccountEdit?: (accountId: string) => void;
  onAccountBack?: () => void;
  investmentId?: string | null;
  onInvestmentOpen?: (investmentId: string) => void;
  onInvestmentBack?: () => void;
  onTourStart?: () => void;
}) {
  const queryClient = useQueryClient();
  const [period, setPeriod] = useState<ConsumerFinanceAnalyticsQuery>({
    period: "CURRENT_MONTH",
  });
  const dashboard = useQuery({
    queryKey: consumerFinanceKeys.dashboard(
      botId,
      period.period === "CURRENT_MONTH" ? undefined : period,
    ),
    queryFn: () => consumerFinanceInsightsApi.dashboard(botId, period),
    retry: false,
    enabled:
      !!profile.onboardingCompletedAt &&
      screen === "home" &&
      (period.period !== "CUSTOM" || Boolean(period.from && period.to)),
  });
  const hasResolvedDashboardCache = queryClient
    .getQueriesData({ queryKey: consumerFinanceKeys.dashboardRoot(botId) })
    .some(([, data]) => data !== undefined);
  const switchingDashboardPeriod =
    screen === "home" && dashboard.isLoading && hasResolvedDashboardCache;
  const financeProfile = profile;
  const locale = normalizeFinanceLocale(financeProfile.locale);
  const t = financeCoreCopy(locale);
  if (!financeProfile.onboardingCompletedAt)
    return (
      <Suspense fallback={<LoadingState text={t.loadingReferences} />}>
        <FinanceOnboarding
          botId={botId}
          profile={financeProfile}
          onTourStart={onTourStart}
        />
      </Suspense>
    );
  if (screen === "home" && dashboard.isLoading && !switchingDashboardPeriod)
    return <LoadingState text={t.loadingFinances} />;
  if (screen === "home" && !dashboard.data && !switchingDashboardPeriod)
    return (
      <div className="space-y-3">
        <ErrorState text={t.financeUnavailable} />
        <Button onClick={() => dashboard.refetch()}>{t.retry}</Button>
      </div>
    );
  return (
    <Suspense fallback={<LoadingState text={t.loadingReferences} />}>
      {screen === "home" && (
        <FinanceDashboard
          data={dashboard.data}
          locale={locale}
          surface={surface}
          period={period}
          onPeriodChange={setPeriod}
          loading={switchingDashboardPeriod}
          loadingLabel={t.loadingFinances}
        />
      )}
      {screen === "analytics" && (
        <FinanceAnalytics
          botId={botId}
          locale={locale}
          onUpgrade={() => onScreenChange("billing")}
          period={period}
          onPeriodChange={setPeriod}
        />
      )}
      {screen === "transactions" && (
        <FinanceTransactions
          key={`${openTransaction ?? "transaction-history"}:${actionRequestId}`}
          botId={botId}
          locale={locale}
          timezone={financeProfile.timezone}
          initiallyOpenType={openTransaction}
          surface={surface}
          period={period}
          onLauncherClose={onActionClose}
          onSpecialAction={onSpecialAction}
        />
      )}
      {screen !== "transactions" && openTransaction ? (
        <FinanceTransactions
          key={`global-${openTransaction}:${actionRequestId}`}
          botId={botId}
          locale={locale}
          timezone={financeProfile.timezone}
          initiallyOpenType={openTransaction}
          surface={surface}
          period={period}
          editorOnly
          onLauncherClose={onActionClose}
          onSpecialAction={onSpecialAction}
        />
      ) : null}
      {screen === "transfers" && (
        <FinanceTransfers
          key={`${openTransfer ? "create-transfer" : "transfer-history"}:${actionRequestId}`}
          botId={botId}
          locale={locale}
          timezone={financeProfile.timezone}
          initiallyOpen={openTransfer}
          onCreateAccount={() => onAccountEdit("create")}
          period={period}
          onLauncherClose={onActionClose}
          onSpecialAction={onSpecialAction}
        />
      )}
      {screen !== "transfers" && openTransfer ? (
        <FinanceTransfers
          key={`global-transfer:${actionRequestId}`}
          botId={botId}
          locale={locale}
          timezone={financeProfile.timezone}
          initiallyOpen
          onCreateAccount={() => onAccountEdit("create")}
          period={period}
          editorOnly
          onLauncherClose={onActionClose}
          onSpecialAction={onSpecialAction}
        />
      ) : null}
      {openEntityAction === "debt" ? (
        <FinanceDebtEditor
          key={`global-debt:${actionRequestId}`}
          botId={botId}
          editing={null}
          locale={locale}
          timezone={financeProfile.timezone}
          onClose={onActionClose}
          onSaved={onActionClose}
        />
      ) : null}
      {openEntityAction === "investment" ? (
        <FinanceInvestmentCreateModal
          key={`global-investment:${actionRequestId}`}
          botId={botId}
          locale={locale}
          defaultCurrency={financeProfile.defaultCurrency}
          onClose={onActionClose}
        />
      ) : null}
      {screen === "debts" && (
        <FinanceDebts
          botId={botId}
          locale={locale}
          timezone={financeProfile.timezone}
          target={debtTarget}
          targetMalformed={debtTargetMalformed}
        />
      )}
      {screen === "regular-payments" && (
        <FinanceRegularPayments
          botId={botId}
          locale={locale}
          timezone={financeProfile.timezone}
          target={regularPaymentTarget}
          targetMalformed={regularPaymentTargetMalformed}
        />
      )}
      {screen === "savings" && (
        <FinanceSavings
          botId={botId}
          locale={locale}
          defaultCurrency={financeProfile.defaultCurrency}
        />
      )}
      {screen === "investments" && (
        <FinanceInvestments
          botId={botId}
          locale={locale}
          defaultCurrency={financeProfile.defaultCurrency}
          onOpen={onInvestmentOpen}
        />
      )}
      {screen === "investment" && investmentId ? (
        <FinanceInvestmentDetail
          botId={botId}
          locale={locale}
          defaultCurrency={financeProfile.defaultCurrency}
          investmentId={investmentId}
          onBack={onInvestmentBack}
        />
      ) : null}
      {screen === "accounts" && (
        <FinanceAccounts botId={botId} locale={locale} onEdit={onAccountEdit} />
      )}
      {screen === "account" && accountId ? (
        <FinanceAccountEditor
          key={accountId}
          botId={botId}
          defaultCurrency={financeProfile.defaultCurrency}
          locale={locale}
          accountId={accountId}
          onBack={onAccountBack}
        />
      ) : null}
      {screen === "budget" && (
        <FinanceBudget
          botId={botId}
          locale={locale}
          onUpgrade={() => onScreenChange("billing")}
        />
      )}
      {screen === "categories" && (
        <FinanceCategories botId={botId} locale={locale} />
      )}
      {screen === "settings" && (
        <FinanceSettings
          botId={botId}
          profile={financeProfile}
          locale={locale}
        />
      )}
      {screen === "profile" && (
        <FinanceAccountCenter
          botId={botId}
          profile={financeProfile}
          locale={locale}
        />
      )}
      {screen === "reminders" && (
        <FinanceReminders
          botId={botId}
          locale={locale}
          currency={financeProfile.defaultCurrency}
          timezone={financeProfile.timezone}
        />
      )}
      {screen === "billing" && <FinanceLegacyBillingSummary botId={botId} locale={locale} />}
    </Suspense>
  );
}
