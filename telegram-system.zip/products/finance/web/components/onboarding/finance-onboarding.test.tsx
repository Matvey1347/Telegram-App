import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { FinanceOnboarding } from "@consumer-finance/web/components/onboarding/finance-onboarding";

describe("FinanceOnboarding", () => {
  it("shows a recoverable error when profile persistence fails", async () => {
    const onComplete = vi.fn().mockRejectedValue(new Error("offline"));
    render(
      <FinanceOnboarding
        profile={{
          id: "profile-1",
          defaultCurrency: "USD",
          timezone: "UTC",
          locale: "en",
          onboardingCompletedAt: null,
          telegramUser: { displayName: "Ada", username: null, avatarUrl: null },
        }}
        onComplete={onComplete}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "Continue" }));
    const timezone = screen.getByRole("button", { name: /UTC/u });
    fireEvent.click(timezone);
    expect(screen.getByPlaceholderText("Search…")).toBeInTheDocument();
    fireEvent.click(timezone);
    fireEvent.click(screen.getByRole("button", { name: "Continue" }));

    expect(
      await screen.findByText("Finance could not be loaded."),
    ).toBeInTheDocument();
    expect(onComplete).toHaveBeenCalledWith({
      defaultCurrency: "USD",
      timezone: "UTC",
      locale: "en",
    });
    expect(
      screen.getByRole("button", { name: "Continue" }),
    ).toBeEnabled();
  });

  it("starts the interactive tour after setting up their preferences", async () => {
    const onComplete = vi.fn().mockResolvedValue(undefined);
    render(
      <FinanceOnboarding
        profile={{
          id: "profile-1",
          defaultCurrency: "USD",
          timezone: "UTC",
          locale: "en",
          onboardingCompletedAt: null,
          telegramUser: { displayName: "Ada", username: null, avatarUrl: null },
        }}
        onComplete={onComplete}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "Continue" }));
    fireEvent.click(screen.getByRole("button", { name: "Continue" }));

    expect(onComplete).toHaveBeenCalledWith({
      defaultCurrency: "USD",
      timezone: "UTC",
      locale: "en",
    });
  });
});
