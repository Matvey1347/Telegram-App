"use client";

import { useState } from "react";
import {
  useInfiniteQuery,
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";
import { RotateCcw } from "lucide-react";
import type {
  ConsumerFinanceAnalyticsQuery,
  ConsumerFinanceHistoryQuery,
  ConsumerFinanceTransaction,
} from "@telegram-system/shared";
import { Button, Card, EmptyState, ErrorState, LoadingState } from "@consumer-finance/web/components/ui";
import { useFinanceFeedback } from "@consumer-finance/web/components/ui/finance-feedback";
import { consumerFinanceApi } from "@consumer-finance/web/lib/api/consumer-finance-api";
import { consumerFinanceLedgerApi } from "@consumer-finance/web/lib/api/consumer-finance-ledger-api";
import {
  prependConsumerTransactionToCaches,
  reconcileConsumerTransactionCaches,
  removeConsumerTransactionFromCaches,
} from "@consumer-finance/web/lib/cache/consumer-finance-cache";
import { consumerFinanceKeys } from "@consumer-finance/web/lib/query/consumer-finance-query-keys";
import { type FinanceLocale } from "@consumer-finance/web/components/i18n/core";
import { financeTransactionsCopy } from "@consumer-finance/web/components/i18n/transactions";
import type { ConsumerFinanceSurface } from "@consumer-finance/web/components/app/consumer-finance-navigation";
import { FinanceTransactionEditor } from "@consumer-finance/web/components/ledger/finance-transaction-editor";
import { FinanceTransactionFilters } from "@consumer-finance/web/components/ledger/finance-transaction-filters";
import { useDebouncedValue } from "@consumer-finance/web/components/hooks/use-debounced-value";
import { FinanceConfirmModal } from "@consumer-finance/web/components/shared/finance-confirm-modal";
import { FinanceTransactionDetailModal } from "@consumer-finance/web/components/ledger/finance-transaction-detail-modal";
import { FinanceMobileTransactionRow } from "@consumer-finance/web/components/ledger/finance-mobile-transaction-row";
import { DesktopTransactionTable } from "@consumer-finance/web/components/ledger/finance-desktop-transaction-table";
import { financePeriodDateRange } from "@consumer-finance/web/components/planning/finance-period-selector";
import { FinanceCursorPagination } from "@consumer-finance/web/components/ui/finance-cursor-pagination";

export function FinanceTransactions({
  botId,
  locale,
  timezone,
  initiallyOpenType = null,
  surface,
  period = { period: "CURRENT_MONTH" },
  editorOnly = false,
  onLauncherClose,
  onSpecialAction,
}: {
  botId: string;
  locale: FinanceLocale;
  timezone: string;
  initiallyOpenType?: "EXPENSE" | "INCOME" | null;
  surface: ConsumerFinanceSurface;
  period?: ConsumerFinanceAnalyticsQuery;
  editorOnly?: boolean;
  onLauncherClose?: () => void;
  onSpecialAction?: (action: "transfer" | "debt" | "investment") => void;
}) {
  const client = useQueryClient();
  const t = financeTransactionsCopy(locale);
  const { pushToast } = useFinanceFeedback();
  const [filters, setFilters] = useState<ConsumerFinanceHistoryQuery>(() => ({
    limit: 50,
    ...financePeriodDateRange(period),
  }));
  const [editing, setEditing] = useState<ConsumerFinanceTransaction | null>(
    null,
  );
  const [deleting, setDeleting] = useState<ConsumerFinanceTransaction | null>(
    null,
  );
  const [detail, setDetail] = useState<ConsumerFinanceTransaction | null>(null);
  const [undoable, setUndoable] = useState<string | null>(null);
  const [page, setPage] = useState(0);
  const debouncedSearch = useDebouncedValue(filters.search);
  const queryFilters = { ...filters, search: debouncedSearch };
  // References and history are independent and intentionally start together.
  const accounts = useQuery({
    queryKey: consumerFinanceKeys.accounts(botId),
    queryFn: () => consumerFinanceLedgerApi.accounts(botId),
  });
  const categories = useQuery({
    queryKey: consumerFinanceKeys.categories(botId),
    queryFn: () => consumerFinanceLedgerApi.categories(botId),
  });
  const history = useInfiniteQuery({
    queryKey: consumerFinanceKeys.transactions(botId, {
      ...queryFilters,
      cursor: undefined,
    }),
    initialPageParam: undefined as string | undefined,
    queryFn: ({ pageParam }) =>
      consumerFinanceApi.transactions(botId, {
        ...queryFilters,
        cursor: pageParam,
      }),
    getNextPageParam: (page) => page.nextCursor ?? undefined,
    enabled: !editorOnly,
  });
  const items = history.data?.pages[page]?.items ?? [];
  const hasNextPage = Boolean(history.data?.pages[page]?.nextCursor);
  const nextPage = async () => {
    if (!hasNextPage || history.isFetchingNextPage) return;
    if (!history.data?.pages[page + 1]) {
      const result = await history.fetchNextPage();
      if (!result.data?.pages[page + 1]) return;
    }
    setPage((current) => current + 1);
  };
  const invalidateDerived = () => {
    void client.invalidateQueries({
      queryKey: consumerFinanceKeys.dashboard(botId),
    });
    void client.invalidateQueries({
      queryKey: consumerFinanceKeys.analyticsRoot(botId),
    });
    void client.invalidateQueries({
      queryKey: consumerFinanceKeys.accounts(botId),
    });
  };
  const invalidateInvestment = () => {
    void client.invalidateQueries({
      queryKey: consumerFinanceKeys.investmentLists(botId),
    });
    void client.invalidateQueries({
      queryKey: consumerFinanceKeys.investmentSummary(botId),
    });
    void client.invalidateQueries({
      queryKey: consumerFinanceKeys.investmentDetails(botId),
    });
  };
  const remove = useMutation({
    mutationFn: (id: string) => consumerFinanceApi.deleteTransaction(botId, id),
    onSuccess: (result, id) => {
      removeConsumerTransactionFromCaches(client, botId, id);
      setUndoable(result.undoable === false ? null : id);
      setDeleting(null);
      if (deleting?.purpose.startsWith("INVESTMENT_")) invalidateInvestment();
      if (items.length === 1 && page > 0) setPage(page - 1);
      invalidateDerived();
      pushToast(t.transactionDeleted, "info");
    },
    onError: () => pushToast(t.transactionDeleteError, "error"),
  });
  const undo = useMutation({
    mutationFn: (id: string) => consumerFinanceApi.undoTransaction(botId, id),
    onSuccess: (result) => {
      setUndoable(null);
      if (result.transaction)
        prependConsumerTransactionToCaches(
          client,
          botId,
          result.transaction,
          timezone,
        );
      else
        void client.invalidateQueries({
          queryKey: consumerFinanceKeys.transactionLists(botId),
        });
      invalidateDerived();
      pushToast(t.transactionRestored, "success");
    },
    onError: () => pushToast(t.transactionUndoError, "error"),
  });
  if (accounts.isLoading || categories.isLoading)
    return <LoadingState text={t.loadingReferences} />;
  if (accounts.isError || categories.isError)
    return (
      <div className="space-y-3">
        <ErrorState text={t.referencesUnavailable} />
        <Button
          onClick={() =>
            void Promise.all([accounts.refetch(), categories.refetch()])
          }
        >
          {t.retry}
        </Button>
      </div>
    );
  const accountRows = accounts.data ?? [];
  const categoryRows = categories.data ?? [];
  if (editorOnly)
    return (
      <FinanceTransactionEditor
        key={`launcher-${initiallyOpenType}`}
        botId={botId}
        accounts={accountRows}
        categories={categoryRows}
        editing={null}
        locale={locale}
        timezone={timezone}
        initiallyOpenType={initiallyOpenType}
        onClose={() => onLauncherClose?.()}
        onSaved={(item) => {
          reconcileConsumerTransactionCaches(client, botId, item, timezone);
          onLauncherClose?.();
          invalidateDerived();
        }}
        onSpecialAction={onSpecialAction}
      />
    );
  return (
    <div className="space-y-4">
      <FinanceTransactionEditor
        key={editing?.id ?? "create-transaction"}
        botId={botId}
        accounts={accountRows}
        categories={categoryRows}
        editing={editing}
        locale={locale}
        timezone={timezone}
        initiallyOpenType={initiallyOpenType}
        onClose={() => {
          setEditing(null);
          onLauncherClose?.();
        }}
        onSaved={(item) => {
          reconcileConsumerTransactionCaches(client, botId, item, timezone);
          if (item.purpose.startsWith("INVESTMENT_")) invalidateInvestment();
          setEditing(null);
          onLauncherClose?.();
          invalidateDerived();
        }}
        onSpecialAction={onSpecialAction}
      />
      <FinanceTransactionFilters
        filters={filters}
        accounts={accountRows}
        categories={categoryRows}
        locale={locale}
        surface={surface}
        onChange={(next) => { setPage(0); setFilters(next); }}
      />
      <Card className={surface === "telegram" ? "overflow-hidden !p-0" : ""}>
        {history.isLoading ? (
          <LoadingState text={t.loading} />
        ) : history.isError ? (
          <div className="space-y-3">
            <ErrorState text={t.transactionLoadError} />
            <Button onClick={() => history.refetch()}>{t.retry}</Button>
          </div>
        ) : items.length && surface === "browser" ? (
          <DesktopTransactionTable
            items={items}
            locale={locale}
            timezone={timezone}
            onDetail={setDetail}
            onEdit={setEditing}
            onDelete={setDeleting}
          />
        ) : items.length ? (
          <div className="divide-y divide-neutral-800">
            {items.map((item) => (
              <FinanceMobileTransactionRow
                key={item.id}
                item={item}
                locale={locale}
                timezone={timezone}
                onDetail={() => setDetail(item)}
                onEdit={() => setEditing(item)}
                onDelete={() => setDeleting(item)}
              />
            ))}
          </div>
        ) : (
          <EmptyState text={t.noTransactions} />
        )}
      </Card>
      <FinanceCursorPagination
        locale={locale}
        page={page}
        hasPrevious={page > 0}
        hasNext={hasNextPage}
        loading={history.isFetchingNextPage}
        onPrevious={() => setPage((current) => Math.max(0, current - 1))}
        onNext={() => void nextPage()}
      />
      {undoable ? (
        <Button
          variant="secondary"
          className="w-full"
          disabled={undo.isPending}
          onClick={() => undo.mutate(undoable)}
        >
          <RotateCcw size={16} /> {t.undoTransaction}
        </Button>
      ) : null}
      <FinanceConfirmModal
        open={!!deleting}
        locale={locale}
        onClose={() => setDeleting(null)}
        onConfirm={() =>
          deleting ? remove.mutateAsync(deleting.id) : Promise.resolve()
        }
        entityName={deleting?.description || t.transactionFallback}
        actionLabel={t.delete}
        description={t.deleteTransactionDescription}
      />
      <FinanceTransactionDetailModal
        botId={botId}
        transaction={detail}
        locale={locale}
        onClose={() => setDetail(null)}
      />
    </div>
  );
}
