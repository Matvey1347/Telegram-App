import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { FinanceFeedbackProvider } from "@consumer-finance/web/components/ui/finance-feedback";
import { consumerFinanceApi } from "@consumer-finance/web/lib/api/consumer-finance-api";
import { FinanceTransactions } from "@consumer-finance/web/components/ledger/finance-transactions";

const ledger = vi.hoisted(() => ({
  accounts: vi.fn(),
  categories: vi.fn(),
}));

vi.mock("@consumer-finance/web/lib/api/consumer-finance-api", () => ({
  consumerFinanceApi: {
    transactions: vi.fn(),
    transaction: vi.fn(),
    createTransaction: vi.fn(),
    updateTransaction: vi.fn(),
    deleteTransaction: vi.fn(),
    undoTransaction: vi.fn(),
  },
}));
vi.mock("@consumer-finance/web/lib/api/consumer-finance-ledger-api", () => ({
  consumerFinanceLedgerApi: ledger,
}));

function renderTransactions(
  surface: "browser" | "telegram" = "telegram",
  locale: "en" | "uk" | "ru" = "en",
) {
  return render(
    <QueryClientProvider
      client={
        new QueryClient({ defaultOptions: { queries: { retry: false } } })
      }
    >
      <FinanceFeedbackProvider>
        <FinanceTransactions
          botId="bot-1"
          locale={locale}
          timezone="UTC"
          surface={surface}
        />
      </FinanceFeedbackProvider>
    </QueryClientProvider>,
  );
}

beforeEach(() => {
  ledger.accounts.mockResolvedValue([]);
  ledger.categories.mockResolvedValue([]);
});
afterEach(() => vi.clearAllMocks());

describe("FinanceTransactions receipt detail", () => {
  it("starts account, category and history reads before any one resolves", async () => {
    let resolveAccounts!: (value: []) => void;
    let resolveCategories!: (value: []) => void;
    let resolveHistory!: (value: { items: []; nextCursor: null }) => void;
    ledger.accounts.mockReturnValue(
      new Promise((resolve) => {
        resolveAccounts = resolve;
      }),
    );
    ledger.categories.mockReturnValue(
      new Promise((resolve) => {
        resolveCategories = resolve;
      }),
    );
    vi.mocked(consumerFinanceApi.transactions).mockReturnValue(
      new Promise((resolve) => {
        resolveHistory = resolve;
      }),
    );

    renderTransactions();

    await waitFor(() => {
      expect(ledger.accounts).toHaveBeenCalledOnce();
      expect(ledger.categories).toHaveBeenCalledOnce();
      expect(consumerFinanceApi.transactions).toHaveBeenCalledOnce();
    });
    resolveAccounts([]);
    resolveCategories([]);
    resolveHistory({ items: [], nextCursor: null });
    expect(
      await screen.findByText("No matching transactions."),
    ).toBeInTheDocument();
  });

  it("keeps Mini App creation in the floating launcher and opens filters on demand", async () => {
    vi.mocked(consumerFinanceApi.transactions).mockResolvedValue({
      items: [],
      nextCursor: null,
    });

    renderTransactions();

    await screen.findByText("No matching transactions.");
    expect(
      screen.queryByRole("button", { name: "Add expense" }),
    ).not.toBeInTheDocument();
    expect(
      screen.queryByPlaceholderText("Search description or category"),
    ).not.toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: /^Filters/ }));

    expect(
      screen.getByPlaceholderText("Search description or category"),
    ).toBeInTheDocument();
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("localizes filters and portals the calendar above the modal", async () => {
    vi.mocked(consumerFinanceApi.transactions).mockResolvedValue({
      items: [],
      nextCursor: null,
    });
    const { container } = renderTransactions("telegram", "ru");

    fireEvent.click(await screen.findByRole("button", { name: /^Фильтры/ }));
    const period = screen.getByRole("button", { name: /01\.09\.2026/ });
    fireEvent.click(period);

    const calendar = screen.getByRole("dialog", {
      name: "Выберите период",
    });
    expect(calendar).toHaveStyle({ position: "fixed" });
    expect(calendar).toHaveClass("z-[220]");
    expect(container).not.toContainElement(calendar);
    expect(screen.getByText("Выберите начальную дату")).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Очистить" }),
    ).toBeInTheDocument();
  });

  it("keeps long mobile transaction labels and amounts on one line", async () => {
    vi.mocked(consumerFinanceApi.transactions).mockResolvedValue({
      items: [
        {
          id: "long-row",
          accountId: "account-1",
          type: "EXPENSE",
          purpose: "ORDINARY",
          amount: "123456789012345.67",
          currency: "UAH",
          occurredAt: "2026-08-21T10:00:00.000Z",
          description:
            "A very long description that must not push the amount onto another line",
          account: {
            id: "account-1",
            name: "A very long account name that should be truncated safely",
            currency: "UAH",
            iconPresentation: { type: "unicode", value: "💳" },
          },
        },
      ],
      nextCursor: null,
    });

    renderTransactions();

    const amount = await screen.findByTitle(/123/);
    expect(amount).toHaveClass("whitespace-nowrap");
    expect(screen.getByTitle(/A very long description/)).toHaveClass(
      "truncate",
    );
  });

  it("fetches receipt items only after the user opens the purchase detail", async () => {
    vi.mocked(consumerFinanceApi.transactions).mockResolvedValue({
      items: [
        {
          id: "receipt-1",
          accountId: "account-1",
          type: "EXPENSE",
          purpose: "ORDINARY",
          amount: "83.42",
          currency: "PLN",
          occurredAt: "2026-08-21T10:00:00.000Z",
          merchantDisplay: "Biedronka",
          source: "RECEIPT",
          itemCount: 2,
          account: {
            id: "account-1",
            name: "mBank",
            currency: "PLN",
            iconPresentation: { type: "unicode", value: "💳" },
          },
        },
      ],
      nextCursor: null,
    });
    vi.mocked(consumerFinanceApi.transaction).mockResolvedValue({
      id: "receipt-1",
      accountId: "account-1",
      type: "EXPENSE",
      purpose: "ORDINARY",
      amount: "83.42",
      currency: "PLN",
      occurredAt: "2026-08-21T10:00:00.000Z",
      merchantDisplay: "Biedronka",
      source: "RECEIPT",
      itemCount: 2,
      account: {
        id: "account-1",
        name: "mBank",
        currency: "PLN",
        iconPresentation: { type: "unicode", value: "💳" },
      },
      items: [
        {
          id: "item-1",
          displayName: "Milk",
          quantity: "2",
          unitPrice: "4.5",
          totalAmount: "9",
          currency: "PLN",
          category: { id: "category-1", name: "Groceries" },
        },
      ],
    });

    renderTransactions();

    expect(await screen.findByText("Biedronka")).toBeInTheDocument();
    expect(consumerFinanceApi.transaction).not.toHaveBeenCalled();
    expect(screen.getByText(/2 Items/)).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Purchase details" }));

    await waitFor(() =>
      expect(consumerFinanceApi.transaction).toHaveBeenCalledWith(
        "bot-1",
        "receipt-1",
      ),
    );
    expect(await screen.findByText("Milk")).toBeInTheDocument();
    expect(screen.getByText(/Quantity: 2/)).toBeInTheDocument();
    expect(screen.getByText(/Unit price: zł 4.50/)).toBeInTheDocument();
  });

  it("uses a dense table on the browser surface without per-row detail GETs", async () => {
    vi.mocked(consumerFinanceApi.transactions).mockResolvedValue({
      items: [
        {
          id: "row-1",
          accountId: "account-1",
          type: "INCOME",
          purpose: "ORDINARY",
          amount: "1200",
          currency: "USD",
          occurredAt: "2026-08-21T10:00:00.000Z",
          description: "Client payment",
          account: {
            id: "account-1",
            name: "Bank",
            currency: "USD",
            iconPresentation: {
              type: "image",
              id: "bank-icon",
              url: "https://cdn.example/bank.png",
            },
          },
          category: {
            id: "category-1",
            name: "Salary",
            type: "INCOME",
            iconPresentation: { type: "unicode", value: "💼" },
          },
        },
      ],
      nextCursor: null,
    });

    renderTransactions("browser");

    expect(await screen.findByRole("table")).toBeInTheDocument();
    expect(screen.getByText("Client payment")).toBeInTheDocument();
    expect(screen.getByText(/Bank/)).toBeInTheDocument();
    expect(screen.getByRole("img", { name: "Bank" })).toHaveAttribute(
      "src",
      "https://cdn.example/bank.png",
    );
    expect(consumerFinanceApi.transaction).not.toHaveBeenCalled();
  });

  it("offers edit and delete for investment cash-flow rows", async () => {
    vi.mocked(consumerFinanceApi.transactions).mockResolvedValue({
      items: [
        {
          id: "investment-flow-row",
          accountId: "account-1",
          type: "EXPENSE",
          purpose: "INVESTMENT_CONTRIBUTION",
          amount: "4000",
          currency: "USD",
          occurredAt: "2026-08-21T10:00:00.000Z",
          description: "House deposit",
          account: {
            id: "account-1",
            name: "Bank",
            currency: "USD",
            iconPresentation: { type: "unicode", value: "💳" },
          },
        },
      ],
      nextCursor: null,
    });

    renderTransactions("browser");

    expect(await screen.findAllByText("Investment contribution")).toHaveLength(
      2,
    );
    expect(
      screen.queryByRole("button", { name: "Purchase details" }),
    ).not.toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Edit transaction" }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Delete transaction" }),
    ).toBeInTheDocument();
  });

  it("shows one cursor page at a time and fetches the next page on demand", async () => {
    vi.mocked(consumerFinanceApi.transactions).mockImplementation(
      async (_bot, query) =>
        query?.cursor
          ? { items: [{ id: "second", accountId: "a", type: "EXPENSE", purpose: "ORDINARY", amount: "2", currency: "USD", occurredAt: "2026-09-02T00:00:00.000Z", description: "Second page" }], nextCursor: null }
          : { items: [{ id: "first", accountId: "a", type: "EXPENSE", purpose: "ORDINARY", amount: "1", currency: "USD", occurredAt: "2026-09-03T00:00:00.000Z", description: "First page" }], nextCursor: "first" },
    );

    renderTransactions("browser");
    expect(await screen.findByText("First page")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Next" }));
    expect(await screen.findByText("Second page")).toBeInTheDocument();
    expect(screen.queryByText("First page")).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Previous" }));
    expect(await screen.findByText("First page")).toBeInTheDocument();
  });

  it("does not offer receipt details for a transaction without itemized receipt data", async () => {
    vi.mocked(consumerFinanceApi.transactions).mockResolvedValue({
      items: [
        {
          id: "manual-row",
          accountId: "account-1",
          type: "EXPENSE",
          purpose: "ORDINARY",
          amount: "8",
          currency: "USD",
          occurredAt: "2026-08-21T10:00:00.000Z",
          description: "Coffee",
          source: "MINI_APP",
          itemCount: 0,
          account: {
            id: "account-1",
            name: "Cash",
            currency: "USD",
            iconPresentation: { type: "unicode", value: "💵" },
          },
        },
      ],
      nextCursor: null,
    });

    renderTransactions("browser");

    expect(await screen.findByText("Coffee")).toBeInTheDocument();
    expect(
      screen.queryByRole("button", { name: "Purchase details" }),
    ).not.toBeInTheDocument();
    expect(consumerFinanceApi.transaction).not.toHaveBeenCalled();
  });
});
