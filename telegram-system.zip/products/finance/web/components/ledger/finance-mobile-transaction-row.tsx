import { Pencil, Trash2 } from "lucide-react";
import type { ConsumerFinanceTransaction } from "@telegram-system/shared";
import { formatMoney } from "@consumer-finance/web/lib/formatters/consumer-finance-money";
import { financeIntlLocale, type FinanceLocale } from "@consumer-finance/web/components/i18n/core";
import { financeTransactionsCopy } from "@consumer-finance/web/components/i18n/transactions";
import { localizeFinanceCategory } from "@consumer-finance/web/components/catalog/finance-category-i18n";
import { IconAvatar } from "@consumer-finance/web/components/ui/finance-icon-avatar";

export function FinanceMobileTransactionRow({
  item,
  locale,
  timezone,
  onDetail,
  onEdit,
  onDelete,
}: {
  item: ConsumerFinanceTransaction;
  locale: FinanceLocale;
  timezone: string;
  onDetail: () => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const t = financeTransactionsCopy(locale);
  const income = item.type === "INCOME" || item.purpose === "INVESTMENT_RETURN";
  const investment = item.purpose.startsWith("INVESTMENT_");
  const debt = item.purpose === "DEBT_REPAYMENT";
  const hasItemizedDetails = (item.itemCount ?? 0) > 0;
  const purposeTitle =
    item.purpose === "INVESTMENT_CONTRIBUTION"
      ? t.investmentContribution
      : item.purpose === "INVESTMENT_RETURN"
        ? t.investmentReturn
        : item.purpose === "REIMBURSEMENT"
          ? t.reimbursement
          : item.purpose === "PASS_THROUGH"
            ? t.passThrough
            : item.purpose === "DEBT_REPAYMENT"
              ? t.debtRepayment
              : undefined;
  const title =
    purposeTitle ||
    item.merchantDisplay ||
    item.description ||
    (item.category
      ? localizeFinanceCategory(item.category.name, item.category.key, locale)
      : undefined) ||
    (income ? t.income : t.expense);
  const sourceLabel =
    item.source === "RECEIPT"
      ? t.receipt
      : item.source === "AI"
        ? t.aiEntry
        : t.manualEntry;
  const amount = `${income ? "+" : "−"}${formatMoney(
    item.amount,
    item.currency,
    "symbol",
  )}`;
  const amountSize =
    amount.length > 20
      ? "text-[10px] tracking-tight"
      : amount.length > 14
        ? "text-xs tracking-tight"
        : "text-sm";

  return (
    <div
      className={`flex min-w-0 items-center gap-1 px-3 py-1 sm:px-4 ${investment ? "bg-violet-950/20" : debt ? "bg-amber-950/15" : ""}`}
    >
      <div
        className={`relative grid min-h-16 min-w-0 flex-1 grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded px-1 text-left ${hasItemizedDetails ? "cursor-pointer outline-none focus-within:ring-2 focus-within:ring-sky-300" : ""}`}
      >
        <IconAvatar
          icon={item.account?.iconPresentation}
          label={item.account?.name ?? t.accountFallback}
          size="sm"
        />
        <span className="min-w-0">
          {hasItemizedDetails ? (
            <button
              type="button"
              aria-label={t.transactionDetails}
              onClick={onDetail}
              className="absolute inset-0 z-10 rounded outline-none focus-visible:ring-2 focus-visible:ring-sky-300"
            />
          ) : null}
          <span
            className={`block truncate text-sm font-medium ${investment ? "text-violet-300" : debt ? "text-amber-300" : ""}`}
            title={title}
          >
            {title}
          </span>
          <span className="block truncate text-xs text-neutral-500">
            {item.account?.name ?? t.accountFallback} ·{" "}
            {new Intl.DateTimeFormat(financeIntlLocale(locale), {
              timeZone: timezone,
            }).format(new Date(item.occurredAt))}
            {item.source ? ` · ${sourceLabel}` : ""}
            {item.category ? (
              <span className="inline-flex items-center gap-1 align-middle">
                <span aria-hidden="true"> · </span>
                <IconAvatar icon={item.category.iconPresentation} label={item.category.name} size="xs" />
                {localizeFinanceCategory(item.category.name, item.category.key, locale)}
              </span>
            ) : null}
            {item.itemCount
              ? ` · ${item.itemCount} ${item.itemCount === 1 ? t.item : t.items}`
              : ""}
          </span>
        </span>
        <strong
          title={amount}
          className={`max-w-[42vw] shrink-0 overflow-hidden text-ellipsis whitespace-nowrap text-right tabular-nums ${amountSize} ${income ? "text-emerald-300" : "text-rose-300"}`}
        >
          {amount}
        </strong>
      </div>
      <MobileRowAction
        label={t.editTransactionLabel}
        tone="text-neutral-300"
        onClick={onEdit}
      >
        <Pencil size={16} />
      </MobileRowAction>
      <MobileRowAction
        label={t.deleteTransactionLabel}
        tone="text-rose-300"
        onClick={onDelete}
      >
        <Trash2 size={16} />
      </MobileRowAction>
    </div>
  );
}

function MobileRowAction({
  label,
  tone,
  onClick,
  children,
}: {
  label: string;
  tone: string;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className={`flex min-h-11 min-w-11 items-center justify-center rounded outline-none focus-visible:ring-2 focus-visible:ring-sky-300 ${tone}`}
    >
      {children}
    </button>
  );
}
