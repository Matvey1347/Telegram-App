import { Injectable } from '@nestjs/common';
import { TelegramBotApplicationType } from '@prisma/client';
import type { TelegramBotApplicationPresentation } from '@api/domains/telegram/telegram-bots/core/telegram-bot-application.ports';
import type { TelegramBotCommand } from '@api/telegram/shared/bot/telegram-bot-api.client';
import {
  financeChatMenuButton,
  financeMainMenu,
  financeMiniAppUrl,
} from '@consumer-finance/api/telegram-presentation/finance-telegram-menu';
import {
  financeChatLocale,
  type FinanceChatLocale,
} from '@consumer-finance/api/i18n/finance-chat-i18n';
import { publicWebOrigin } from '@api/config/deployment-config';

const COMMAND_DESCRIPTIONS: Record<FinanceChatLocale, string[]> = {
  en: [
    'Open Finance',
    'Add an expense',
    'Add income',
    'Recent transactions',
    'Accounts',
    'Categories',
    'Transfer between accounts',
    'Finance analytics',
    'PLUS access and subscription',
    'Contact support',
    'Payment support',
    'Terms of service',
    'Help',
  ],
  uk: [
    'Відкрити Finance',
    'Додати витрату',
    'Додати дохід',
    'Останні операції',
    'Рахунки',
    'Категорії',
    'Переказ між рахунками',
    'Аналітика Finance',
    'Доступ PLUS і підписка',
    'Зв’язатися з підтримкою',
    'Підтримка з оплати',
    'Умови користування',
    'Допомога',
  ],
  ru: [
    'Открыть Finance',
    'Добавить расход',
    'Добавить доход',
    'Последние операции',
    'Счета',
    'Категории',
    'Перевод между счетами',
    'Аналитика Finance',
    'Доступ PLUS и подписка',
    'Связаться с поддержкой',
    'Поддержка по оплате',
    'Условия использования',
    'Помощь',
  ],
};

const LOCAL_LIFECYCLE = {
  started: {
    uk: '✅ Локальну версію Finance запущено. Посилання Mini App оновлено.',
    ru: '✅ Локальная версия Finance запущена. Ссылка Mini App обновлена.',
    en: '✅ Local Finance is running. The Mini App link has been refreshed.',
  },
  stopped: {
    uk: 'Локальну версію Finance не запущено. Запустіть pnpm dev:bots, а потім надішліть /start.',
    ru: 'Локальная версия Finance не запущена. Запустите pnpm dev:bots, затем отправьте /start.',
    en: 'Local Finance is not running. Start pnpm dev:bots, then send /start.',
  },
} as const;

@Injectable()
export class FinanceTelegramPresentationService implements TelegramBotApplicationPresentation {
  readonly applicationType = TelegramBotApplicationType.FINANCE;

  commands(locale = 'en'): TelegramBotCommand[] {
    const resolved = this.resolveLocale(locale);
    const [
      start,
      expense,
      income,
      recent,
      accounts,
      categories,
      transfer,
      analytics,
      plus,
      support,
      paysupport,
      terms,
      help,
    ] = COMMAND_DESCRIPTIONS[resolved];
    return [
      { command: 'start', description: start },
      { command: 'expense', description: expense },
      { command: 'income', description: income },
      { command: 'recent', description: recent },
      { command: 'accounts', description: accounts },
      { command: 'categories', description: categories },
      { command: 'transfer', description: transfer },
      { command: 'analytics', description: analytics },
      { command: 'plus', description: plus },
      { command: 'support', description: support },
      { command: 'paysupport', description: paysupport },
      { command: 'terms', description: terms },
      { command: 'help', description: help },
    ];
  }

  supportedLocales() {
    return ['uk', 'ru', 'en'] as const;
  }

  menuButton(botIntegrationId: string, locale = 'en') {
    return financeChatMenuButton(botIntegrationId, this.resolveLocale(locale));
  }

  miniAppUrl(botIntegrationId: string) {
    return financeMiniAppUrl(botIntegrationId);
  }

  resolveLocale(preferred: string | null, fallback?: string | null) {
    return financeChatLocale(preferred, fallback);
  }

  localDevelopmentActive() {
    return Boolean(publicWebOrigin());
  }

  localLifecycle(
    state: 'started' | 'stopped',
    botIntegrationId: string,
    locale: string,
  ) {
    const resolved = this.resolveLocale(locale);
    return {
      text: LOCAL_LIFECYCLE[state][resolved],
      ...(state === 'started'
        ? { replyKeyboard: financeMainMenu(botIntegrationId, resolved) }
        : {}),
    };
  }
}
