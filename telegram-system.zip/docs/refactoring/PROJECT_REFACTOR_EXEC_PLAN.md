# Project Refactor ExecPlan

Updated: 2026-11-03

## 2026-11-03 Site performance initiative — Publication Calendar first slice

The site-wide performance pass is in progress, starting with Publication Calendar. Its exact-range query is persisted under the existing workspace-scoped schedule key; a five-minute stale window enables immediate same-range revisits with a background refresh, while range changes do not reuse the prior range as placeholder data. Ad placement and VP mutations invalidate only the calendar query family, leaving schedule-list reads fresh. Calendar slots/events are indexed by local day once per response instead of filtering full collections repeatedly during rendering. The supplied browser capture is the baseline: the calendar API request took 2.59s and the route RSC requests took 4.49s and 2.11s; post-change browser timings have not yet been captured. Focused tests cover DST matching, indexed slot/event rendering, and targeted calendar invalidation. The Telegram Posts workspace now skips its full managed-post list request in Groups and Hypotheses views; switching back to Posts uses the existing query cache and normal stale refresh. Targeted post/calendar cache tests pass. The Ad Campaigns route no longer fires its unused performance summary read; repository search showed no consumer of its result, while the API query loaded every matching campaign and its channel plus the last sync run. The now-dead frontend query cache key/invalidation path was removed. Its mutually exclusive mutual-promotion folder and plan screens are now dynamically loaded, with a route-aware loading shell preserving the app navigation, section title and tabs. The production build succeeds and focused route tests pass (11 tests); generated route manifest confirms separate asynchronous module groups for those screens. The route was reduced to its existing 2,382-line shrinking-only ceiling; the matching page-query allowance was lowered from 20 to 19. Web typecheck passes. The architecture gate has no new violation from this slice, but still fails on existing repo-wide debt in unrelated/currently edited files. Browser timing capture remains pending because the in-app browser opens localhost at the sign-in screen and has no authenticated workspace session. Next work is to establish a local authenticated QA path, measure calendar/post cold and warm paths, inspect the API hot reads, then repeat the read/cache/invalidation audit across the remaining major tabs. Runtime work remains request-driven: no polling, timers, background jobs, database writes, or additional reads on idle.

## 2026-11-03 Channel post reminders

Added workspace reminder templates and channel assignments, due-driven coverage checks, and per-member System Bot and web-push preferences through Operations Notifications. The existing scheduler supplies claims and restart recovery; eligible channels are checked in workspace batches and notifications are grouped by recipient. Grace/Knuth/Parnas preflight and Turing integration review were performed. Operational limits, retention and the 100-channel cost model are documented in [channel post reminders](../external-integrations/channel-post-reminders.md).

## 2026-10-30 CRM Inbox 2.0 and shared Chat UI

Implemented a neutral browser Chat UI and a CRM-owned adapter, compact cursor conversation read model, mounted desktop list/thread/details, single-screen mobile navigation, canonical workspace conversation drafts, idempotent retries and scoped SSE cache reconciliation. Existing Telegram runtime and message store are reused. Incoming edit events use the existing update result. No schema/index, worker, polling, recurring DB work, AI call or Support implementation was added. Grace/Knuth/Parnas preflights and Turing integration review were performed; review regressions are covered before handoff. Architecture retains the same 20 pre-existing errors with no new allowance. Full behavior, capability limits, verification and cost model: [CRM Inbox 2.0](../plans/crm-inbox-2.md).

## 2026-10-30 Finance independence audit and safety gate

The standalone Finance host is not ready for cutover. A read-only
`finance-api migration:plan` found distinct source/destination databases, but
the source has 28 Finance tables (714 rows) and the destination has 11 Finance
tables (8 rows). Shared-name Account, Profile, and Transaction tables lack
4, 12, and 20 source columns respectively. The standalone API does not yet
serve the existing Web client's startup, ledger reads, obligations,
investments, browser challenge, or AI contracts. Its Telegram webhook lacks a
command/callback dispatcher. Until those paths and a reconciled staging
restore are implemented, the legacy Finance runtime remains the webhook
owner and data source; standalone startup cannot take over that webhook, and
signed updates received there return 503 without being marked processed.
`migration:extract --execute` is blocked to prevent an incompatible partial
copy. See `docs/refactoring/FINANCE_INDEPENDENCE_CONTRACT.md` for the cutover
gates. No production data was changed in this audit.

## 2026-10-18 Finance host namespace

Consumer Finance remains at `products/finance/{api,bot,web}`. Its independent
runtime hosts now live at `apps/standalone/finance/api` and
`apps/standalone/finance/web`, replacing the flat `apps/finance-api` and
`apps/finance-web` directories. The `apps/standalone/*/*` workspace glob makes
room for future products without conflating a product implementation with its
runtime host. TypeScript/Jest/Vitest aliases, Tailwind sources, deployment
watch paths, local profile readers, and host tooling point to their respective
new locations. Package names, public API and web URLs, data contracts,
database records, and runtime behavior are unchanged; this relocation adds no
process, polling, persistence, network request, or deployment.

## 2026-10-03 Finance Pro and Greeter product boundaries

Consumer Finance implementation now lives in `products/finance/api`,
`products/finance/bot`, and `products/finance/web`; Greeter now lives
in `products/greeter/api` and `products/greeter/web`. The Nest and Next apps
retain composition, route entrypoints, proxy behavior, Prisma ownership, and
the single Railway deployment. Product workspace manifests make their direct
runtime dependencies explicit. Nest uses one production bundle so code outside
the API source root still resolves through the unchanged `apps/api/dist/main.js`
entrypoint. No database models, migrations, API URLs, frontend URLs, or
environment variables changed. Generic Telegram infrastructure remains in
`apps/api/src/telegram/shared` and `telegram-bots/core`; no second platform
package was introduced because it would only repackage existing infrastructure.

Historical note: this 2026-10-03 record predates Greeter retirement. As of
2026-10-17, its source product, routes, runtime wiring, and shared contracts
are removed; the non-destructive database transition is documented in
`docs/refactoring/PRODUCT_SPLIT_PLAN.md`.

## 2026-09-20 Investor profit at historical ownership shares

Internal Finance now derives investor profit from the chronological operating
ledger: eligible Telegram income less confirmed operating expenses and the
seller commission. Each event is allocated using capital accumulated strictly
before that event, so a later contribution cannot alter an earlier split. The
calculation is read-time and uses bounded workspace reads, adding no timer,
polling, background work, duplicated ledger rows, or per-member HTTP joins.
Manual reinvestment distribution and withdrawal controls are no longer exposed;
salary payout and salary-to-capital remain separate decisions.

## 2026-09-20 System-wide exchange-rate reference data

Exchange-rate observations are now system-owned rather than copied into every
workspace. The database keeps one historical observation per
base-currency/target-currency/UTC-day; the migration deterministically merges
legacy duplicates, preferring official-provider data. Workspace currency
settings remain workspace-local because they only choose how that workspace
displays amounts.

The manual create, edit, delete, and sync rate surfaces were removed from both
the API and the Finance UI. A non-editable system-maintenance task fetches the
canonical EUR rate graph once daily. Historical and lazy current-pair lookups
read the same global graph, with de-duplicated writes and no workspace scan.
At 100 workspaces this remains one scheduled provider request and one bounded
batch insert per day, rather than 100 independent syncs and copies.

## 2026-09-17 Autogenerated CPM pricing and canonical sorting controls

Autogenerated channel messages can now render either the existing public sales
price or a price calculated from each channel's internal CPM. Both variants are
prepared from the same bounded channel/product pricing batch; changing the
editor option performs no additional request and does not duplicate financial
math in the browser. A missing internal CPM is shown as unavailable instead of
silently falling back to the public price. The existing short channel
description remains sourced from Appearance settings and its API limit now
matches the 240-character editor limit.

Internal paginated lists use a canonical field selector plus an adjacent
ascending/descending button. Ad campaigns and CRM clients share the internal
control; Consumer Finance keeps a product-owned localized equivalent. Campaign
cost and joined ordering and investment ordering execute in the database before
pagination with deterministic id tie-breakers. Investment monetary sorting uses
valuation-currency-normalized columns so unlike currencies are not compared as
if they were equal. The template calculation reuses one pricing read for up to
100 channels, and sorting adds no timer, polling, background process, unchanged
write, or per-row HTTP/SQL request.

## 2026-09-17 Telegram channel traffic-source attribution

Telegram channel cards now expose a compact source-attribution summary and a
lazy-loaded detail modal for mutual promotion, folders, ad campaigns, audience
transfer, bot, broadcast, and otherwise unclassified invite links. The stable
shared read model reports acquired peak, retained audience, drop from peak,
paid-source CPA, per-source rows, and a bounded history series. Folder rows use
their saved attribution boundaries and primary-currency expense; ad campaigns
use their primary-currency campaign spend. One invite link is classified under
one source kind so overlapping campaign/folder/mutual configuration cannot
double-count it, while separate reuse windows inside the same source kind stay
visible as separate rows.

The channel list remains one HTTP request and performs six batched,
workspace-scoped reads for up to 100 channel cards, plus one bounded lateral
boundary lookup when completed mutual placements are present. It does not scan
raw invite history to calculate peaks: `TelegramInviteLink.peakAttributedCount`
is backfilled from current counters and existing snapshots, then advanced in
the existing invite sync upsert and protected from concurrent regression by a
database trigger. Direct-mutual JSON targets are filtered in PostgreSQL and
covered by a GIN index; the campaign lookup has a
workspace/channel/analytics index.
The detail endpoint is fetched only when the user opens the modal and caps raw
history at 5,000 rows. No timer, polling loop, background process, external
request, unchanged-state write, or new retention stream is introduced.

Frontend list/detail cache keys are separate and sync completion invalidates
only the affected attribution family. The legacy channels page shrank by
extracting its cohesive catalog card, and its shrinking-only size/API-import
allowances were lowered in the same change. Focused backend and frontend tests
cover calculations, workspace isolation, cross-source deduplication,
same-source folder reuse, the 100-channel bounded-read case, compact card UI,
loading/error/retry/empty/detail modal states, and sync invalidation.

## 2026-09-15 Canonical workspace-local modal draft sessions

This completed frontend refactor makes the existing workspace modal draft storage,
React hook, and picker the only lifecycle for unfinished browser-local forms.
Features continue to own their serializable value, seeded defaults,
normalization, meaningfulness rule, restore mapping, and compact preview data.
The shared layer owns workspace keys, IDs and timestamps, legacy decoding,
initialization, autosave deduplication, multiple drafts, picker transitions,
and successful-submit cleanup.

The accepted runtime boundary is localStorage only. It adds no API, React Query,
PostgreSQL/Neon read or write, Railway process, background job, service worker,
interval, external lookup, or query invalidation. New picker metadata is stored
with each draft and rendered locally; legacy rows degrade to a local fallback
instead of fetching icons. Selecting 100 channels changes only the browser-local
serialized form and performs zero backend operations.

Grace Explorer mapped the shared and bespoke draft paths, Knuth Performance
confirmed the zero-backend cost boundary, and Parnas Structure completed both
the read-only preflight and clean final structural review. Ada Frontend migrated
Ad Sale, Promo, both Cross Promotion modes, Mutual Folder create/edit, Post
Batch, publication schedules, Campaign/Hypothesis, and message templates.
Turing Review found and drove fixes for a workspace-switch autosave race and
untouched prop-seeded Ad Sale drafts, then completed a clean final re-review.

The final storage contract uses a versioned multi-draft envelope with immutable
creation time, change-only update time, local preview metadata, normalization,
corrupt-data repair, quota-safe writes, and merged canonical/legacy-key
migration. A generation guard prevents a previous workspace or modal invocation
from writing through a newly initialized session. Successful-submit cleanup
invalidates the in-memory envelope, so a later render cannot recreate it.

Final focused validation passes 16 Web files/74 tests, including storage/hook,
picker, Ad Sale characterization, Promo, both Cross modes, Mutual Folder,
Post Batch, schedules-related editor behavior, and message templates. Web
typecheck and production build, targeted ESLint, architecture policy 18/18,
and `git diff --check` pass. The normal architecture size stage retains seven
unrelated surrounding-worktree shrinking-baseline overruns; this slice removed
the prior Ad Campaigns page overrun, lowered its allowance from 2464 to 2429,
and kept every touched draft production unit at or below 400 lines. The new
developer guide is `docs/design-system/MODAL_DRAFTS.md`.

Runtime acceptance remains exact: additional Neon reads and writes are zero;
Railway background CPU and recurring jobs are zero; normal autosave performs
zero external HTTP requests; selecting 100 channels performs zero backend
operations. Storage grows only with meaningful local drafts created by the
user. Writes occur only after a changed meaningful browser snapshot; identical
state is deduplicated and empty seeds are removed. No backend service, database
schema, React Query persistence, service worker, timer, or background sync was
added for modal drafts.

## 2026-09-15 Canonical website-driven System Bot post import

This completed refactor replaces feature-specific Ad Sale, Promo, Mutual
Promotion, and Post Batch capture transports with one Telegram-owned contract.
The public capture modes are only `single` and `multiple`; both return normalized
`TelegramSystemBotPostDraft[]`. Business consumers remain responsible for
channels, slots, scheduling, validation, and persistence after capture. The
ordinary `/post` bot wizard retains its separate channel/publication semantics.

The accepted runtime design is request/event-driven. Idle, hidden, terminal,
and unmounted consumers perform no import reads. One visible active workflow
uses one bounded, visibility-aware reconciler with a slower backoff than the
legacy feature hooks, and active reads use a compact workflow projection rather
than repeatedly loading the growing JSON payload. No cron, worker, database
heartbeat, SSE/WebSocket, persistent cache, telemetry writer, service, or
unchanged-state write is introduced. Capture cost is independent of selected
channel count; channel fan-out begins only in the owning domain submit flow.

Grace Explorer and Knuth Performance mapped the original paths and costs;
Parnas Structure completed preflight and a clean post-remediation audit. The
initial worktree was clean. All changed handwritten services, hooks, and React
components are below their applicable size targets, the canonical layers have
no reverse Growth dependency, and old feature-specific runtime paths are gone.
Architecture policy tests pass 17/17; the normal gate retains only the same
eight unrelated pre-existing shrinking-baseline overruns. Turing Review found
and drove fixes for OWN_CHANNELS access, recovery ownership and target routing,
single-poller handoff, same-workspace cross-user consumption, and same-mode
start hijacking before its final integration pass.

Final focused validation passes 8 API suites/80 tests and 8 Web files/45
tests. Shared typecheck/build, API build, Web typecheck/build, Prisma client
generation and schema validation, targeted API/Web lint, and diff checks pass.
API typecheck remains red only on the pre-existing
`telegram-channel-catalog-select.spec.ts` preview typing error. The full Web
suite passes 1,285/1,298 tests; its 13 failures are in nine unrelated legacy
suites. The full API run exposes the existing Regular Payments mock failure and
development force-exit behavior; all refactor-focused suites pass.

Runtime cost remains bounded and request-driven. Idle imports add zero queries,
writes, timers, processes, or connections. A visible ACTIVE import has one
module-coordinated poller: one compact metadata row per read, every second for
the first ten seconds and every three seconds afterward, capped at 120 visible
seconds (about 47 reads at the cap versus about 94 in the replaced flow).
Hidden, unmounted, timed-out, and terminal states read nothing. Start writes one
workflow and attaches one control message; each accepted forward performs one
versioned payload transition, albums update the same logical draft, and
finish/cancel performs one versioned status transition. No unchanged-state
writes were added. Completed payload is loaded once, and downstream consumers
claim it atomically with their domain write.

Telegram traffic occurs only for user actions: create/edit the control card,
existing media download/storage calls for forwarded media, input cleanup, and
one or two preview messages depending on content. Capture is O(1) in selected
channel count; 100-channel fan-out remains solely in the later domain publish
operation. No Railway service, worker, Redis, heartbeat, SSE/WebSocket, or
long-lived connection was added, so idle CPU/RAM/network and Neon scale-to-zero
behavior are unchanged. Persistence adds one workflow row per import under the
existing workflow retention policy; no new retention stream or cleanup job was
introduced.

## 2026-09-14 Telegram publication schedules, unified import, and content hypotheses

Telegram Channels now owns reusable workspace publication schedules with typed
CONTENT, AD, and MUTUAL_PROMOTION weekly slots. Channels adopt the complete
schedule or an explicit subset. A scheduled managed post persists both the
chosen slot and the concrete UTC occurrence; the API validates the channel
assignment and the slot's weekday/time/timezone before using the existing
publication path. Legacy daily time posts are migrated into seven explicit
weekly content slots per configured time and retained only for rollback during
the compatibility window.

Content hypotheses are a Telegram-owned aggregate, deliberately separate from
Growth advertising hypotheses. A hypothesis has lifecycle state, optional icon,
theory/conclusion, many-to-many managed-post links, and bounded aggregates over
current Telegram post counters. Subscriber change is labelled as the observed
channel delta during the hypothesis window rather than causal per-post churn.
The feature reuses existing audience/post snapshots and adds no metric collector.

The former posts/groups/calendar/delete entry points now lead through one
versioned import manifest. Preview returns separate group, hypothesis, post, and
schedule sections after one workspace-scoped preflight. Apply requires the exact
preview hash, executes dependency order, returns per-section outcomes, and
passes typed slot identity through the existing publication service. Database
commands remain bounded and Telegram side effects are never held inside a
database transaction.

Unified apply intentionally has explicit partial-result semantics because
native Telegram scheduling cannot participate in the same database transaction
as group/post mutations. Every section returns its failures, the UI stays open
when any operation fails, and a retry uses a newly generated preview/hash.
Destructive automation must name exact IDs; omission never means delete. This
favors observable recovery over claiming false cross-system atomicity.

GPT context format 6 and calendar instruction format 4 expose assigned typed
slots, content hypotheses, and the unified version-1 manifest. All new runtime
behavior is request/event-driven: no cron, polling, timer, heartbeat, worker, or
unchanged-state write was added. At 100 channels, stored assignments add rows
but no idle work; reads are scoped to the opened channel/workspace, occurrence
generation is bounded to 62 days, and hypothesis metrics are fetched in batched
channel reads rather than per-card requests.

## 2026-09-08 Consumer Finance debts and regular payments

This slice adds two FinanceProfile-owned aggregates without crossing into the
internal Finance product. Debts own direction, account-native amount, due date,
derived overdue state and one atomic ledger settlement. Regular payments own an
account-native amount, optional expense category, weekly/monthly/yearly calendar
anchor, one next useful occurrence and append-only configuration/status
revisions. Confirmed occurrences are financial audit records; advancing the
schedule alone is not a configuration revision.

Regular payments deliberately coexist with simple Reminders. Reminder delivery
may advance after send; regular-payment delivery is a one-shot prompt and may
advance only after a guarded user confirmation carrying the exact expected
occurrence. Both features reuse the existing `TelegramBotDelivery` outbox,
leases, retries, bounded batches and single nearest-due timer. Domain state and
the next delivery are written in one Prisma transaction through a stable
transaction-aware platform port. After commit, a new row only notifies the
existing scheduler of an earlier candidate; replacement first arms its committed
candidate and then recomputes the shared earliest wake, so it can neither delay
another product's delivery nor lose a wake if the recompute fails. No cron,
polling, scan, worker, heartbeat, per-entity timer or Railway service is added.

The cross-stack contract uses bounded profile-scoped read models with compact
account/category presentation, account-derived currency, narrow query keys and
two module-scope lazy frontend screens. Settlement and payment confirmation use
`FinanceLedgerService.createTransactionInTransaction`; stale/double requests
return the already linked transaction and never pay the following occurrence.
The confirmation guard carries both the exact occurrence and the presented
configuration version; confirmation advances the state CAS token, so a stale
Telegram button or concurrent edit cannot settle a different amount/config.
Adopting an overridden occurrence amount is a separate version-guarded command
that creates exactly one real revision. Profile export/deletion includes the
new aggregates, revisions, occurrences and related delivery payloads. Calendar
obligations snapshot their schedule timezone, and category revisions snapshot a
stable localization key. Deep links use an exact profile-scoped, active-row
lookup rather than a client-side first-page search.

Grace/Knuth/Parnas/Turing review completed with no release-blocking findings.
All new handwritten production files are within the 100–400 target (largest:
397 lines), and architecture policy tests pass 16/16. `db:generate`, Prisma
validate, shared typecheck/build, API typecheck/build, Web typecheck/build,
targeted lint, 54 targeted API tests, 28 targeted Web tests, i18n and diff checks
pass. The full API run passes 336 suites and 1843 tests, with three unrelated
pre-existing suites failing (two CRM assertion drifts and one missing
`Reflect.getMetadata` setup). The full Web run passes 209 files and 902 tests;
its sole unrelated failure is the existing Ad Sales publication-preview
fixture. Full Web lint remains at the inherited 160 errors/231 warnings, while
the changed obligation files are clean. The architecture command remains red
only on the same seven unrelated shrinking-baseline violations.

Runtime cost is event-driven. New recurring jobs/processes/timers: zero; after
the existing scheduler bootstrap, an empty queue performs no periodic DB work.
Debt create is two persisted rows (debt + delivery), a real edit is at most
three changed rows (debt, canceled delivery, replacement), settlement is two
domain rows plus cancellation, and duplicate/no-op requests write nothing.
Regular-payment create is three rows (payment, first revision, delivery), a
real edit is at most four, pause/cancel or resume at most three, and confirmation
is four domain rows (transaction, occurrence, schedule advance, next delivery).
Applying a changed future amount adds one payment update, one revision, and a
delivery replacement. At 100 debts plus 100 regular payments there are at most
200 pending delivery rows but still one timer; if all mature together they drain
in eight batches of 25 plus the final empty claim. Revisions grow only on real
configuration/status changes and occurrences only on confirmations; durable
delivery retention remains 30 days. Neon scale-to-zero and Railway idle
CPU/RAM/network baselines are unchanged; network and retry cost occur only for
actual Telegram notifications.

## 2026-09-08 Consumer Finance surface and frontend boundary

Consumer Finance Web App and Telegram Mini App now share one explicit screen
model while remaining isolated from internal Finance implementation. Settings
owns profile and privacy only; Reminders and Plans/Billing are independent
destinations. Accounts use a collection screen plus a browser-history-aware
full-page create/edit route, and malformed or missing account deep links return
to a recoverable Accounts state.

The eager shell keeps Dashboard and a small typed `en`/`uk`/`ru` core copy.
Accounts, account editor, Analytics, Budget, Categories, Onboarding, Plans,
Reminders, Settings, Transactions, Transfers and Ultimate are module-scope lazy
screens with feature-local copy. The former monolithic Consumer Finance i18n
modules were removed. Eager locale updates use a narrow profile API client;
planning, billing, reminders, ledger, timezone and emoji-picker implementation
remain outside the initial Home graph and no hidden screen is prefetched.

Transactions now starts account, category and history reads in one render wave;
Transfers starts accounts and history together; Budget starts Dashboard,
categories and smart limits together without a duplicate cold limits request;
Plans starts entitlements and catalog together. Locale-only changes no longer
refetch Dashboard, account creation cannot populate a partial collection cache,
and all mutations keep bot-scoped keys and narrow cache updates. Dashboard uses
hydrated `iconPresentation` without `/icons/:id` joins. No timer, polling,
per-row request, persistent cache, worker, database write path or Railway
service was added; idle and 100-channel cost remain unchanged.

Final Grace/Knuth/Parnas/Turing review corrected repeated action reopening,
account deep-link/cache handling, paid-plan duplicate checkout, Stripe/Stars
price compatibility, subscription-specific renewal state and localized billing
status/mode display. All touched handwritten Consumer Finance production files
remain below 400 lines. Web typecheck, production build, API build, focused API
and 150 focused Consumer Finance tests, i18n parity/check and `git diff --check`
pass. Targeted lint for every changed Consumer Finance TypeScript file has zero
errors (two existing Telegram-avatar `<img>` warnings); full web lint remains
red on 160 errors and 231 warnings outside this slice. The full web run passes
872 of 873 tests; its sole stable failure is an untouched Ad Sales lifecycle
fixture that lacks the linked-post state now required to render `Publication
pending`. Architecture policy tests pass 16/16; the gate remains red only on
the same seven unrelated pre-existing size/direct-access baseline violations.

## 2026-09-06 CRM reply attention and grouped notifications

CRM Contact cards now consume persisted per-Conversation inbound/outbound
Message counters and existing read/last-direction compacts instead of scanning
Message history. The reply summary distinguishes a first inbound Message from
an unanswered established Conversation and distinguishes Telegram-read from
Telegram-unread state. A Contact-level `replyAlertMutedAt` suppresses only the
visual urgency treatment; it does not delete Messages or falsify the underlying
reply status.

The forward migration initializes both counters with one grouped scan of
`TelegramCrmMessage`. Thereafter live ingest, history import, and manual sends
update counters only when a Message is newly persisted, while sync reconciles
the compact facts without unchanged-state writes. Counts are marked complete
only after Conversation history is exhausted.

Fresh inbound notification projection keeps at most one active CRM Message
group per Contact (falling back to Conversation before Contact promotion) and
carries compact sender/avatar/count presentation. Telegram read synchronization
reconciles the Contact's aggregate unread count and removes the group when it
reaches zero, so already-read Messages do not remain in Notifications. This is
event-driven: there is no
polling, timer, heartbeat, per-card aggregate, or additional Railway service.
At 100 active Conversations, one page still performs bounded Contact and
notification reads; cost grows with newly persisted/read Messages rather than
idle time or stored history.

## 2026-09-06 Scheduled Telegram CRM source sync

Telegram CRM source selection remains owned by the CRM account capability
contract (`crmSyncEnabled`). The contacts surface now exposes that selection in
a compact modal, while both manual imports and the scheduled task consume the
same selected connected MTProto accounts.

The existing persisted scheduled-task runner now registers
`telegram.crm.sync` as a workspace operation with a daily schedule. It runs
accounts sequentially, records results in the shared Scheduled Tasks history,
and is automatically disarmed when no eligible CRM source exists. Capability
changes signal the existing one-shot scheduler wake path, so this adds no cron,
polling loop, or idle database wake. At 100 selected accounts one daily run is
bounded to 100 sequential MTProto imports; idle workspaces perform no scheduled
CRM sync and unchanged account selection creates no capability write.

For a Conversation that has not yet been history-warmed, the same sync fetches
51 newest Telegram Messages with concurrency capped at four and stores no more
than 20 Conversations per database transaction. The first chat request can
therefore return 50 rows entirely from Neon and expose `Load older` only when a
51st row exists. A persisted history cursor/exhausted marker prevents later
daily runs from downloading that page again.

## 2026-09-06 Workspace-wide Telegram Premium emoji

Premium emoji packs now use their existing `workspaceId` ownership directly.
The legacy channel-pack join table and channel-targeting API are removed by a
forward migration that preserves every pack and emoji, so existing imports
become available to current and future channels in the owning workspace.

Post and CRM message editors share one compact Standard/Premium picker. Premium
packs are fetched only when the user opens the Premium tab, cached under one
workspace query key, and imported or deleted through workspace-level endpoints.
GPT context export reads the same workspace pack set. The change adds no timer,
polling, background task, recurring database write, or per-channel request; at
100 channels, opening Premium remains one bounded workspace query and importing
a pack no longer creates 100 attachment rows.

Pack removal is reversible archival. Archived packs are excluded from editors
and GPT context but retain their database-owned immutable B2 asset references;
re-import restores them without Telegram or B2 traffic, avoiding orphaned
storage objects and requiring no background cleanup job.

## 2026-09-03 CRM customer-message automation removal

The customer-facing CRM automation product slice has been removed end to end.
The Clients UI no longer exposes Automation controls or status copy; shared
contracts and RBAC no longer publish the opt-in surface; API controllers,
materializers, delivery services and Ad Sales fact callbacks are gone. The
persisted one-shot scheduler no longer registers or executes the customer
automation task.

The schema migration removes the execution queue, opt-in/override fields,
automation-specific notification type and permission rows. Existing automated
Message history is retained as `SYSTEM` history before the obsolete origin and
execution link are removed. Creating, promoting, merging, or changing a Contact
or Deal therefore creates no customer-message work. Manual Message sending is
unchanged and remains an explicit permissioned user action.

This removal reduces idle Neon/Railway work: there is no customer-automation
due lookup, timer, queue claim, write, or Telegram request at 1 or 100 channels,
and no new runtime service or retention surface is introduced.

## 2026-09-01 CRM Notification Center and Web Push

Stage 5 adds a generic operations Notification Center without merging it into
CRM customer messaging or the existing Scheduled Task/System Bot notification
path. CRM projects only fresh live inbound Messages and explicit internal CRM
events; the operations module owns compact persisted notifications, member
unread/preferences, User-device Web Push subscriptions, transport, realtime,
and bounded retention.

Incoming projection is transactionally idempotent with Message persistence.
Initial import, history, edits, outgoing/manual messages, application startup,
and duplicate Telegram updates create no extra notification or Push. Center and
Push share exact workspace-aware deep links, while backend authorization remains
authoritative after workspace switching.

Push is explicit, event-driven, best-effort at-most-once, and disabled unless a
complete validated VAPID key set exists. The service worker has no polling,
periodic sync, cache refresh, or heartbeat. Follow-up publication and
90-to-91-day UTC-bucketed retention reuse the one-shot due scheduler; idle notification cost is zero
recurring work and no Railway service is added.

Final integration review moved the scheduler wake signal to a neutral common
bridge, centralized source visibility for REST/SSE/due/publish paths, and made
Contact owner changes revoke published previews plus transfer pending rows in
the same transaction. Retention is indexed by full expiry order and bucketed
to one UTC-day wake, while Push loads devices before claiming, caps each User at
five active devices under a transaction-scoped User lock, and shares one
eight-request process-wide fanout limit. Exhausted automation failure projection
is capped at 25 executions per due run so recipient resolution cannot hold one
transaction across an unbounded number of workspaces.
Pending follow-ups cross a narrow due-resolution port: CRM recomputes the
current owner/Deal-assignee/fallback recipient and source RBAC inside the due
transaction, while the generic operations module remains unaware of CRM models.

## 2026-09-01 CRM customer-message automations

Stage 4 activates a separate CRM Automations layer after the CRM foundation,
MTProto runtime, and Contact-centered UI. Ad Sales emits fresh business facts;
CRM alone evaluates cutovers and consent, resolves a fixed Conversation,
renders localized customer copy, sends through the Conversation's MTProto
account, and records the attributed execution and Message.

The rollout remains fail closed. Migration creates no occurrences, executions,
Conversations, Messages, or Telegram calls; existing Contacts remain off and
pre-Stage4 Deals remain protected. Startup, settings enablement, initial CRM
Sync, Peer promotion, Contact stage changes, historical publications,
`nextContactAt`, and internal follow-up tasks do not backfill customer events.
Only explicit future domain mutations may create a due occurrence whose
business timestamp is after every applicable activation boundary.

The existing CRM customer execution record becomes an indexed, leased,
idempotent due/send state machine. The legacy advertiser automation tables
remain internal-task-only. Scheduling reuses the persisted one-shot scheduler:
one nearest-due timer, bounded claims, no minute cron, no Deal/workspace scan,
no per-Deal timer, no new Railway service, and zero incremental recurring DB or
Telegram work while idle.

The final send authorization is serialized against current Workspace,
Contact, Deal, placement/channel/post, Conversation, and account mutations.
The worker locks and reloads those rows, rechecks cutovers/source identity, and
only then commits `SENDING`; a prior OFF/reschedule/delete commit therefore
produces zero runtime calls. Expired ambiguous sends keep their pinned envelope
and become an explicit failed/uncertain audit outcome when current gates no
longer allow an idempotent retry. Composite workspace foreign keys remain in
force, with Deal deletion atomically unlinking only mutable audit pointers.
Dedicated and generic Deal cancellation converge on one atomic lifecycle write;
the final locked send barrier independently rejects `CANCELLED`, including when
the best-effort post-commit fact callback fails.

## 2026-08-31 Contact-centered CRM web application

Stage 3 makes `/ad-sales` a Contact-centered CRM while retaining the existing
Sales, Calendar, Analytics, placements, pricing, availability, payment,
checkout, and publication-lifecycle implementations. The former page remains a
route integrator; focused CRM components own Contacts, Inbox, stable Contact +
Conversation deep links, account-specific threads, cursor Message history,
unread state, explicit promotion, and automation safety presentation.

The cross-stack contract adds purpose-built compact Contact/detail,
Conversation, Inbox, unread, and Message cursor read models. It does not return
full histories or introduce frontend joins. CRM cache state is workspace
scoped and non-persisted; one authenticated event stream drives narrow cache
updates, with no polling or root-wide invalidation.

Customer automation remains execution-inert. The UI exposes explicit future
Contact consent, workspace/type configuration, and protected Deal overrides,
but no runner, cron, queue, heartbeat, historical backfill, or implicit opt-in
is added. Account capability controls keep CRM Sync, CRM Send, and MTProto
Publishing independent, and the default sender applies only to a new
Conversation.

## 2026-08-31 Telegram CRM multi-account runtime and Inbox

Stage 2 continues the Contact-centered CRM foundation with an event-driven
MTProto runtime. One process-local client is maintained per eligible account;
there is no global master account, database/Telegram polling, cron, heartbeat,
or new worker service. Existing Conversations keep their fixed account while
the workspace default is consulted only when creating a new Conversation.

The runtime adds explicit bounded private-dialog import, batch-idempotent live
updates, bounded `GetDifference` recovery, lazy history, numeric read state,
manual idempotent sending, Inbox classification, Peer promotion, transactional
Contact merge, and a process-local authenticated event stream. Telegram
protocol details stay in `telegram/shared`, while focused CRM services own
workspace-scoped persistence and authorization. The MTProto facade and account
service continue shrinking and their architecture ceilings are lowered.

The rollout remains automation-inert: no customer automation runner, schedule,
send, execution, opt-in mutation, or historical backfill is introduced. Manual
sending is independently permissioned and account-capability gated. See
`docs/architecture/CRM_ARCHITECTURE.md`.

## 2026-08-31 Contact-centered CRM foundation

Stage 1 evolves the existing Ad Sales CRM without adding parallel Contact or
Deal storage. `TelegramAdvertiser` remains the Contact backing entity and
`TelegramAdSale` remains the Deal. The two persisted advertiser lifecycle
fields are replaced by one authoritative CRM Contact stage; legacy API fields
are compatibility projections only, and active-Deal state remains derived.

The new focused `domains/telegram/telegram-crm` boundary owns Contact, stable
Telegram Peer identity, Conversation/Message persistence, per-account sync
state, CRM settings, independent account capabilities, and a pure fail-closed
customer-automation policy. It does not import the Ad Sales service or Telegram
protocol SDK. Ad Sales continues to own sales, placements, payments, pricing,
calendar, availability, and analytics.

Rollout is deliberately inert: existing/new Contacts have customer automation
off, existing Deals are migration-disabled and ineligible, workspace/type
switches default off, and migration creates no Messages, Conversations, sync
states, due events, or automation executions. No cron, polling, heartbeat,
startup scan, worker, queue, persistent MTProto connection, telemetry writer,
Redis, or Railway service is introduced. See
`docs/architecture/CRM_ARCHITECTURE.md`.

## 2026-08-30 Cross-stack operations slice

The workspace members, Ad Sales, Telegram channel sync, and Internal Finance
flows were extended together while reducing transitional file debt:

- the workspace member modal was extracted from the members section and its
  redundant nested framed surfaces were removed;
- Ad Sales client selection and placement lifecycle presentation were extracted
  into focused components, and publication refresh is bounded to an active due
  event instead of idle polling;
- workspace-wide manual channel sync reuses the canonical channel orchestrator
  through one server request and sequential per-channel execution;
- transaction category/member validation was extracted from the transactions
  service while adding the system Salary expense category.

The slice adds no production cron, recurring idle work, schema migration, or
per-entity browser joins. Shrinking-only architecture baselines are lowered in
the same change after the final measured scan.

## Current State

`telegram-system` is a pnpm monorepo with:

- `apps/api`: NestJS API with Prisma and Telegram Bot/MTProto integration.
- `apps/web`: Next.js App Router frontend with React Query and Tailwind v4 CSS.
- `packages/shared`: serializable cross-stack contracts.

## 2026-08-31 Modular internationalization foundation

The internal product is gaining a locale-neutral domain contract and modular
presentation catalogs. The first translated slice covers the global navigation
and the complete Telegram Posts workspace (editor, groups, calendar and its
supporting modals). Locale persistence, SSR cookie mirroring, feature namespace
registration, typed keys and CI catalog validation form the reusable foundation
for later sections and languages.

HTTP errors in this slice move toward stable machine codes and structured
parameters; backend translation is reserved for direct outbound bot,
notification, email and export presentation. Catalog loading is route/feature
scoped, with heavy subfeatures eligible for lazy loading. The implementation
adds no polling, recurring database work or per-entity locale lookup. See
`docs/architecture/I18N.md` for the contract.

The main architectural issue is concentrated handwritten production files that combine unrelated responsibilities. The former 12978-line Telegram channels god-service is now a 255-line checker-counted compatibility facade over focused use-case providers. The largest remaining backend file is `apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales.service.ts` at 5,825 checker-counted lines; the largest frontend file is `apps/web/src/app/(internal)/(telegram)/telegram-posts/page.tsx` at 8,564 checker-counted lines.

## Metrics Before Refactoring

Measured before edits:

| Metric                              |                                                                                  Count |
| ----------------------------------- | -------------------------------------------------------------------------------------: |
| Handwritten production TS/TSX files |                                                                                    275 |
| Files > 500 lines                   |                                                                                     32 |
| Files > 1000 lines                  |                                                                                     17 |
| Files > 2000 lines                  |                                                                                     10 |
| Files > 3000 lines                  |                                                                                      8 |
| Largest backend file                | `apps/api/src/domains/telegram/telegram-channels/telegram-channels.service.ts` - 11019 |
| Largest frontend file               |                           `apps/web/src/app/(telegram)/telegram-posts/page.tsx` - 6775 |

## Historical Metrics After the 2026-08-22 Milestone

This table is retained as the milestone record and is not the current inventory.

| Metric                              |                                                                                 Count |
| ----------------------------------- | ------------------------------------------------------------------------------------: |
| Handwritten production TS/TSX files |                                                                                   675 |
| Files > 500 lines                   |                                                                                    55 |
| Files > 1000 lines                  |                                                                                    16 |
| Files > 2000 lines                  |                                                                                     7 |
| Files > 3000 lines                  |                                                                                     5 |
| Largest backend file                | `apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales.service.ts` - 5884 |
| Largest frontend file               |               `apps/web/src/app/(internal)/(telegram)/telegram-posts/page.tsx` - 8379 |

## Current Working-Tree Metrics — 2026-08-27

| Metric                              |                                                                                 Count |
| ----------------------------------- | ------------------------------------------------------------------------------------: |
| Handwritten production TS/TSX files |                                                                                   852 |
| Files > 500 lines                   |                                                                                    65 |
| Files > 800 lines                   |                                                                                    27 |
| Files > 1000 lines                  |                                                                                    16 |
| Files > 2000 lines                  |                                                                                     7 |
| Files > 3000 lines                  |                                                                                     5 |
| Largest backend file                | `apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales.service.ts` - 5825 |
| Largest frontend file               |               `apps/web/src/app/(internal)/(telegram)/telegram-posts/page.tsx` - 8564 |

`TelegramChannelsService` was reduced from 12978 lines to a 255-line explicit
delegation facade. Its file-size baseline and both direct GramJS import
exceptions were removed; all newly extracted channel production files remain
below 500 lines. `apps/web/src/lib/api.ts` was reduced from 3575 lines and is currently 783
checker-counted lines after extracting type-only API contracts, focused endpoint
facades, and the neutral HTTP transport. The temporary 1486-line
`apps/web/src/lib/api-types.ts` type warehouse was split into domain modules,
leaving a small compatibility barrel. `packages/shared/src/types/telegram-ad-sales.ts`
is currently 882 lines after moving CRM contracts to `telegram-ad-sales-crm.ts`.
`apps/api/src/domains/growth/ad-campaigns/ad-campaigns.service.ts` is currently
1859 lines after focused extraction. Transitional architecture allowances remain
shrinking-only. The current project-wide `pnpm architecture:check` fails on
existing grown files, hard/page/facade limits, stale allowances and one product-
boundary import. The live inventory and the exact performance-sensitive
decomposition order are recorded in
`docs/refactoring/PERFORMANCE_AUDIT_2026-08-27.md`.

## Large Files

### 3000+ Lines

- `apps/web/src/app/(internal)/(telegram)/telegram-posts/page.tsx` - posts page, composer, calendar, groups, bulk operations, scheduling modals.
- `apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales.service.ts` - products, pricing, inventory, analytics, CRM, sales lifecycle, payments.
- `apps/web/src/app/(internal)/(telegram)/telegram/channels/[id]/page.tsx` - channel detail, analytics, settings, posts, access and sync modals.
- `apps/web/src/app/(internal)/(telegram)/telegram-channels/page.tsx` - channel catalog, networks, accounts/bots, import/export, composer.
- `apps/api/src/telegram/shared/telegram-mtproto.client.ts` - login, dialogs, channel resolution, stats, invite links, publishing/edit/delete/media.
- `apps/web/src/components/features/growth/ad-sales/ad-sales-page.tsx` - ad sales tabs, calendar, settings, pricing, analytics, lifecycle flows.

### 2000+ Lines

- All files above.
- `apps/web/src/app/(internal)/(growth)/ad-campaigns/page.tsx` - campaigns/promos/hypotheses page state, tables, modals, analytics.

### 1000+ Lines

- All files above.
- `apps/api/src/domains/growth/ad-campaigns/ad-campaigns.service.ts`
- `apps/web/src/components/ui/primitives.tsx`
- `apps/web/src/components/features/growth/ad-campaigns/campaigns-table.tsx`
- `apps/api/src/domains/telegram/telegram-user-accounts/telegram-user-accounts.service.ts`
- `apps/web/src/components/features/telegram/telegram/telegram-account-panels.tsx`
- `apps/web/src/components/icons/icon-picker.tsx`
- `apps/web/src/components/features/growth/ad-sales/ad-sale-modal.tsx`
- `apps/api/src/domains/growth/ad-campaigns/ad-campaign-admission-analytics.service.ts`

### 500+ Lines

`docs/refactoring/codebase-inventory.json` is the historical refactor inventory
from an earlier milestone; it is not the live file-size source. Use
`scripts/check-architecture.mjs` for the current full list and
`docs/refactoring/PERFORMANCE_AUDIT_2026-08-27.md` for the 2026-08-27 audited
major-file table.

## Target Architecture

Backend target:

- Business modules are physically grouped under `src/domains/{identity,workspace,finance,growth,telegram,operations}` while shared infrastructure remains in `src/common`, `src/prisma`, and `src/telegram/shared`.
- Telegram Bot code is grouped into `core`, `greeter`, and `finance` behind one Nest composition module.
- Controllers remain thin and delegate to application services.
- `TelegramChannelsService` becomes a compatibility facade while behavior moves into use-case services: channel catalog, import, sync orchestration, invite-link sync, managed posts, managed post publishing, post groups, analytics queries.
- `TelegramAdSalesService` decomposes into product/pricing, inventory, lifecycle, payments, analytics and CRM services.
- MTProto remains behind a single injectable facade while implementation moves into auth, channels, posts, invite links, publishing and stats adapters.
- Workspace isolation remains explicit on every Prisma read/write.

Frontend target:

- Public routes retain their URLs through App Router groups, while domain components and clients live under `components/features/*` and `lib/features/*`.
- Page files read params/search state and render feature containers.
- Data fetching and mutation invalidation move into feature hooks.
- Domain clients remain behind one base API client; endpoint facades are split by domain.
- Query keys are created through typed factories in `apps/web/src/lib/query-keys.ts`.
- Reusable selectors and pickers are composed from existing primitives before adding new UI.

## Architecture Guard Policy

- Recommended handwritten production file size: 100-400 lines.
- Warning threshold: over 500 lines.
- Hard policy: over 800 lines.
- App Router `page.tsx` policy: 300 lines.
- API compatibility facade policy: 400 lines.
- Type barrel/index policy: 250 lines; UI barrel policy: 150 lines.
- `pnpm architecture:check` runs in transitional mode. Current oversized files are baseline entries that may shrink but may not grow.
- `ARCHITECTURE_STRICT=1 pnpm architecture:check` runs the final policy with no transitional baseline and currently fails until the remaining god files are decomposed.
- The transitional baseline must only decrease. Adding entries requires a documented deviation and is not acceptable for completed refactoring.

## Contracts That Must Not Break

- Existing API URLs, response shapes and status codes.
- Workspace scoping via `X-Workspace-Id` and `WorkspaceService`.
- Telegram sync stages and retry/rate-limit behavior.
- Managed post publish/schedule/edit/delete semantics.
- Invite link attribution and campaign linkage.
- Ad sales pricing, availability, payment and transaction behavior.
- Frontend routes and query key cache semantics.

## Completed Decisions

- Consolidate backend source layout into six domain groups without merging independent Nest provider scopes or changing API routes.
- Split the flat Telegram Bots directory into `core`, `greeter`, and `finance`, keeping `telegram-bots.module.ts` as the single composition root.
- Consolidate frontend routes with URL-transparent App Router groups and organize feature components/API clients by the same domain vocabulary.
- Keep `apps/web/src/lib/api.ts` as a compatibility facade while extracting type-only contracts.
- Introduce `apps/web/src/lib/api-types.ts` for frontend API-facing serializable types currently owned by the web client.
- Extract `applicationLogsApi` to `apps/web/src/lib/features/operations/application-logs-api.ts` while preserving `@/lib/api` compatibility exports.
- Introduce `apps/web/src/lib/query-keys.ts` as the global query-key factory module.
- Adopt query-key factories in auth, member select, Telegram access/channel invalidation, Telegram ad-sales invalidation and Telegram channel detail data flows while preserving the existing array key values.
- Align Telegram channel invite-link cache invalidation with the canonical `telegram-channel-invite-links` workspace-scoped key used by the channel detail page and query provider.
- Extract invite-link history payload construction from `AdCampaignsService` into `apps/api/src/domains/growth/ad-campaigns/invite-link-history.ts` with focused characterization tests.
- Add `scripts/check-architecture.mjs` as a baseline-aware guard. Existing legacy files above limits are tracked as shrinking-only transitional entries; new files above hard policy and legacy growth fail.
- Add project-scoped Codex agent definitions under `.codex/agents`.
- Assign stable project call-signs in `.codex/agents`: Linus Backend, Ada Frontend, Dieter Design, Grace Explorer and Turing Review.
- Extract `telegramAdSalesApi` from `apps/web/src/lib/api.ts` to `apps/web/src/lib/features/growth/telegram-ad-sales-api.ts` while preserving the `@/lib/api` compatibility export.
- Extract workspace, finance, prompt-notes, Telegram channels, Telegram source/account, marketing and Ad Sales endpoint implementations from `apps/web/src/lib/api.ts` while preserving `@/lib/api` compatibility exports.
- Extract Telegram Ad Sales CRM shared contracts from `packages/shared/src/types/telegram-ad-sales.ts` to `packages/shared/src/types/telegram-ad-sales-crm.ts`.

## Validation Baseline

Pre-existing results before implementation:

| Command                                 | Result                                                                                                                           |
| --------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| `pnpm install --frozen-lockfile`        | pass                                                                                                                             |
| `pnpm db:generate`                      | pass                                                                                                                             |
| `pnpm --filter api test -- --runInBand` | pass: 30 suites, 209 tests                                                                                                       |
| `pnpm --filter api lint`                | fail: 5680 errors, 251 warnings, mostly pre-existing prettier/unsafe any                                                         |
| `pnpm --filter api typecheck`           | pass after correcting the `telegram-ad-sales.service.spec.ts` mocked `OVERDUE_PAYMENT.scheduledAt` to match the service contract |
| `pnpm --filter api build`               | pass                                                                                                                             |
| `pnpm --filter web test -- --run`       | pass: 18 files, 89 tests                                                                                                         |
| `pnpm --filter web lint`                | fail: 190 errors, 101 warnings, mostly pre-existing explicit any/react compiler rules                                            |
| `pnpm --filter web typecheck`           | pass                                                                                                                             |
| `pnpm --filter web build`               | pass                                                                                                                             |

## Progress By Milestone

- Workspace RBAC foundation (2026-08-29): canonical shared feature/permission
  registry and ownership semantics defined; custom role persistence, request-
  scoped authorization, Role API/editor, permission-aware surfaces and bounded
  domain enforcement are being implemented as separate non-overlapping slices.
  The design stores role permission deltas rather than copying effective rights
  onto members and adds no polling or recurring runtime work. See
  `docs/architecture/WORKSPACE_RBAC.md`.

- 2026-08-28 regression closure: extracted the internal transaction editor from
  the Finance transactions App Router page, reducing that page below the
  300-line policy while restoring category-driven Member/Channel fields and a
  single-row primary-field layout. Restored System Bot slash-command
  registration on both selected environments. Ad-sales list grouping now uses
  the booked placement time; the existing post-metrics task also includes
  channels with active published placements, and legacy deletion can use an
  explicitly linked TelegramPost when an empty managed-post shell has no
  message identity. No timer, polling loop, task frequency, retention, or
  unchanged-state write was added; the existing 100-channel external-call
  ceiling is unchanged.
- Ad Sales network placement slice: added authoritative exact-sum audience-weighted pricing for paid checkout and System Bot sales, exposed the system "all channels" network in the creation flow, added one shared creative cloned to channel-owned managed posts, automatic future scheduling, and workspace-timezone-safe per-channel overrides. No polling or recurring runtime work was introduced.

- Milestone 1 - Baseline: completed. Inventory JSON, baseline checks and risk map created.
- Milestone 2 - Agent and architecture guidance: completed for AGENTS, `.codex/agents`, design-system docs and architecture check.
- Milestone 3 - Frontend primitives: started. Query key factories added and adopted in central invalidation/auth/member select/ad-sales invalidation/channel detail.
- Milestone 4 - Frontend migration: started. Routes, feature components, API clients and API types are now grouped by domain; large page decomposition remains.
- Milestone 5 - Backend decomposition: started. Backend modules are grouped by domain, Telegram Bots is split into product folders, and the Telegram channels god-service is decomposed; Telegram ad-sales and MTProto remain.
- Milestone 6 - Shared contracts: planned; no cross-stack API shape changes made.
- Milestone 7 - Final review: partial validation completed.

## Telegram Logical Bot / Runtime Split

- Introduced environment-scoped runtime instances so one logical Finance or
  Greeter bot shares business data while `LOCAL` and `PRODUCTION` keep distinct
  BotFather identities, tokens, webhooks and runtime state.
- Migrated existing integration infrastructure state into a `PRODUCTION`
  runtime and made update idempotency runtime-aware.
- Routed webhook responses through their origin runtime while keeping scheduled
  deliveries production-authoritative and non-duplicated.
- Replaced local production-webhook rebinding and System Bot polling with
  explicit local webhook configuration. Runtime reconciliation remains a
  bounded startup/configuration event with no recurring database activity.
- Completed the management presentation around one logical bot card with
  `PRODUCTION`/`LOCAL` runtime selection. The compact list model avoids
  per-card status requests; explicit checks and configuration mutations patch
  the selected runtime rather than broadly invalidating bot queries. Web App
  availability and Telegram Mini App/menu configuration are shown separately.
- Documented the System Bot as a separately env-managed integration: its UI can
  identify the selected process environment and last-known status, but cannot
  edit or reveal environment credentials. No status heartbeat or polling was
  added for either bot model.

## Telegram Platform Foundation Completion

- Extracted a canonical workspace full-channel sync use case that reuses the existing single-channel sync orchestration and is shared by Scheduled Tasks and the Telegram System Bot.
- Replaced scheduler evaluation cursors with persisted occurrence timestamps, owner-fenced claims and recoverable run identity; notification delivery is now awaited after terminal run persistence.
- Removed the Greeter feature cron in favor of the distributed Scheduled Tasks infrastructure and added terminal operational-history retention.
- Added recoverable Telegram bot webhook transitions, non-fatal application-update failures, workspace-independent recipient subscriptions and durable System Bot finance selection drafts.
- Added focused backend, shared-contract and frontend regression coverage. The new focused API gate passes 58 tests and the web suite passes 127 tests. The full API suite still exposes five unrelated legacy Telegram channel mock failures in `sync-managed-posts.spec.ts` and `managed-post-history.spec.ts`.

## Greeter Product Completion

- Replaced the Greeter schema/service skeleton with workspace-scoped configuration, persisted permission degradation, idempotent join/CAPTCHA decisions, Greeter-only users and aggregated analytics.
- Added immutable automation versions, acquisition-channel enrollments, isolated draft test sessions, restart-safe execution repair, one-time broadcasts and delivery-to-domain reconciliation.
- Added the canonical `/telegram-bots/[botId]/greeter` management route with focused Overview, Channels, CAPTCHA, Users, Analytics, Automations, Broadcasts and Test Mode components backed by shared contracts and query-key factories.
- Kept new production files below the architecture warning threshold by extracting Greeter read models and focused services. No Finance Bot implementation was started.
- Current Greeter-focused API gate passes 13 suites and 66 tests; the final web suite passes 31 files and 149 tests. The full API suite remains at five unrelated legacy Telegram channel mock failures.

## Finance Product Runtime Slice

- Added verified Telegram Mini App context, a consumer-owned Finance API, derived ledger balances, confirmation-based chat proposals, tenant-scoped core CRUD/aggregation/export, and recurring delivery-queue reminders.
- Added reusable Stripe and Telegram Stars checkout/lifecycle paths, immutable provider price synchronization, internal coupon validation, privacy-safe admin billing reads, and the canonical Finance entitlement boundary.
- Added a bounded OpenAI Responses adapter for structured text and receipt proposals with usage metadata and no raw prompt/receipt persistence.
- Removed the personal-token Monobank adapter and hardcoded bank capability runtime. Bank Import is not exposed as an entitlement.
- Completed the consumer Finance product pass: the Finance bot now provides a Web App entry point and concise chat actions, proposal confirmation is atomic, and the Mini App is decomposed into focused Home, Transactions, Budget, Accounts and More workflows backed by typed consumer contracts and narrow query keys.
- New Finance production files remain below architecture thresholds. The existing project-wide architecture failures and five unrelated Telegram channel tests remain outside this slice.

## Finance Consumer Surface Split

- Split the shared consumer layout into explicit Telegram Mini App and browser Web App shells while retaining one auth/bootstrap container, API client, query-key family and mutation implementation.
- Kept Telegram viewport, safe-area, FAB and bottom-navigation behavior inside the Mini App shell. The browser shell now owns its desktop sidebar, operational header, responsive browser navigation and profile context.
- Added browser-only Reminders and Billing destinations that compose the existing settings/reminder/billing workflows with screen-oriented lazy queries rather than duplicating domain logic.
- Added a bounded desktop transaction table over the existing cursor endpoint. Row details remain user-triggered, so collection rendering adds no per-row HTTP joins.
- The browser Overview continues to use the existing bounded dashboard read model and arranges its account, category, budget, goal and recent summaries in a desktop grid without adding a giant endpoint or bootstrap fan-out.

## Domain Layout Consolidation

- Consolidated backend business modules under `apps/api/src/domains/{identity,workspace,finance,growth,telegram,operations}`. Shared infrastructure remains at `common`, `prisma`, and `telegram/shared` so domain grouping does not blur adapter boundaries.
- Split the former flat `telegram-bots` directory into `core`, `greeter`, and `finance`. Kept one `TelegramBotsModule` composition root to avoid duplicate runtime, registry, and delivery providers.
- Consolidated frontend routes into URL-transparent App Router groups and moved domain UI/API helpers under `components/features/*` and `lib/features/*`.
- Updated source imports, architecture baselines, agent guidance, design-system import examples, the codebase inventory, and architecture documentation to the canonical paths.
- Next.js production route output confirms that all existing public route paths are unchanged.

## Product Boundary Architecture Foundation

- Defined the product/application model in `docs/architecture/PRODUCT_BOUNDARIES.md`: internal Finance and consumer Finance are separate products; Finance and Greeter own their behavior and surfaces; `telegram-bots/core` and `telegram/shared` are platform boundaries rather than product implementation homes.
- Kept this slice architecture-only. No production TypeScript, API contract, public URL, Prisma schema, UI behavior, runtime job, connection, query, write, or deployment service changed.
- Extended `pnpm architecture:check` with fast Node policy tests and a static source scan. The scan resolves relative and `@/` imports without loading TypeScript, starting the application, using the database, or accessing the network.
- Enforced product/platform import direction, the separation of the two Finance products, consumer product UI ownership, low-level Telegram SDK placement, controller/Prisma separation, configuration access, bounded frontend polling, and thin App Router pages.
- Recorded current dependency/presentation/environment/polling debt as exact source/target edges or path/rule occurrence ceilings. Every exception has a reason and removal slice; stale ceilings now fail after a violation shrinks, preventing silent regrowth.
- Lowered every already-shrunk file-size allowance to the current size and removed the obsolete allowance for `managed-posts-import-modal.tsx`, which is now below the 800-line hard limit. No file-size allowance was increased.
- The pre-existing architecture failure remains exactly three file-growth violations: `telegram-channels.service.ts` (12978 vs 12788), `telegram-posts/page.tsx` (8379 vs 8370), and `primitives.tsx` (1962 vs 1936).
- Added focused regression coverage for platform-to-product and product-to-product imports, the two-Finance boundary, consumer UI ownership, Telegram SDK placement, Prisma-backed controllers, scattered environment reads, frontend polling, and page-level query/API orchestration.

## Consumer Finance Product Isolation

- Moved Consumer Finance business and HTTP implementation out of the flat
  `telegram-bots/finance` directory into
  `domains/telegram/consumer-finance/{identity,ledger,transfers,catalog,planning,analytics,ultimate,ai,billing,chat-flows,i18n,http,telegram-presentation}`.
  The original `telegram-bots/finance` path now contains only the Finance-owned
  Telegram update/presentation adapter.
- Replaced bot-core imports of Finance and Greeter implementations with narrow
  handler and presentation ports wired in `telegram-bots.module.ts`. Finance
  commands, menus, locale selection and local lifecycle copy are product-owned.
  The chat-flow writer/service cycle was removed through a product-owned types
  module.
- Kept durable reminder delivery sequencing in the platform while moving the
  reminder month calculation, localized payload and Prisma write into Finance.
  The remaining `financeReminderId`/delivery-port seam mirrors the existing
  persisted schema and preserves post-success idempotency without a generic
  plugin framework or new recurring work.
- Gave the browser Web App and Telegram Mini App a Finance-owned presentation
  layer: controls, dates, modal, surfaces/states, icon/avatar wrapper, Unicode
  emoji picker, visual tokens, toast and QueryClient. The two shells remain
  separate and retain their existing URL/bootstrap/session behavior.
- Split the consumer HTTP facade into focused Finance-owned auth, ledger,
  planning and insights clients over one neutral low-level web transport.
  Finance now owns its query keys and money/date/cache helpers; internal Finance
  and bot administration no longer import consumer implementation or the
  reverse.
- Split the shared `consumer-finance` contract warehouse into cohesive identity,
  billing, ledger, transfers, planning, analytics and Ultimate type modules,
  retaining the original public type barrel and serializable API shapes.
- Removed every transitional Consumer Finance import exception. The architecture
  gate now recognizes both the Finance product root and its adapter, forbids
  business-to-adapter direction, and enforces Finance-owned web UI/provider/API/
  query boundaries with focused regression tests.
- No Prisma schema or migration changed. No route, cookie, HTTP status, Telegram
  command/callback, Stripe redirect, entitlement, AI, money, locale, reminder or
  analytics contract was intentionally changed.

## Environment Configuration Contract

- Reduced the checked runtime profile from 48 template keys to 28 keys. The
  remaining profile contains only credentials, deployment/network topology,
  runtime selection, logging controls, and deployment-sensitive monitoring.
- Removed ignored nested web environment files and made web-only local topology
  explicit in the root script. The profile checker now rejects extra `.env*`
  files at the root and app-package levels.
- Established `FRONTEND_URL` as the single public web origin and
  `API_PUBLIC_URL` as the single public API origin. Product URLs are built from
  application routes; workspace and System Bot webhooks use the canonical API
  origin rather than separate ingress aliases.
- Removed product-specific URL/gateway configuration and legacy Telegram sync
  flags. Telegram remains webhook- and due-driven; no polling interval,
  heartbeat, worker, or compatibility runtime was reintroduced.
- Moved capability refresh limits, log buffering/retention, memory sampling and
  recovery, and operational-history retention to focused code constants. The
  memory warning threshold remains deployment configuration because it follows
  the Railway memory tier.
- Unified browser API resolution in a neutral HTTP helper. Localhost continues
  to use the local API; a public HTTPS page cannot call a loopback API and uses
  same-origin `/api`; Railway and separately deployed HTTPS APIs remain
  supported.
- Added pure deployment-origin and environment-contract tests. Configuration
  remains startup/build-time logic with no database-backed settings, polling,
  watchers, persisted history, or new process.

## Risks

- The two largest backend services have broad Prisma and Telegram side effects. They need characterization tests before behavioral extraction.
- Existing lint/typecheck failures make CI noisy. New checks must be judged against this baseline until lint debt is separately fixed.
- Large frontend pages contain local components with shared closure state; mechanical splitting can easily change UI behavior.
- MTProto adapter split is high-risk and should happen behind a facade after adapter tests are expanded.
- Consumer Finance still has cohesive-decomposition debt in several 500–794-line
  files. They remain below the hard limit and did not grow; later slices should
  split them around characterized use cases rather than mechanical line count.
- The durable delivery schema still exposes `financeReminderId` to bot core.
  Core depends only on a narrow continuation port and no Finance implementation;
  removing the discriminator itself would require a separately justified schema
  migration.
- Existing within-product dependency cycles remain in Greeter
  automation/enrollment/sequence services. The Consumer Finance chat-flow
  writer/service cycle was removed in this slice.

## Deviations

- The architecture check uses a transitional shrinking-only baseline for existing files above limits. This is intentional because the repository still has large production files; `ARCHITECTURE_STRICT=1 pnpm architecture:check` enforces the final no-exception policy and currently fails until decomposition is complete.
- Remaining high-risk backend god-service decomposition for Telegram ad sales and MTProto still requires characterization tests around publishing/payment and protocol behavior before moving side-effectful logic.
- Static source rules intentionally target low-noise syntactic violations. Semantic broad invalidation, N+1 HTTP, workspace isolation, transaction preservation, circular runtime dependencies, and false shared abstractions remain mandatory integration-review checks.

## Telegram Channels God-Service Decomposition

- Replaced the 12978-line `TelegramChannelsService` implementation with a
  252-line compatibility facade whose 78 public methods explicitly delegate to
  focused Nest providers. The controller and HTTP DTO/status/response contracts
  remain unchanged.
- Split channel ownership into catalog/lifecycle/financial reads, source access,
  schema compatibility, import policy/preparation/import, insights/content read
  models, workbook writing, historical sync, sync orchestration, post metrics
  and broadcast statistics.
- Split invite ownership into attribution, campaign commands, persistence,
  snapshot/history compatibility and remote sync. Requested-count and missing
  snapshot-table fallbacks have one persistence owner rather than duplicated
  read/sync branches.
- Split managed-post ownership into presentation/rendering, revisions, import,
  commands/history, queries/calendar/links, publishing transport, bulk/group
  operations, moves/deletion, remote scheduled import, reconciliation and
  auto-repair. Existing Telegram identity semantics remain in the focused
  identity service.
- Rewired account, scheduled-task, System Bot, workspace sync, daily analytics,
  user-account, Ad Sales and calendar-planner callers to their narrow use-case
  providers. The facade is retained only for the HTTP compatibility surface.
- Routed HTML parsing through `telegram/shared/telegram-html-parser.ts`, removing
  both direct GramJS domain imports and their exact architecture exceptions.
- Removed the Telegram channels file-size allowance entirely and lowered the
  already-shrunk Telegram user-account allowance from 1193 to 1179 checker
  lines. Every newly extracted production file is below 500 physical lines; no
  new transitional allowance was added.
- Characterization coverage preserves required/optional sync step sequencing,
  publication compensation after remote success/local failure, workspace-scoped
  channel update transactions, missing revision storage, atomic invite
  reattribution, post-group creation/attachment and group-move rollback.
- Private Telegram invite references are redacted at the shared logging boundary;
  regression coverage rejects raw invite URLs and bearer-like hashes in both
  compatibility-persistence warnings and MTProto diagnostic references.
- The refactor adds no schema or API changes, recurring production processes,
  runtime jobs, polling, timers, database operations, snapshots or external calls. The
  existing sequential per-channel pipelines, conditional no-write paths,
  transaction boundaries, due notifications and cache invalidation remain the
  runtime owners.

## Latest Validation

Telegram channels god-service decomposition on 2026-08-22:

| Command / audit                                                   | Result                                                                                                                                                                                                                                                          |
| ----------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| channel/caller/security focused API tests plus AppModule DI smoke | pass: 26 suites, 200 tests                                                                                                                                                                                                                                      |
| `pnpm --filter api test -- --runInBand --silent`                  | pass: 139 suites, 865 tests                                                                                                                                                                                                                                     |
| `pnpm --filter api typecheck`                                     | pass                                                                                                                                                                                                                                                            |
| `pnpm --filter api build`                                         | pass                                                                                                                                                                                                                                                            |
| `node --test scripts/architecture-policy.test.mjs`                | pass: 16 focused policy tests                                                                                                                                                                                                                                   |
| `pnpm architecture:check`                                         | expected fail only: the two unrelated existing web growth violations in `telegram-posts/page.tsx` and `primitives.tsx`; Telegram channels has no allowance or import exception                                                                                  |
| `ARCHITECTURE_STRICT=1 pnpm architecture:check`                   | expected repository-debt failure; the decomposed facade and every new channels production file satisfy their applicable limits                                                                                                                                  |
| Telegram channels static import graph                             | pass: 65 production TypeScript files, zero cycles                                                                                                                                                                                                               |
| facade surface audit                                              | pass: 78 declarations and 78 assignments with no missing, extra or duplicate delegate                                                                                                                                                                           |
| extracted-file lint audit                                         | actionable/format findings removed; relocated `no-unsafe-*` findings reduced from 427 in the monolith to 425 across extracted implementation files, with no disables or exceptions; the compatibility facade retains legacy inferred-`any` delegate assignments |
| `git diff --check`                                                | pass                                                                                                                                                                                                                                                            |

No Prisma schema or shared HTTP contract changed, so database generation and
frontend gates are not required for this slice.

Environment configuration contract on 2026-08-22:

| Command                                            | Result                                                                                                                                                                                                                     |
| -------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `pnpm env:check`                                   | pass: `.env` and `.env.example` synchronized at 28 key names without printing values                                                                                                                                       |
| `pnpm test:deployment`                             | pass: 7 origin/profile regressions plus Railway artifact verification                                                                                                                                                      |
| `pnpm --filter api test -- --runInBand`            | pass: 135 suites, 849 tests                                                                                                                                                                                                |
| `pnpm --filter web test -- --run`                  | pass: 79 files, 365 tests                                                                                                                                                                                                  |
| `pnpm --filter api typecheck`                      | blocked only by the pre-existing unrelated mock typing error in `telegram-channels/import-managed-posts.spec.ts:389`                                                                                                       |
| `pnpm --filter web typecheck`                      | pass                                                                                                                                                                                                                       |
| API and web production builds                      | pass; `/finance/[botId]` remains dynamic                                                                                                                                                                                   |
| `node --test scripts/architecture-policy.test.mjs` | pass: 16 focused policy tests                                                                                                                                                                                              |
| `pnpm architecture:check`                          | expected fail only: the same three pre-existing growth violations in `telegram-channels.service.ts`, `telegram-posts/page.tsx`, and `primitives.tsx`; all environment-access allowances and stale ceilings removed/lowered |
| `git diff --check` and retired-key contract audit  | pass                                                                                                                                                                                                                       |

Consumer Finance product isolation on 2026-08-22:

| Command                                                 | Result                                                                                                                                                                                                    |
| ------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| targeted Finance/core API tests                         | pass: 29 suites, 224 tests                                                                                                                                                                                |
| `pnpm --filter api test -- --runInBand`                 | pass: 133 suites, 839 tests                                                                                                                                                                               |
| `pnpm --filter api typecheck`                           | blocked only by the pre-existing unrelated mock typing error in `telegram-channels/import-managed-posts.spec.ts:389`                                                                                      |
| `pnpm --filter api build`                               | pass                                                                                                                                                                                                      |
| shared package typecheck/build                          | pass                                                                                                                                                                                                      |
| Finance-focused web tests                               | pass: 22 files, 105 tests before final toast compatibility regression                                                                                                                                     |
| `pnpm --filter web test -- --run`                       | pass: 77 files, 364 tests; existing jsdom navigation/chart-size stderr remains non-fatal                                                                                                                  |
| `pnpm --filter web typecheck`                           | pass                                                                                                                                                                                                      |
| `pnpm --filter web build`                               | pass; `/finance/[botId]` remains a dynamic route                                                                                                                                                          |
| `node --test scripts/architecture-policy.test.mjs`      | pass: 16 focused product/policy tests                                                                                                                                                                     |
| `pnpm architecture:check`                               | expected fail only: the same three pre-existing growth violations in `telegram-channels.service.ts`, `telegram-posts/page.tsx`, and `primitives.tsx`; no Consumer Finance boundary/config/network failure |
| `git diff --check` and repo-wide forbidden-import audit | pass                                                                                                                                                                                                      |

Architecture-boundary foundation on 2026-08-22:

| Command                                            | Result                                                                                                                                                                                                                                                                                                       |
| -------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `node --test scripts/architecture-policy.test.mjs` | pass: 13 focused static-policy regression tests                                                                                                                                                                                                                                                              |
| `pnpm architecture:check`                          | expected pre-existing fail only: the same three file-growth violations in `telegram-channels.service.ts`, `telegram-posts/page.tsx`, and `primitives.tsx`; no new dependency/presentation/config/network failure                                                                                             |
| `pnpm --filter @telegram-system/shared typecheck`  | pass                                                                                                                                                                                                                                                                                                         |
| `pnpm --filter web typecheck`                      | pass                                                                                                                                                                                                                                                                                                         |
| `pnpm --filter api typecheck`                      | fail in two untouched existing tests: incomplete `UpdateFinanceSettingsDto` at `finance-auth.controller.spec.ts:302` and mock return typing at `import-managed-posts.spec.ts:389`                                                                                                                            |
| `git diff --check`                                 | pass                                                                                                                                                                                                                                                                                                         |
| repo-wide forbidden-pattern audit                  | all current low-level Telegram imports outside `telegram/shared` (2 files), Prisma-backed controller usage (1 file), `refetchInterval` usage (2 files), direct environment reads, page orchestration, and product-boundary edges are represented by exact checker exceptions; no untracked violation remains |

| Command                                                                                                                                            | Result                                                                                                                                                                                                                    |
| -------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `pnpm architecture:check`                                                                                                                          | fail: current refactored files are within transitional allowances, but unrelated legacy growth remains in Telegram channels, Telegram posts pages, transactions, UI primitives, icon picker and managed-post import modal |
| `pnpm --filter @telegram-system/shared typecheck`                                                                                                  | pass                                                                                                                                                                                                                      |
| `pnpm --filter api typecheck`                                                                                                                      | pass                                                                                                                                                                                                                      |
| `pnpm --filter api test -- telegram-ad-sales.service.spec.ts telegram-ad-sales-crm-advertisers.service.spec.ts --runInBand`                        | pass: 2 suites, 31 tests                                                                                                                                                                                                  |
| `pnpm --filter api test -- --runInBand`                                                                                                            | pass: 30 suites, 209 tests                                                                                                                                                                                                |
| `pnpm --filter api test -- telegram-ad-sales.service.spec.ts --runInBand`                                                                          | pass: 19 tests                                                                                                                                                                                                            |
| `pnpm --filter api test -- invite-link-history.spec.ts --runInBand`                                                                                | pass                                                                                                                                                                                                                      |
| `pnpm --filter api test -- ad-campaigns invite-link-history ad-campaign-admission-analytics --runInBand`                                           | pass                                                                                                                                                                                                                      |
| `pnpm --filter api build`                                                                                                                          | pass                                                                                                                                                                                                                      |
| `pnpm --filter web typecheck`                                                                                                                      | pass                                                                                                                                                                                                                      |
| `pnpm --filter web test -- --run`                                                                                                                  | pass: 18 files, 89 tests; existing jsdom navigation/chart-size stderr remains non-fatal                                                                                                                                   |
| `pnpm --filter web test -- src/lib/telegram-ad-sales-query.test.ts --run`                                                                          | pass: 1 test                                                                                                                                                                                                              |
| `pnpm --filter web build`                                                                                                                          | pass                                                                                                                                                                                                                      |
| `pnpm db:generate`                                                                                                                                 | pass                                                                                                                                                                                                                      |
| `pnpm --filter @telegram-system/shared build`                                                                                                      | pass                                                                                                                                                                                                                      |
| `pnpm --filter web exec eslint src/lib/application-logs-api.ts src/lib/query-keys.ts`                                                              | pass; pnpm emitted local Node v18 engine warning                                                                                                                                                                          |
| `pnpm --filter api exec eslint src/domains/growth/ad-campaigns/invite-link-history.ts src/domains/growth/ad-campaigns/invite-link-history.spec.ts` | pass                                                                                                                                                                                                                      |
| `pnpm --filter api lint`                                                                                                                           | fail: 5622 errors, 251 warnings; existing repo-wide lint baseline remains                                                                                                                                                 |
| `pnpm --filter web lint`                                                                                                                           | fail: 190 errors, 101 warnings; existing repo-wide lint baseline remains                                                                                                                                                  |
| `ARCHITECTURE_STRICT=1 pnpm architecture:check`                                                                                                    | expected fail until all transitional oversized files are decomposed                                                                                                                                                       |

Domain-layout validation on 2026-08-09:

| Command                                 | Result                                                                                                                                   |
| --------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| `pnpm --filter api typecheck`           | pass                                                                                                                                     |
| `pnpm --filter api build`               | pass                                                                                                                                     |
| focused bot/scheduler/system-bot tests  | pass: 30 suites, 134 tests                                                                                                               |
| `pnpm --filter api test -- --runInBand` | 70 suites and 409 tests pass; the same five legacy Telegram managed-post mock failures remain                                            |
| `pnpm --filter web typecheck`           | pass after regenerating Next route types                                                                                                 |
| `pnpm --filter web test -- --run`       | pass: 31 files, 149 tests                                                                                                                |
| `pnpm --filter web build`               | pass; 36 existing public routes retained                                                                                                 |
| shared package typecheck/build          | pass                                                                                                                                     |
| `pnpm architecture:check`               | path migration is recognized; still fails on pre-existing shrinking-baseline growth and the existing oversized managed-post import modal |

## 2026-08-22 Channel card pricing slice

- Moved the pure Telegram-post expected-views calculation into
  `common/analytics` after the ad-sales setup and channel catalog became two
  real consumers with identical 24h/48h/72h/7d semantics.
- Shrunk `telegram-ad-sales.service.ts` while keeping its public pricing
  contract unchanged. Channel collection pricing uses one bounded, workspace-
  scoped batch instead of per-card API or database reads.
- Lowered the shrinking-only architecture ceilings for the affected ad-sales
  service and Telegram channels page.

## 2026-08-23 Telegram post image persistence slice

- Added a permanent `TelegramPost.imageUrls` read/storage contract and a
  content-addressed Backblaze B2 adapter for Telegram-origin image bytes.
- New synchronized photos and Telegram scheduled imports use bounded MTProto
  batch downloads and exact-key B2 reuse; repeat metric sync skips stored media.
- Added a manual, cursor-batched maintenance command for legacy managed-post
  data URLs and historical synchronized posts. No cron, startup scan, polling,
  or permanent worker was introduced.
- GPT context and read models expose only permanent HTTP(S) image URLs; the old
  request-time Telegram media endpoint was removed.

## Integration Review

- `integration-reviewer` checked the dirty refactor diff after the frontend/backend/design-system slices.
- Medium finding fixed: restored `AdHypothesisCampaignSummary` re-export from `@/lib/api`.
- Low finding fixed at that milestone: validation docs reported the then-current 289 production files; the 2026-08-22 inventory above now reports 580.
- Follow-up fixed: `apps/web/src/lib/api-types.ts` is no longer a transitional god file; it now re-exports focused type modules from `apps/web/src/lib/api-types/`.
- Remaining artifact note: `telegram-system.zip` is untracked and should stay out of the refactor commit unless intentionally archived.

## Manual QA Plan

- Consumer Finance bot: run `/start`, `/expense`, `/income`, `/recent`,
  `/accounts`, `/categories`, `/transfer`, and `/help` in `uk`, `ru`, and `en`;
  complete and cancel at least one callback-driven chat flow.
- Consumer Finance Mini App: open `/finance/[botId]` through Telegram initData,
  verify safe areas/navigation/FAB, create/edit/delete/undo a transaction, and
  confirm that changing bot/runtime does not reuse another bot's session/cache.
- Consumer Finance browser: complete challenge login, reload the HttpOnly
  session, reject an unsafe `returnTo`, log out, and confirm the Mini App session
  remains correctly bot-scoped.
- Finance correctness: create accounts in two currencies, add income/expense,
  transfer between them, verify source/destination amounts and valuation, then
  inspect dashboard, analytics, limits, goal, reminder and Ultimate read models.
- Billing: exercise Stripe checkout success/cancel return paths and Telegram
  Stars entitlement refresh without leaking internal JWT/workspace headers.
- Presentation isolation: compare current browser and 320–390px Mini App
  screenshots, open modal/date/select/emoji/toast states, and confirm emoji
  selection performs no HTTP request.

- Greeter: activate a GREETER bot, open Configure, connect a channel and refresh live `can_invite_users` permission health.
- Greeter: configure global CAPTCHA and a channel override, preview variables, submit a real join request, pass BUTTON_CONFIRM and SIMPLE_CHOICE, and verify approval plus durable outcome delivery.
- Greeter: verify the acquired user, mutually exclusive state and Today/Total/channel analytics; create 0s/10s/1d draft steps, select an interacted tester, run/reset TEST, then publish once.
- Greeter: confirm real acquisition-channel variables, create/estimate/send/schedule/cancel a broadcast, and observe persisted recipient progress through completion.

- Login, workspace switch and dashboard load.
- Telegram channels list, channel detail, sync-now, import/export and source access.
- Telegram posts list, compose, schedule, publish, edit and return to draft.
- Ad campaigns list/detail and admission analytics.
- Ad sales calendar, create sale, reserve/confirm/cancel, register payment.
- Networks create/edit and member assignment.

## 2026-08-27 Repository-Wide Performance Workstream

The evidence and priority register for this workstream live in
`docs/refactoring/PERFORMANCE_AUDIT_2026-08-27.md`. This is an ordered set of
bounded slices, not authorization for a single repository-wide rewrite.

### Constraints and measurement contract

- Preserve every API, authorization, workspace-isolation, idempotency,
  financial-calculation, Telegram and UI contract unless a slice explicitly
  introduces and migrates a shared contract.
- Do not add a Railway service, worker, replica, cache, polling loop, cron,
  heartbeat, recurring telemetry write or higher Neon/Railway resource floor.
  Idle database activity and unchanged-state writes must not increase.
- Before each production slice, record a local/test baseline for Prisma client
  calls, HTTP requests, Telegram API calls and response shape where applicable.
  Static call counts are not latency benchmarks and must not be presented as
  such.
- Prefer request-scoped reuse, bounded batch reads, database aggregates where
  they reduce transferred rows, purpose-built read models and authoritative
  mutation reconciliation. Do not hide inefficient work behind persistent
  caching.
- Significant slices follow Grace Explorer -> Knuth Performance -> Parnas
  Structure preflight -> main integrator -> Linus Backend/Ada Frontend on
  non-overlapping files -> Parnas final check -> Turing Review.
- Existing `scripts/check-architecture.mjs` remains the sole file-size policy
  owner. Every touched shrinking-only file must get smaller; no ceiling or
  exception may be raised.

### Continued implementation checkpoint — 2026-08-27

The backend/runtime continuation landed the following bounded slices. “Partial”
means the measured multiplicative path was removed, but a separately named
contract or runtime concern remains; it is not a claim that the whole numbered
slice is complete.

| Slice     | Status                                                                       | Landed evidence                                                                                                                                                                                                                                                                                                                                                                                                                                |
| --------- | ---------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| P-01      | Critical path complete for the current single-runtime topology               | System Bot stale `PROCESSING` reclaim, process-wide live-attempt exclusion, generation-fenced finalization, callback-first routing, command scopes, one reusable authorized connection, and non-blocking best-effort typing.                                                                                                                                                                                                                   |
| P-02      | Complete for proposal confirmation and established bot context               | Rates and account/category references are prepared once; a ten-operation confirmation performs no root-Prisma call inside the transaction. Finance Bot user/profile context is one scoped read and downstream handlers reuse it.                                                                                                                                                                                                               |
| P-03      | Multiplicative DB work complete; audience/lease follow-up remains            | Atomic `SKIP LOCKED` delivery claims, environment/lease-scoped hydration, fail-closed lost-runtime reconciliation, 250-row idempotent enqueue/link pages, grouped broadcast reconciliation, grouped blocked/missing-chat updates, and cancellation-safe orphan cleanup.                                                                                                                                                                        |
| P-04      | Backend read-write regression addressed; cross-stack collection work remains | Established internal-Finance category readiness is one read and zero writes. Browser “load every page” removal and setup-time ownership remain separate work.                                                                                                                                                                                                                                                                                  |
| P-05/P-06 | Backend hot paths complete; bulk quote UI/API remains                        | Products/pricing samples and availability inputs are loaded in bounded batches. Pricing preserves requests above 100 channels by processing sequential batches of at most 100, ranks at most 60 posts per channel, and returns only exact nearest/latest snapshot candidates for every required stored product window. Established settings/default reads are write-free; first-use defaults are materialized in one batch and refetched once. |
| P-07      | Duplicate/prior hydration complete; `allTime` contract blocked               | Overview uses one current dataset, one prior revenue aggregate and no standalone payment dataset. Selected channel metadata/inventory/latest prices are batched.                                                                                                                                                                                                                                                                               |
| P-08      | Complete for the characterized dashboard path                                | Period predicates are pushed into reads, account transfers are grouped, and one request-scoped currency graph is reused.                                                                                                                                                                                                                                                                                                                       |
| P-12      | Partial                                                                      | Network financial inputs and daily analytics work are batched. Recurring campaign admission reads at most one predecessor per invite link plus the current sync window; MTProto operation-scoped reuse and remaining lifecycle fan-out are still open.                                                                                                                                                                                         |
| P-13      | Partial                                                                      | Scheduler unchanged-state work and due-key rearming were reduced without polling; its automatic-eligibility responsibility was extracted and the touched service reduced from 531 to 464 checker lines. Startup DDL and unchanged Telegram presentation reconciliation remain open.                                                                                                                                                            |
| P-15      | In progress                                                                  | Ad Sales was reduced to 5,825 checker lines and admission analytics to 798, removing the latter's transitional allowance; the touched scheduled-task service is now below 500 and every new production helper in this continuation is below 500 lines.                                                                                                                                                                                         |

Static application-issued operation counts after the continuation:

| Characterized path                                                    |                                                                Before |                                                                                                                                                                                                    After |
| --------------------------------------------------------------------- | --------------------------------------------------------------------: | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: |
| Ad Sales products, 100 channels/four defaults                         | 903 reads when established; up to 903 reads + 100 writes on first use |                                                                                                                              4 whole-path reads when established; 5 reads + 1 batched write on first use |
| Ad Sales availability, 50 channels                                    |                                                         257/258 calls |                                                                      10 whole-path reads and zero writes for the established no-network/empty-placement fixture; first use is 11 reads + 1 batched write |
| Ad Sales analytics source, six selected channels                      |                         up to 10 full datasets / 30 source statements |                                                                                               populated current dataset + prior aggregate / 3 source statements, excluding authorization and other cards |
| Ad Sales analytics whole six-channel overview                         |                                                       about 119 calls |                                                                                                   at most 24 calls for populated, non-`allTime`, no-network input; `allTime` adds two earliest-row reads |
| Operations dashboard, 100 accounts                                    |                                             up to `409 + L + F` calls |                                                                                                                                                          about 21-23 calls, independent of account count |
| Finance proposal confirmation, 10 operations                          |                      up to 40 root reads + 20 full rate-history loads | `M + 5 + B + G + U` operations: 17 for the category-present, single-rate, no-merchant fixture and at most 36 for `M=10`, plus a possible workspace lookup; zero root-Prisma calls inside the transaction |
| Finance Bot established actor/profile bootstrap                       |                     2 sequential reads plus repeated downstream reads |                                                                                                                                     1 scoped read; duplicate user/profile/accounts-context reads removed |
| System Bot `/help`                                                    |                                              typing + 3 context reads |                                                                                                                                                                            no typing and no context read |
| Delivery claim of `N` rows                                            |                                              `1 + N` claim operations |                                                                                                                                                                             2 claim/hydration operations |
| Greeter normal `ALL_ALIVE` materialize/enqueue/link, 1,000 recipients |     2,022 characterized operations after the earlier partial refactor |                                                                    34 operations across four 250-row pages, excluding scheduler/delivery processing; Telegram attempts remain per recipient/retry policy |
| Recurring campaign admission source, 100 campaigns                    |                                per-campaign historical snapshot reads |                                                                                                                               one campaign read + one bounded predecessor read + one current-window read |

These are deterministic test/static counts, not physical SQL or latency claims.
One Prisma relation operation can still issue more than one SQL statement.
For Finance, `M` is the number of proposal operations, `B` is the optional
category batch (`0` or `1`), `G` the distinct current/as-of rate groups and `U`
the merchant-mapping upserts. Category-less or identity-rate input can therefore
be below 17 operations. Availability's network lookup or managed-post hydration
can each add one read outside the characterized empty no-network fixture. The
delivery count is the normal path; a runtime deleted between claim and hydration
adds one fail-closed transaction with three batch writes and no Telegram call.

Evidence-blocked or deliberately deferred work:

- `allTime` analytics still exposes every current placement, alert and inventory
  point. Adding `take` would silently drop public output. Completion requires a
  synchronized aggregate/paginated read contract (P-07/P-09), not an arbitrary
  backend cap. The unbounded previous-period and standalone-payment reads have
  already been removed.
- Greeter audience acquisition still resolves the distinct audience before the
  250-row delivery pages. A true cursor must preserve “first acquisition
  channel” semantics and needs a PostgreSQL integration test. Existing
  five-minute delivery leases also lack an owner token; the new state writes are
  race-guarded, but an already in-flight Telegram request cannot be made
  retractable.
- System Bot live attempts are excluded process-wide and every reclaim/finalize
  is fenced by an exact `updatedAt` generation. This closes the unfinished-live-
  handler race in the current single-runtime topology without a timer or
  heartbeat. Separate OS processes overlapping for more than five minutes can
  still duplicate an external side effect before the losing generation is
  prevented from finalizing. A fully distributed guarantee would require a
  pinned database lock/long transaction, a heartbeat lease or end-to-end
  idempotent side-effect schema, all outside the current cost/safety constraints;
  do not add System Bot replicas without resolving that contract.
- Pricing snapshot rows no longer scale with retained metric history. A request
  for `C` channels uses `ceil(C/100)` sequential SQL batches. In batch `b`,
  `C_b <= 100`, `P_b <= 60C_b`, and `W_b` distinct required stored product
  windows produce at most `P_b(W_b+1)` raw rows. A standard four-window batch is
  therefore at most 30,000 rows; requests above 100 preserve the existing API
  response, and custom windows are included exactly rather than truncated.
- Recurring campaign admission sync hydrates `P + R` snapshots, where `P` is at
  most one predecessor per selected invite link and `R` is the current sync
  range. Initial historical/backfill processing still deliberately reads the
  requested history and remains retention/pagination follow-up work.
- Ten distinct Finance valuation dates can still prepare ten rate-history
  groups outside the transaction, and explicit dashboard `all` mode retains its
  lifetime row/series contract. Bounding either requires a purpose-built latest-
  edge/range contract rather than changing financial or all-time output.
- Bulk placement quote requests, paginated sale-cache membership and hidden-tab
  request gating are cross-stack/frontend P-05/P-09/P-10 work, not backend-only
  changes to infer in this continuation.
- Managed-post read repair/renumber side effects, MTProto operation-scoped
  connection reuse, startup compatibility DDL/presentation reconciliation and
  remaining Ad lifecycle detail hydration remain explicit P1 work.
- No index was added. The new delivery lookup uses the existing
  `(botIntegrationId, idempotencyKey)` unique constraint; due claims use the
  existing `(status, scheduledAt)` index; broadcast reconciliation uses existing
  recipient status/uniqueness indexes. P-14 remains blocked on sanitized,
  production-like `EXPLAIN (ANALYZE, BUFFERS)` evidence and deployed Neon
  configuration access, so speculative write-amplifying indexes were rejected.
- No cache service, worker, timer, polling loop, heartbeat, recurring
  precomputation or telemetry writer was introduced. Idle Neon/Railway work and
  the service topology/resource floor are unchanged or lower.

### Final verification closure and working-tree manifest

The final Parnas structural review, Knuth runtime-cost review and Turing
integration review all pass this continuation with no unresolved current-slice
Critical/High finding. The repository-wide transitional debt below is reported
rather than hidden or widened.

| Check                                                                        | Result                                                                                                                                                              |
| ---------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `pnpm --filter api test -- --runInBand`                                      | pass: 216 suites, 1,331 tests                                                                                                                                       |
| `pnpm --filter api typecheck`                                                | pass                                                                                                                                                                |
| `pnpm --filter api build`                                                    | pass                                                                                                                                                                |
| `pnpm db:generate`                                                           | pass                                                                                                                                                                |
| `pnpm --filter api exec prisma validate`                                     | pass with the existing `SetNull` relation warning                                                                                                                   |
| Focused lint for new/changed production helpers and final performance slices | pass                                                                                                                                                                |
| Broad changed-API-file lint (87 TypeScript files)                            | fail: 1,674 errors and 245 warnings, concentrated in inherited oversized service/spec formatting and unsafe typing/test doubles; no false full-lint pass is claimed |
| `git diff --check`                                                           | pass                                                                                                                                                                |
| Architecture policy tests                                                    | pass: 16/16                                                                                                                                                         |
| `pnpm architecture:check`                                                    | repository-wide fail: 26 existing/transitional findings; current slice passes shrinking-only review                                                                 |
| `ARCHITECTURE_STRICT=1 pnpm architecture:check`                              | repository-wide fail: 36 existing findings; among touched files only the known 5,825-line Ad Sales legacy service remains a strict size failure                     |
| Temporary PostgreSQL pricing execution                                       | pass for SQL types, workspace/channel isolation, custom 96h selection, historical cutoff and row bound; transaction rolled back                                     |
| Final read-only integration review                                           | Turing pass; focused rerun 4 suites, 70 tests                                                                                                                       |

Final production inventory: 852 TypeScript/TSX files; 65 over 500 checker
lines, 27 over 800, 16 over 1,000, seven over 2,000 and five over 3,000. The
Ad Sales shrinking-only ceiling is exact at 5,825. Admission analytics is 798
and its former allowance was removed. The pricing reader is 458, admission
events helper 341, delivery service 493, scheduled-task service 464 and
automatic-eligibility helper 78 checker lines. Static dependency analysis found
six inherited SCCs and zero touching a changed/new file.

The current audit/continuation working tree contains exactly 97 paths: 55
tracked modifications (`M`) and 42 new untracked paths (`A`). This manifest is
the exact hand-off scope; it does not claim that every pre-existing dirty path
was first created in the final continuation turn.

<details>
<summary>Exact 97-path manifest</summary>

```text
M  .codex/agents/backend-architect.toml
M  .codex/agents/codebase-explorer.toml
M  .codex/agents/frontend-architect.toml
M  .codex/agents/integration-reviewer.toml
M  AGENTS.md
M  apps/api/src/common/currency-conversion.service.spec.ts
M  apps/api/src/common/currency-conversion.service.ts
M  apps/api/src/domains/finance/finance-categories/finance-categories.service.spec.ts
M  apps/api/src/domains/finance/finance-categories/finance-categories.service.ts
M  apps/api/src/domains/growth/ad-campaigns/ad-campaign-admission-analytics.service.spec.ts
M  apps/api/src/domains/growth/ad-campaigns/ad-campaign-admission-analytics.service.ts
M  apps/api/src/domains/operations/dashboard/dashboard.module.ts
M  apps/api/src/domains/operations/dashboard/dashboard.service.ts
M  apps/api/src/domains/operations/scheduled-tasks/scheduled-tasks.service.spec.ts
M  apps/api/src/domains/operations/scheduled-tasks/scheduled-tasks.service.ts
M  apps/api/src/domains/telegram/consumer-finance/chat-flows/finance-proposal.service.spec.ts
M  apps/api/src/domains/telegram/consumer-finance/chat-flows/finance-proposal.service.ts
M  apps/api/src/domains/telegram/consumer-finance/identity/finance-context.service.spec.ts
M  apps/api/src/domains/telegram/consumer-finance/identity/finance-context.service.ts
M  apps/api/src/domains/telegram/consumer-finance/ledger/finance-ledger.service.spec.ts
M  apps/api/src/domains/telegram/consumer-finance/ledger/finance-ledger.service.ts
M  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-bot-command.service.spec.ts
M  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-checkout.service.spec.ts
M  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales.service.spec.ts
M  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales.service.ts
M  apps/api/src/domains/telegram/telegram-bots/core/telegram-bot-delivery.service.spec.ts
M  apps/api/src/domains/telegram/telegram-bots/core/telegram-bot-delivery.service.ts
M  apps/api/src/domains/telegram/telegram-bots/core/telegram-bot-users.service.spec.ts
M  apps/api/src/domains/telegram/telegram-bots/core/telegram-bot-users.service.ts
M  apps/api/src/domains/telegram/telegram-bots/finance/finance-bot-chat-responder.service.spec.ts
M  apps/api/src/domains/telegram/telegram-bots/finance/finance-bot-chat-responder.service.ts
M  apps/api/src/domains/telegram/telegram-bots/finance/finance-bot.service.spec.ts
M  apps/api/src/domains/telegram/telegram-bots/finance/finance-bot.service.ts
M  apps/api/src/domains/telegram/telegram-bots/greeter/greeter-broadcast.service.spec.ts
M  apps/api/src/domains/telegram/telegram-bots/greeter/greeter-broadcast.service.ts
M  apps/api/src/domains/telegram/telegram-channel-networks/telegram-channel-networks.service.spec.ts
M  apps/api/src/domains/telegram/telegram-channel-networks/telegram-channel-networks.service.ts
M  apps/api/src/domains/telegram/telegram-channels/dto.spec.ts
M  apps/api/src/domains/telegram/telegram-channels/telegram-channel-financial-read.service.spec.ts
M  apps/api/src/domains/telegram/telegram-channels/telegram-channel-financial-read.service.ts
M  apps/api/src/domains/telegram/telegram-channels/telegram-channels.characterization.spec.ts
M  apps/api/src/domains/telegram/telegram-channels/telegram-managed-post-calendar.service.ts
M  apps/api/src/domains/telegram/telegram-sync/daily-analytics-sync.service.ts
M  apps/api/src/domains/telegram/telegram-system-bot/telegram-system-bot-ad-sale-flow.service.spec.ts
M  apps/api/src/domains/telegram/telegram-system-bot/telegram-system-bot-ad-sale-flow.service.ts
M  apps/api/src/domains/telegram/telegram-system-bot/telegram-system-bot-connections.service.spec.ts
M  apps/api/src/domains/telegram/telegram-system-bot/telegram-system-bot-connections.service.ts
M  apps/api/src/domains/telegram/telegram-system-bot/telegram-system-bot-handler.service.spec.ts
M  apps/api/src/domains/telegram/telegram-system-bot/telegram-system-bot-handler.service.ts
M  apps/api/src/domains/telegram/telegram-system-bot/telegram-system-bot-option-layout.spec.ts
M  apps/api/src/domains/telegram/telegram-system-bot/telegram-system-bot-post-preview.spec.ts
M  apps/api/src/domains/telegram/telegram-system-bot/telegram-system-bot-runtime.service.spec.ts
M  apps/api/src/domains/telegram/telegram-system-bot/telegram-system-bot-runtime.service.ts
M  docs/refactoring/PROJECT_REFACTOR_EXEC_PLAN.md
M  scripts/check-architecture.mjs
A  .codex/agents/file-size-guardian.toml
A  .codex/agents/performance-optimizer.toml
A  apps/api/src/domains/finance/finance-categories/finance-system-category-readiness.ts
A  apps/api/src/domains/growth/ad-campaigns/ad-campaign-admission-analytics-performance.spec.ts
A  apps/api/src/domains/growth/ad-campaigns/ad-campaign-admission-events.ts
A  apps/api/src/domains/operations/dashboard/dashboard-period.ts
A  apps/api/src/domains/operations/dashboard/dashboard-read.service.spec.ts
A  apps/api/src/domains/operations/dashboard/dashboard-read.service.ts
A  apps/api/src/domains/operations/dashboard/dashboard-trend.spec.ts
A  apps/api/src/domains/operations/dashboard/dashboard-trend.ts
A  apps/api/src/domains/operations/dashboard/dashboard.service.spec.ts
A  apps/api/src/domains/operations/scheduled-tasks/scheduled-task-automatic-eligibility.ts
A  apps/api/src/domains/telegram/consumer-finance/ledger/finance-transaction-valuation.ts
A  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-analytics-dataset-reader.spec.ts
A  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-analytics-dataset-reader.ts
A  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-analytics-inventory-alerts.ts
A  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-analytics-summary.ts
A  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-analytics-utils.ts
A  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-availability-builder.ts
A  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-availability-reader.ts
A  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-channel-analytics.ts
A  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-default-products.spec.ts
A  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-default-products.ts
A  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-inventory-reader.ts
A  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-performance.spec.ts
A  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-pricing-reader.ts
A  apps/api/src/domains/telegram/telegram-ad-sales/telegram-ad-sales-workspace-settings.ts
A  apps/api/src/domains/telegram/telegram-bots/core/telegram-bot-delivery-batch-enqueue.spec.ts
A  apps/api/src/domains/telegram/telegram-bots/core/telegram-bot-delivery-batch-enqueue.ts
A  apps/api/src/domains/telegram/telegram-bots/core/telegram-bot-delivery-broadcast-reconciliation.spec.ts
A  apps/api/src/domains/telegram/telegram-bots/core/telegram-bot-delivery-broadcast-reconciliation.ts
A  apps/api/src/domains/telegram/telegram-bots/core/telegram-bot-delivery-claim.spec.ts
A  apps/api/src/domains/telegram/telegram-bots/core/telegram-bot-delivery-claim.ts
A  apps/api/src/domains/telegram/telegram-bots/greeter/greeter-broadcast-batch-link.spec.ts
A  apps/api/src/domains/telegram/telegram-bots/greeter/greeter-broadcast-batch-link.ts
A  apps/api/src/domains/telegram/telegram-channel-networks/telegram-channel-network-presentation.ts
A  apps/api/src/domains/telegram/telegram-channels/telegram-channel-financial-summary-preparation.ts
A  apps/api/src/domains/telegram/telegram-channels/telegram-managed-post-calendar.service.spec.ts
A  apps/api/src/domains/telegram/telegram-sync/daily-analytics-sync.service.spec.ts
A  apps/api/src/domains/telegram/telegram-system-bot/telegram-system-bot-action-context.ts
A  apps/api/src/domains/telegram/telegram-system-bot/telegram-system-bot-handler-performance.spec.ts
A  docs/refactoring/PERFORMANCE_AUDIT_2026-08-27.md
```

</details>

### Slice P-00 — characterization and operation-count harnesses

Scope:

- Add test/development-only Prisma-call and API-client counters around the
  selected use case; keep them out of production startup and request paths.
- Capture fixtures for Ad Sales pricing, availability, analytics, sales list
  and calendar; operations dashboard; Finance Bot; System Bot; campaigns;
  networks; and due analytics sync.
- Record response-shape snapshots or explicit contract assertions before
  changing read models.

Acceptance:

- Each P0 path has a deterministic before-count and equivalent-output test.
- Tests distinguish Prisma client operations from physical SQL statements and
  do not claim wall-clock improvement without a representative benchmark.
- The harness creates no production logging, persistence, timer, request or
  environment dependency.

### Slice P-01 — System Bot crash recovery and critical context

Scope:

- Add atomic stale-`PROCESSING` reclaim to the System Bot runtime while keeping
  terminal duplicates idempotent.
- Classify commands by no context, connection-only or workspace membership;
  reuse the authorized connection and remove best-effort typing from fast-path
  serial work.
- Keep callback acknowledgement first.

Acceptance:

- Concurrent fresh/stale/terminal duplicate tests prove exactly one reclaim
  winner and no lost or double-executed command.
- Help performs no workspace reads; workspace-bound commands still reject a
  disabled connection or stale membership.
- Typing failure/latency cannot delay the useful action on a fast command.

### Slice P-02 — Consumer Finance transaction and rate context

Scope:

- Carry `workspaceId` in the Consumer Finance profile context.
- Resolve a bounded current/as-of rate source before opening proposal-confirm
  transactions and reuse it for every operation; batch account/category inputs.
- Keep mutable financial state request-scoped and preserve atomic confirmation.

Acceptance:

- A ten-operation confirmation makes no root-Prisma call inside the transaction
  callback and has a deterministic bounded operation count.
- Historical/current/default/USD values, duplicate confirm, rollback and
  constrained-pool concurrency retain regression coverage.
- Established Finance actor/profile bootstrap and accounts summaries reuse
  resolved profile/workspace/rate context without caching it across updates.

### Slice P-03 — Telegram delivery and Greeter broadcast linearization

Scope:

- Claim a bounded delivery batch atomically using PostgreSQL concurrency
  semantics; preserve leases and runtime ownership.
- Cursor/batch audience materialization and recipient linking.
- Replace per-delivery whole-broadcast scans with grouped counts or atomic
  counters and one reconciliation per touched broadcast/batch.

Acceptance:

- A 1,000-recipient fixture processes O(B), not O(B²), status rows and records
  exact DB/Telegram operation counts.
- Concurrent claim, crash reclaim, cancellation, blocked user, partial failure,
  retry-after and duplicate-audience tests pass.
- Telegram sends remain bounded and one per required recipient; no new worker,
  queue service, heartbeat or polling loop is added.

### Slice P-04 — collection purity and explicit pagination/aggregates

Scope:

- Remove shared serial “load every page” behavior from user-facing list paths;
  keep UI pagination and add purpose-built server aggregates/selectors.
- Move internal Finance system-category provisioning to workspace setup/
  migration and make transaction GETs write-free.
- Add debounce/cancellation propagation to search paths whose current page
  chains can overlap.

Acceptance:

- 1/100/1,000-row fixtures prove bounded route HTTP work; Categories obtains
  equivalent totals without downloading all transactions.
- Established list GETs perform zero writes and legacy workspace initialization
  still owns every required default.
- Pagination/search/sort, abort, empty/error and workspace-isolation tests pass.

### Slice P-05 — Ad Sales pricing, bulk quotes and read purity

Scope:

- Load channels/products/bounded pricing posts/required metric snapshots once
  and derive every product/placement window in memory.
- Replace per-placement serialized quote POSTs with one keyed bulk preview and
  explicitly decide when an auditable price snapshot is persisted.
- Move default-product/settings materialization out of GET paths.

Acceptance:

- Product calls are bounded at 1/10/50/100 channels; quote HTTP count is one at
  1/100/500 placements with partial-failure and stale-response coverage.
- Established reads perform zero writes; accepted snapshot/audit semantics and
  first-time defaults remain equivalent.
- 24h/48h/72h/7d, missing samples, currency/price and workspace tests pass; the
  Ad Sales god service shrinks without a new exception.

### Slice P-06 — Ad Sales availability use case

Scope:

- Resolve membership/settings/timezone once; batch policies, products,
  placements, posts and pricing; group rows before channel/day/slot loops.
- Keep the existing response cache only as a duplicate-read shield.

Acceptance:

- Cache-miss Prisma calls are bounded at 1/10/50 channels and GET performs no
  upsert/write.
- 93-day, timezone/DST, inherited policy, network, collision, managed metrics
  and cache-equivalence tests pass; no cache service or refresh task is added.

### Slice P-07 — Ad Sales analytics shared source data

Scope:

- Resolve authorization/range once, load current/prior/inventory/pricing source
  data once where semantics match, then derive all overview cards/rollups.
- Prefer smaller specialized aggregates when they transfer fewer rows; do not
  force one giant SQL query.

Acceptance:

- Current range is loaded once for a normal and six-channel overview.
- Empty/current/prior/all-time/mixed-currency output remains equivalent, and
  all-time rows/series are deliberately bounded or aggregated without silent
  truncation.

### Slice P-08 — operations dashboard and currency graph reuse

Scope:

- Push requested date predicates/aggregates into PostgreSQL; batch all account
  transfer totals; build one request-scoped rate graph; bound series density.

Acceptance:

- Calls do not scale as four per account at 1/100 accounts; a 30-day request
  does not hydrate lifetime finance/growth rows.
- Totals, signs, transfers, invite selection, all-time points, stale/missing
  rates and mixed currencies retain regression coverage.

### Slice P-09 — Ad Sales list/calendar contracts

Scope:

- Define synchronized compact sales-row and date/channel-bounded calendar
  contracts; keep rich detail authoritative.
- Preserve compact placement/payment/member/icon summaries so the browser does
  not perform row joins; move complete-history search to the server.

Acceptance:

- Backend/shared/frontend compile against one contract; more than 100 sales and
  search beyond page one remain visible when in scope.
- Payload tests exclude heavy collection fields and retain all detail behavior;
  no per-row HTTP request appears.

### Slice P-10 — frontend request lifecycle and cache precision

Scope:

- Fix sale cache membership: updates touch only containing pages; creates enter
  only provably matching page-one scopes.
- Build an Ad Sales mutation/staleness matrix and gate inactive tabs/modals in
  Campaigns, Channels/detail, Posts, networks/accounts and dashboard surfaces.
- Measure persisted query bytes and exclude heavy families only when doing so
  does not increase duplicate backend requests.

Acceptance:

- Page-one/page-two/filter cache tests, exact invalidation tests and workspace
  switches pass; settings/rates are untouched by ordinary sale mutations.
- Cold-route API counters prove hidden views do not fetch until visible and no
  duplicate request appears within the freshness contract.
- Analytics channel selection is explicit; bounded login/broadcast polling
  remains terminal-state gated and no idle polling is added.

### Slice P-11 — managed-post read purity and bounded read models

Scope:

- Move auto-repair/reconciliation/number normalization to existing due/event
  ownership; check calendar cache before source reads.
- Add bounded collection/calendar/group read models and remove calendar-driven
  self-refetch when exact cache reconciliation is possible.

Acceptance:

- Managed-post/calendar GET and cache-hit tests prove zero writes/MTProto and
  bounded DB/payload work.
- Due publish/delete, drift repair, numbering/group ordering and month navigation
  converge with no lost state or added scheduler.

### Slice P-12 — networks, campaigns, sync, MTProto and Ad lifecycle fan-out

Scope:

- Batch union network sources and campaign invite/baseline observations.
- Batch sync admin links and use existing bounded concurrency.
- Reuse MTProto clients only within one account/channel operation, honor explicit
  history selectors, and return compact Ad lifecycle/deletion outcomes with
  bounded nearest metric snapshots.

Acceptance:

- 1/100 network and 100-channel sync/connection-count tests are bounded; no
  admin-link N+1 or posts/invites overfetch remains.
- Campaign fingerprints/attribution/fallback and changed-only writes pass.
- Twenty deletions/100 lifecycle rows avoid full detail/all-snapshot hydration
  while preserving remote/local compensation, leases and flood-wait behavior.

### Slice P-13 — startup and scheduler no-work cost

Scope:

- Make migrations the schema owner and reduce runtime compatibility DDL to the
  minimum explicitly supported check.
- Version-gate unchanged bot presentation and keep per-user menu reconciliation
  off the health-critical path using existing ownership.
- Materialize task defaults explicitly, page due ticks/retention and rearm only
  affected due keys.
- Measure existing persisted slow-warning cardinality; retain errors/actionable
  events and bound noisy successful-path persistence without adding telemetry.

Acceptance:

- Deployment/predeploy/start/health tests cover supported migration states;
  unchanged presentation makes zero Telegram calls.
- Scheduler startup/list has no unchanged writes, due work cannot be missed,
  and a tick does not refresh unrelated families.
- Log tests preserve redaction/errors while proving any sampling is bounded and
  creates no new recurring aggregate/write path.
- No always-on process, new job, heartbeat, recurring log or higher service
  resource is introduced.

### Slice P-14 — index and Neon query-plan verification

Scope:

- Capture `EXPLAIN (ANALYZE, BUFFERS)` on sanitized production-like
  distributions after request/read-model work; accept only plan-proven indexes.
- Update Prisma schema and migration together; manually verify the deployed URL
  is the intended Neon pooled endpoint without exposing it.

Acceptance:

- Every index cites predicate/order and before/after plan; duplicates and write
  amplification are assessed.
- Prisma generation/validation, affected tests/build/typecheck pass; Neon
  scale-to-zero/minimum compute and Railway tier/service count do not change.

### Slice P-15 — cohesive decomposition and final integration

Scope:

- Decompose in characterized runtime-risk order: Ad Sales use cases/UI,
  dashboard/collections, campaigns, managed Posts/pages, Channel pages and the
  MTProto facade last; split UI primitives by cohesive family behind a barrel.
- Lower/remove every touched shrinking-only ceiling; never normalize growth.

Acceptance:

- New files satisfy limits, touched god files shrink, pages trend below 300
  lines, imports stay within product boundaries and no cycle appears.
- Parnas final and Knuth count checks pass; Turing finds no contract/workspace/
  idempotency regression.
- Relevant typecheck, lint delta, tests/builds, architecture and manual QA are
  recorded with honest pre-existing failures.

## 2026-08-28 Frontend, Read-Model, and Final Performance Closure

This continuation completed the cross-stack P0 route work identified by the
final Knuth audit. The exact 269-path working-tree scope is recorded in
`docs/refactoring/PERFORMANCE_FINAL_MANIFEST_2026-08-28.md`; it includes earlier
program changes already present in the dirty working tree.

### Closed route and cache findings

| Surface                            | Before                                                                                                                                | Final contract/evidence                                                                                                                                                                                                                                                                       |
| ---------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Ad Sales quote preview             | `C × D` serialized HTTP calls in the original flow; the first batch revision accepted only 200 rows and ran pricing SQL once per date | One ordered POST for up to 10,000 placements; 9,300-row UI fixture makes one HTTP call; current/future/no-date rows share one pricing-source call; exact historical work is capped at 31 cutoffs; zero snapshot writes; stale requests abort and a same-key failure has one bounded retry.    |
| Ad Sales sales search              | Browser filtered only the current 25-row page                                                                                         | Workspace-scoped server predicate is shared by `findMany` and `count`; page/search are in the query key, old requests receive an AbortSignal, and a page-two regression is covered.                                                                                                           |
| Ad Sales analytics scope           | Selected channel IDs were silently sliced to six                                                                                      | One shared six-channel contract drives the selector and backend; the selector blocks a seventh and direct API/service callers receive an explicit 400 before workspace or analytics reads.                                                                                                    |
| Managed-post collection cache      | Visible pages stored `PaginatedResponse`, while mutations/deep links/due refresh read or wrote a phantom raw-array prefix             | Separate list/detail key families and one paginated reconciliation helper update every cached page containing the entity; create narrowly invalidates lists; reorder snapshots/rollback use real pages; due refresh also checks/refetches exact deep-link detail and stops on terminal state. |
| Managed import/deletion validation | Only page 1 / 100 posts was inspected                                                                                                 | One workspace/channel-scoped lookup accepts at most 1,000 IDs and returns request-ordered compact 10-field summaries plus missing IDs. It uses channel + one post read + at most one icon read, with zero Telegram/MTProto/writes.                                                            |
| Managed post groups                | Route and modals followed every 100-row page serially                                                                                 | One read-only channel summary request returns at most 1,000 compact groups; `take=1001` fails explicitly above the bound, status counts are aggregated without per-post arrays, and the path performs no ensure/normalize/DDL writes.                                                         |
| Campaigns / hypotheses / promos    | Active route and hypothesis form used generic serial load-all helpers                                                                 | Active view makes one 50-row server page request; server owns search/date/sort/count; hidden datasets stay disabled; campaign options paginate while retaining selected IDs; rich edit/preview and off-page promo deep links use detail endpoints. Obsolete load-all wrappers were removed.   |
| Finance categories                 | Browser downloaded every transaction page (`P`, up to 100 HTTP requests for 1,000 rows)                                               | One category-statistics aggregate request after authorization; no transaction-page chain.                                                                                                                                                                                                     |
| Workspace switch                   | Workspace-scoped React Query data could survive the selected-workspace transition                                                     | Registered workspace-scoped query families are cleared on switch before the next workspace renders.                                                                                                                                                                                           |

### Read models and payloads

- Ad Sales collections use `TelegramAdSaleListItem`; payment histories, full
  advertiser detail and rich managed-post bodies remain detail-only while the
  compact placement/payment/member/icon and remote-status presentation stays
  in the row, avoiding client N+1 joins.
- Availability carries existing-placement summaries instead of bootstrapping
  the first 100 sale details for the calendar.
- Campaign, hypothesis and promo list readers use explicit compact selects;
  forms and previews hydrate their separate detail contracts.
- Managed lookup excludes text, media, buttons, planner state, relations,
  revisions and Telegram engagement rows. Its shared request/item/response
  contract and limits live in `packages/shared`.
- Finance category statistics and latest currency rates have purpose-built
  aggregate/latest contracts rather than client-side all-history reduction.

### Structural closure

No threshold or exception was raised. Normal architecture passes across 906
production TS/TSX files. Transitional baselines fell from 28 to 23 during the
program; the final slice additionally lowered Channels `3314 → 3059`, Campaigns
page `2482 → 2464`, Ad Sales page `1016 → 1004`, API facade `763 → 760`, and
Hypotheses service `905 → 903`. Earlier cohesive reductions remain: Posts page
`8564 → 7973`, Ad Sales service `7543 → 5723`, channel detail `4170 → 3867`,
MTProto facade `3603 → 3433`, primitives `2194 → 1747`, Ad Sale modal
`1343 → 555`, and sale details `1174 → 704`. New production helpers top out at
494 lines; no new production file exceeds 500.

Strict architecture intentionally remains red on the 23 exact inherited
transitional owners (seven backend services, nine App Router pages, six
frontend components, and the API facade). This is visible shrinking-only debt,
not a widened allowance.

### Verification

| Gate                     | Result                                                                                                                                                                               |
| ------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| API tests                | pass: 228 suites, 1,375 tests                                                                                                                                                        |
| Web tests                | pass: 129 files, 576 tests                                                                                                                                                           |
| Root TypeScript          | pass for shared, API, and web                                                                                                                                                        |
| Production build         | pass; 31 web pages generated                                                                                                                                                         |
| Shared typecheck/build   | pass                                                                                                                                                                                 |
| Prisma generate/validate | pass; existing required-field `SetNull` warning remains                                                                                                                              |
| Deployment contract      | pass: 11 tests and Railway artifact check                                                                                                                                            |
| Normal architecture      | pass: 16/16 policy tests, 906 production files                                                                                                                                       |
| Strict architecture      | expected fail: 23 inherited exact-baseline owners                                                                                                                                    |
| `git diff --check`       | pass                                                                                                                                                                                 |
| Full lint                | inherited red: API 6,112 errors / 581 warnings; web 164 errors / 254 warnings; shared passes. New focused helpers pass targeted lint; no false repository-wide lint pass is claimed. |

### Explicit P1/P2 backlog

- P-07: all-time Ad Sales placement/inventory/alert output still needs a
  synchronized aggregate/paginated contract; silently capping it would change
  correct totals.
- P-11/P-13: established Finance category reads are write-free, but first-use
  default provisioning and remaining runtime schema compatibility/startup DDL
  still need setup/migration ownership.
- P-12: daily analytics still performs 100 bounded but sequential channel sync
  calls at 100 channels; MTProto still creates several clients during a full
  channel sync; Ad lifecycle/deletion compact outcomes remain follow-up.
- Hypothesis summaries still hydrate nested linked-campaign inputs needed by
  the current calculation. Replacing them requires a purpose-built aggregate
  equivalence contract, not a payload-only deletion.
- Greeter owner-token/audience cursor semantics and System Bot cross-process
  exactly-once remain the documented correctness backlog; no heartbeat or new
  service was introduced to disguise them.
- P-14 production-like `EXPLAIN (ANALYZE, BUFFERS)`, deployed pooled-Neon URL,
  scale-to-zero/minimum compute, payload-byte capture, and browser latency remain
  manual production verification. No percentage latency claim is made.

### Neon/Railway cost gate

The final tree adds no worker, Railway service, polling loop, heartbeat,
keep-warm request, recurring precomputation, persistent cache, telemetry writer,
schema migration, retention increase, higher resource floor, or scale-to-zero
change. Optimized paths perform equal or fewer HTTP/DB calls and writes; all
100-channel/10,000-quote/1,000-ID behaviors above have explicit bounds.

## 2026-09-08 Consumer Finance Analytics and Billing Consolidation

This slice completes the Consumer Finance UI continuation without reopening the
internal Finance boundary.

- The single `/analytics` read model now owns FREE totals, expense and income
  category breakdowns, account breakdowns, timeline, calendar-aware comparison,
  deterministic trends, and explicit current/previous legacy-currency quality
  disclosures. The former duplicate Ultimate deterministic screens and reads
  were removed; old `screen=ultimate` links resolve to Analytics.
- Ultimate adds one explicit, server-authorized AI action over compact aggregate
  facts. It uses the existing encrypted provider configuration, structured
  Responses output, `store: false`, a 20-second timeout, atomic monthly usage
  reservation, priced usage recording, and no response persistence, timer,
  polling, background job, or precomputation. Analytics interpretation and
  credential resolution were extracted into focused services, reducing the
  touched Finance AI provider from 569 to 492 lines. Reservations persist the
  workspace, bot, runtime, user and profile dimensions consumed by the existing
  operator AI usage/cost view.
- `finance-product-definition.ts` is the production source for the exact Free,
  Pro and Ultimate capabilities, limits and UAH monthly prices. The consumer
  billing facade returns this definition plus authoritative subscription and
  provider state, server-owned purchase eligibility, and owns Finance catalog
  synchronization. Checkout independently rejects same-tier purchases,
  downgrades, recoverable past-due subscriptions, and overlapping paid-plan
  checkout against the current entitlement/provider state; provider-safe
  replacement/proration remains a separate future flow. The generic billing
  engine no longer contains Finance prices.
- Consumer billing endpoints were extracted from the broad Finance controller.
  Transaction rows render the shared resolved account/category icons, including
  image-backed icons, and locale-owned date/notification accessibility copy no
  longer falls back to hard-coded English.

### Runtime-cost assessment

- Base analytics performs five fixed, parallel, bounded aggregates regardless
  of account count; the 100-account regression asserts the same five statements
  and capped category/account/legacy result sets. Dashboard keeps its separate
  one-aggregate read model and does not hydrate comparison or timeline data.
- Current presentation-rate preparation now reads only the latest persisted row
  per directed workspace currency pair instead of loading full exchange-rate
  history. Existing composite uniqueness supports the workspace/pair/date access
  pattern; a new speculative index was not added without production-like
  `EXPLAIN (ANALYZE, BUFFERS)` evidence.
- AI is never called by the FREE analytics read or on page load. The only AI
  request follows an explicit Ultimate mutation. No unchanged-state write,
  recurring work, retention change, Neon keep-awake behavior, or Railway
  CPU/RAM/network baseline was added.

### Verification

- Root typecheck, shared/API/web builds, focused API/web lint, i18n parity,
  Prisma generation, and all targeted Consumer Finance suites pass.
- Full API: 339/343 suites and 1,844/1,851 tests pass; the four remaining suites
  are existing CRM, managed-post metadata, and stale mutual-promotion fixture
  failures outside this slice.
- Full web: 209/210 files and 895/896 tests pass; the remaining failure is the
  existing Ad Sales publication-timing test outside Consumer Finance.
- Architecture policy tests pass. The normal gate remains red only on seven
  existing shrinking-baseline overruns in MTProto, Growth campaigns, Telegram
  Channels/account panels, and shared UI primitives; no Consumer Finance
  violation or allowance was added. `git diff --check` passes.

## 2026-09-08 Consumer Finance Savings Goals and Universal Investments

This slice replaces the former singular editable goal with product-owned
Savings Goals and adds generic manual Investments without crossing into the
internal Finance product.

- Savings Goals use append-only allocation, release, and reallocation events.
  Account transfers remain real transfers; goal allocation is metadata over
  cash already held in accounts and therefore contributes zero additional net
  worth. The read model reports allocated, backed, underfunded, and legacy
  unlinked amounts explicitly. Completed goals retain release/reallocation and
  history; archive requires zero linked allocation, while legacy-only metadata
  remains historical and does not strand the goal.
- Investments support business, real estate, securities, crypto, digital and
  physical assets, and other manually valued assets without a ticker or market
  data engine. Contributions and returns are first-class, account-authoritative
  movements with a dedicated transaction purpose, immutable reporting/base
  snapshots, ownership checks, atomic projection updates, and idempotency.
- Valuations and corrections are append-only. Current value is the latest
  effective valuation, profit/loss is `current value + returned - invested`,
  and percentage return is absent when invested capital is zero. Closing can
  atomically record an optional return, a zero valuation, and closed status.
- Account allocation, account archive, transfer linking, valuation, cash-flow,
  close, complete, and archive races use shared advisory/optimistic locks and
  locked ownership/status rechecks. UI retries preserve the original
  idempotency key; a duplicate close reconstructs its original return,
  transaction, account, and valuation result.
- Active investments without a manual current valuation are disclosed as
  excluded instead of being reported as known zero-value losses. Corrected
  valuations remain in history but superseded points are omitted from the
  effective trend.
- Analytics and the bounded dashboard distinguish ordinary income, ordinary
  expenses, saved, invested, investment returns, cash, investments, and net
  worth. Ordinary category/limit paths exclude investment-purpose movements.
- Shared contracts, Prisma schema/migration, API DTO/controllers/services,
  export/privacy deletion, generated-transaction guards, product-owned query
  keys/cache reconciliation, responsive Web/Mini UI, and Ukrainian/Russian/
  English copy were updated together. Lists and histories use bounded cursor
  pagination with explicit load-more and error states.

### Runtime-cost assessment

- Idle cost is zero: no polling, timer, cron, market API, background valuation,
  persistent cache, or unchanged-state write was introduced. Neon remains able
  to sleep, and Railway receives no new continuous CPU/RAM/network baseline.
- At 100 goals or investments, normal reads remain cursor-bounded and dashboard
  work remains a fixed compact request. Storage grows only from explicit user
  actions: one savings event, one transaction plus cash-flow row, or one manual
  valuation row. Full history export remains an explicit user-triggered linear
  portability operation.

### Verification

- Prisma generate/validate, root typecheck, i18n parity, focused lint, and the
  shared/API/web production build pass. Prisma validate retains the repository's
  pre-existing required-field `SetNull` warning.
- All 47 Consumer Finance API suites pass (240 tests), and the broader 39-file
  Consumer Finance web slice passes (198 tests). Full API passes 352/356
  suites and 1,880/1,887 tests; the four remaining suites are existing CRM,
  Growth mutual-promotion, and Telegram Channels failures outside this slice.
- Full web passes 214/215 files and 920/921 tests; the remaining failure is the
  existing Ad Sales publication-lifecycle timing test outside Consumer Finance.
- Architecture policy tests pass 16/16. The normal file-size gate remains red
  only on the same seven unrelated shrinking-baseline overruns; no Consumer
  Finance allowance or cross-product import was added. `git diff --check`
  passes.

## 2026-09-08 Consumer Finance Fintech Shell and State System

- Consumer Finance navigation now uses one product-owned destination map for
  Web and Mini App, grouped by summary, money, planning, and service intent.
  Active destinations retain `aria-current` and use transform-only motion with
  a reduced-motion fallback.
- The browser shell keeps branding and Telegram identity outside the scrolling
  navigation, presents the active section identity in the sticky header, and
  moves the synchronized locale control to the top-right. Language choices are
  flag-only visually while retaining localized accessible names.
- Transfers now treat two non-archived accounts as a real prerequisite. With
  fewer accounts, only localized guidance and one direct account-creation action
  are rendered; transfer history is not requested until the prerequisite is
  satisfied.
- The shared Consumer Finance feedback layer now uses compact context-aware
  ledger, flow, planning, and growth visuals. Empty and error states do not loop;
  continuous motion is limited to active navigation and genuine ongoing states.
- The existing session profile and settings update contracts already provide
  Telegram identity and persist locale changes through the bot presentation
  path, so no parallel API, schema, or cross-product abstraction was added.

### Runtime-cost assessment

- Navigation, avatar, locale placement, and CSS motion add no polling, timers,
  storage, external calls, or idle Railway/Neon work.
- The ineligible transfer screen removes its history HTTP request and associated
  bounded database reads. At 100 such opens this avoids roughly 100 HTTP calls
  and about 200 database reads while keeping the existing accounts read.

## 2026-09-08 Ads and Workspace Navigation Consolidation

- Growth exposes one Ads destination. Campaigns and mutual-promotion folders
  are selected through accessible page tabs, while the legacy mutual-promotion
  URL redirects to the consolidated workspace.
- Ads and Telegram Channels share one route-tab persistence hook. Explicit URL
  state wins, valid last-used state is restored, unrelated query parameters are
  preserved, and invalid stored values fall back safely.
- The mixed Operations navigation group was removed. Workspace Settings now
  owns permission-aware links to Roles & access, Scheduled tasks, and Trash;
  the System Logs UI route was removed while backend operational logging stays
  available to the platform.
- Application log retention is 30 days. The existing daily, non-editable
  system-maintenance task performs the bounded cleanup, so records expire after
  about one month without introducing another scheduler or polling loop.

### Runtime-cost assessment

- Route-tab persistence is browser-local and adds no HTTP calls, database work,
  timers, or polling. Hidden Ads sections remain unmounted, so only the active
  section issues queries.
- Log cleanup keeps the existing one due-driven daily execution: approximately
  30 cleanup queries per month deployment-wide, not per workspace or channel.
  At 100 channels the schedule and query count are unchanged; shorter retention
  reduces stored rows and index size. No new Railway process, CPU loop, memory
  baseline, external request, or network egress was added.

## 2026-10-28 Finance FREE + PLUS billing foundation

- The independent Finance host now has additive billing tables, a single
  four-offer catalog, Finance-only Stripe ENV, explicit `billing:sync`, signed
  mode-scoped webhooks, a Finance Mini App session, and a FREE/PLUS billing
  screen. Legacy PRO/ULTIMATE source rows and Stripe Price identities remain
  intact. A checksummed backup and dry-run importer prepare preservation of
  existing paid/gift rights without cross-database SQL.
- This is a staged foundation, not a production cutover. The old hosted
  consumer Finance surface still exposes PRO/ULTIMATE and Telegram Stars;
  browser-only login does not yet issue a standalone Finance session. TEST
  Stripe, 7 UAH minimum acceptance, old-subscription webhook routing, and a
  staging database import must be verified before switching new sales.
- Local Finance API tests/typecheck/build and Finance Web tests/typecheck/build
  pass. The repository architecture checker and full web lints still fail on
  pre-existing violations outside this billing slice. See
  `docs/finance-bot/BILLING_ROLLOUT.md` for cutover and rollback steps.

### Runtime-cost assessment

- Billing adds no poll, cron, startup Stripe call, or idle database query. A
  billing-screen open performs bounded subscription/history reads and a
  payment aggregation for active candidates. Checkout and webhooks perform
  event-driven DB/Stripe work; catalog sync runs only by explicit CLI command.
- At 100 Telegram channels, idle billing work remains zero because billing
  scales with paying users and events, not channel count. Payment facts and
  webhook IDs are append-only audit data; UI history is bounded to 30 rows.
  The Finance API uses its existing process, so there is no new Railway
  process or persistent connection baseline from this feature.

## 2026-10-31 CRM Notifications & PWA Web Push

- Restored live incoming CRM intents through the existing transactional batch writer and after-commit Operations publisher. Incoming alerts require explicit opt-in; existing global Web Push preferences and due-driven follow-up scheduling remain intact.
- Added exact account/conversation grouping, monotonic read reconciliation, bounded cooldown/fanout, current privacy/permission/subscription checks at network-ready dispatch and shared current follow-up occurrence validation. No new Telegram runtime, worker, polling or presence writes.
- Existing Settings now exposes EN/RU CRM flags, device status and an explicit throttled test. The Service Worker safely restores conversation/workspace destinations through authentication; notification SSE patches bounded caches without full Inbox refetch.
- Grace/Knuth/Parnas preflight and Parnas/Turing final integration review completed. The queued stale-privacy finding was fixed with fresh readiness cohorts before provider calls. Normal architecture remains16/16 policy tests with20 existing source violations; strict mode reports26 existing violations. Thresholds/allowances were unchanged.
- Delivery, cost bounds, deployment migration, test evidence, physical-device QA and rollback: [CRM notification plan](../plans/crm-notifications-pwa.md) and [QA](../qa/crm-notifications/README.md). Migration was not applied and no production-device push was sent.

## 2026-10-31 CRM Sales Workflow, Follow-up & Package Sales

- Added explicit nullable client-owned manual sales decisions while deriving reply/waiting/due attention from existing facts. Operational conversation state and contact classification remain distinct. DNC survives merges and is enforced against the current conversation immediately before manual sending; compact timestamps are monotonic under incoming/outgoing races.
- Inbox actions reuse canonical advertiser tasks, current-owner authorization, effective occurrence ordering and existing due/notification delivery. No-op/repeated commands avoid writes; changed occurrences dismiss obsolete published reminders. Purchase history uses a lazy linked-sale cursor and currency-safe aggregates; package context reads existing products/networks/constraints without materialization or repricing.
- CRM owns the sales controls and adapters; Shared Chat UI remains neutral. Native-dialog overlay portal behavior is corrected in the shared UI layer for mobile controls. Mutation/realtime caches reconcile exact affected entities rather than refetching the entire Inbox.
- Grace/Knuth/Parnas preflight and Turing integration review were performed; queued DNC, follow-up independent read/edit scopes, exact-origin retention and overdue INTERESTED/HUMAN_REVIEW filter cases were corrected. Final structural/check evidence and concurrent outside-slice failures are recorded in the QA handoff; checker thresholds/allowances were unchanged.
- Plan, contracts, operation budgets, migration prerequisites, rollback and acceptance steps: [CRM sales workflow](../plans/crm-sales-workflow.md). No production migration, real commercial message or AI request was executed.

## 2026-10-31 Internal AI infrastructure and usage

- Added one internal Operations AI gateway, immutable Decimal tariff/configuration snapshots, workspace/category reservations, bounded idempotency and explicit reconciliation. Consumer Finance AI implementation/accounting remains independent.
- Added compact daily usage read models, bounded cursor history, role-scoped AI Usage settings/dashboard and lazy CRM Sales cost summary. No producer, HTTP execution endpoint, new worker, polling or deployment was added.
- Grace/Knuth/Parnas preflight and Turing final read-only review completed. Late UNKNOWN reconciliation, all-age hold discovery, exact UTC accounting, configuration bounds and cache isolation were verified. Policy16/16; normal23/strict28 pre-existing source violations unchanged; thresholds untouched.
- Operational cost, migration/rollback and QA evidence: [plan](../plans/ai-infrastructure-usage.md), [QA](../qa/ai-infrastructure/README.md). Migration not applied; all provider calls mocked. Existing API five TypeScript errors remain outside scope.

## 2026-10-31 AI Sales Copilot

- Added four manually requested CRM use cases through the existing Operations gateway, bounded selected-source context, seven-day CRM draft claims/results and human approval bound to text/revision/current facts. No Discovery, outreach automation or Support implementation was added.
- Reused the existing composer, canonical browser drafts, manual Telegram sender/idempotency and shared mobile details surface. AI provenance, canonical keys, fresh authorization/DNC/price/source-grant checks and retained-receipt replay protect explicit sends; ordinary manual chat remains independent of AI availability.
- Grace/Knuth/Parnas preflight and Turing final review completed. Review fixes cover verified source scope, financial assertion aliases/spelled/free claims, pre-call permissions, uncertain persistence, repeated-approval no-ops, TTL receipt replay, cancellation and keyboard composer priority. Policy16/16; normal23/strict28 source violations unchanged, with no allowance edits.
- [Plan](../plans/ai-sales-copilot.md) and [QA](../qa/ai-sales-copilot/README.md) record actual source-level costs, synthetic evaluation, blocked production rollout and migration/rollback. No migration, paid benchmark or commercial send was executed; five existing API build errors remain outside scope.

## 2026-11-01 Telegram Lead Discovery

- Added a distinct Growth CRM source registry, one-copy evidence pipeline and human candidate queue; existing TelegramAdvertiser, Operations AI Gateway, Scheduled Tasks and live MTProto handle remain canonical. The shared contract was fixed before backend/frontend implementation.
- Grace/Knuth/Parnas preflight and Turing integration review covered source access/grants, workspace isolation, bounded cost, stale edits/deletes/RPC origins, UNKNOWN paid attempts, coverage proof, strong identities and DNC. Discovery creates no artificial conversation, outbound message, join, second runtime or idle polling.
- Cohesive neutral extractions reduce the MTProto adapter and runtime. Shared Select accessibility was fixed once and tested in affected consumers; the primitives legacy ceiling was lowered from1,737 to1,505 without raising thresholds. Policy16/16; normal22 inherited violations versus23 baseline, strict28.
- [Implementation/rollout/costs](../plans/telegram-lead-discovery.md) and [QA](../qa/telegram-lead-discovery/README.md) record the feature-off default, reviewed deployment grants, bounded retention capacity, unchanged five API build errors and staging prerequisites. No production migration, real collection or paid call was executed.

## 2026-11-01 AI Lead Qualification and Candidate Preparation

- Extended Discovery with an independent qualification dimension and derived review workflow, strict grounded AI output, versioned explainable scores, cited risk signals and separate human risk decisions. Existing rejection, CRM ownership/status and DNC remain independent.
- Candidate drafts use minimal candidate-specific records while preserving required conversation FKs. Common Copilot provenance/pricing guards and Operations Gateway remain canonical; explicit candidate approval enables freshness-checked Copy, never a fake conversation/send.
- Grace preflight, Parnas/Knuth source-level cost/structure audit, separate backend/frontend writes and Turing read-only review covered paid claims, UNKNOWN, current identity/source/product facts, human-decision revocation and actual Gateway business-object limits. No new polling/runtime/worker/service was added. Policy16/16; normal22/strict28 inherited violations, no raised allowance.
- [Plan and costs](../plans/ai-lead-qualification.md), [QA and staging benchmark](../qa/ai-lead-qualification/README.md) document known collection/uncertainty limits, optional notifications extension, additive migration/rollback and existing five API build errors. No real provider/channel/DB migration or release was executed.

## 2026-11-01 Instagram contacts and manual CRM workflow

- Extended canonical advertiser contact identity with typed Instagram syntax, preserved raw values, separate human ownership/state and compact manual dates. Existing activity/task records own manual reports and peerless reminders; no second client/message store, transport, poll or worker was introduced.
- Explicit Clients/manual workflow and AI Lead attribution reuse current approval, source/DNC and own/any checks. Removed an existing contact-on-mount mutation and unsafe raw contact link behavior. Shared Chat UI remains transport-neutral.
- Grace preflight, Parnas/Knuth structural/cost preflight, separate backend/frontend files and Turing read-only integration checks covered all typed write paths, strong identity, legacy promotion, request receipts, merge, reminder privacy and manual-only status. Cohesive legacy Contact CRUD extraction shrank the Sales facade; no threshold/allowance was raised.
- [Plan](../plans/crm-instagram-contacts.md) and [QA](../qa/crm-instagram-contacts/README.md) record actual gates/debt, official Meta adapter research,365-day bounded audit retention, staged enum/schema migration and compatible rollback. No production migration, Instagram login/message or paid AI call was executed.

### Prompt №10 — shared chat actions (2026-11-01)

Extended the existing CRM MTProto handle and neutral Shared Chat UI for real reply/edit/delete/reaction/forward and bounded lazy media/voice. Reused canonical messages, account runtime, notifications, rich editor and drafts; added compact operation receipts/deletion identities and unread snapshot ordering. No Bot Support runtime, second client/store, polling or media blobs in PostgreSQL. Grace exploration and Parnas/Knuth source/cost check preceded integration; Turing read-only final review cleared known P1/P2 after regressions. Rollout defaults disabled, migration unapplied, global baseline build/architecture failures retained. [Plan](../plans/telegram-chat-actions.md), [QA](../qa/telegram-chat-actions/README.md).


### 2026-11-01 — AI Sales CRM final integration (Prompt 11)

Completed read-only runtime/cost/structure mapping, bounded integration fixes and independent integration review. Current authorization is refreshed for manual sends, locked contact merge and bounded SSE batches; private CRM reads bypass server response caching, unresolved AI records survive retention, and workspace AI query cleanup and UNKNOWN send behavior are covered. Original five API typing blockers and CRM fixture drift were fixed. Vitest now owns product web tests only; all 75 excluded backend suites remain owned by API Jest.

Release decision remains **NO-GO**: focused API138 suites/1083 tests and web55 files/409 tests pass, but full API has13 failing suites/23 tests and web19 failing files/29 tests. Disposable PostgreSQL forward migration has zero drift; genuine clean bootstrap fails at a historical missing-Workspace precondition. Last-account lease cleanup, supported Node LTS alignment, live staging/device/provider checks and measured capacity remain acceptance work. No production migration/deploy or paid/live outreach was executed. See [release readiness](../plans/ai-sales-crm-release-readiness.md) and [QA/checklist](../qa/ai-sales-crm-final/README.md).

## 2026-11-01 CRM runtime ownership and history repair

- Grace/Knuth runtime and cost analysis traced the reported conflict to localhost versus the production lease owner and an outdated deployed history contract. Preserve exclusive cloud ownership and relay local CRM HTTP/SSE through one trusted origin before body parsing.
- Separate backend/frontend changes repair raw-ID history pagination, stale exhaustion, automatic bounded recent sync, immediate older-page display, legacy media enrichment and post-commit cache invalidation. No new idle polling or second runtime.
- Turing final review found no blocking issue; final structural rerun retains the same22 unrelated failures with zero new violations. API/web builds and typechecks pass; full API has23 unrelated existing test failures. [Operational QA and costs](../qa/ai-sales-crm-final/runtime-history-fix.md) records live rollout evidence and limits.

## 2026-11-01 Compact working CRM and one-click AI

- Grace traced the actual failed operation to an invalid token-count payload, disabled chat-action rollout and unconfigured source registry. Knuth/Parnas bounded catalog/feedback/usage/source costs before backend/frontend assignments.
- Added server-owned one-click suggestion context, corrected provider contract, bounded scoped feedback and unresolved-operation fencing. Simplified Copilot, editor control, sidebar and Discovery; Usage is always visible and includes all workspace AI categories. No new persistence model or polling.
- Turing reviewed authorization/freshness, exact source metadata grants, pricing/provenance, UNKNOWN recovery and constant-query catalog limits. Targeted gates/builds pass; existing full-suite/lint/architecture debt remains. [QA, costs and live acceptance](../qa/ai-sales-crm-final/compact-crm-fix.md).

## 2026-11-01 Telegram CRM folder rail

- Mapped the prior account-specific contact-tag limitation and introduced workspace/account-isolated conversation membership, complete server unread aggregates and a compact folder rail with a global Unread filter.
- Folder membership uses existing Telegram runtime and event-driven reconciliation. Reads carry the actually visible message watermark; hidden tabs, unfocused windows, older-history views and modal overlays do not automatically mark messages read.
- A disposable PostgreSQL migration and aggregate fixture verifies account/workspace isolation, overlap, unlinked chats and cascade. [QA and runtime costs](../qa/ai-sales-crm-final/telegram-folders.md) records limits, rollout and manual checks.

## 2026-11-01 Lead Discovery autopilot — in progress

- Grace, Knuth and Parnas mapped the actual leased Telegram transport, event monitor, manual-only AI admission, source grants and repository size/cost baseline. Autonomous AI must use existing AUTOMATIC budget gates and unknown-receipt fencing.
- Added a conservative standalone prefilter, reciprocal-evidence checks and an offline aggregate benchmark; neither is integrated into a running automatic pipeline. The supplied 2,700-post text export lacks source metadata and independent human labels. Quality and production rollout remain **NOT VERIFIED / NO-GO**. See [plan](../plans/lead-discovery-autopilot.md) and [QA](../qa/lead-discovery-autopilot/README.md).

## 2026-11-03 Site-wide loading performance — in progress

- Telegram Channel detail now defers Recharts and the audience/MTProto chart components into a separate chunk; campaign currency settings/rates wait until Campaign Attribution is open and has campaigns, and preview/settings/icon modals are dynamically loaded. Added normalization regressions for available, malformed and stored graph data (3/3 pass). Web typecheck and production build pass. The route-level lint still reports legacy diagnostics. No additional polling or refresh loop was added.
- Telegram Network detail no longer fetches the full channel selector catalog during read-only viewing; the catalog query is enabled only while the edit form is open, and the form modal is a lazy chunk. Extracted the presentation/table section so its route file now fits the sub-300-line page target (217 lines). The edit response now reconciles the detail cache directly while the list is refreshed, preventing an immediate duplicate detail read. A route regression covers lazy catalog loading, cache reconciliation and no repeat detail request (1/1 pass); focused ESLint and Web typecheck pass.
- Telegram Posts now lazy-loads the text editor (including its editor-only dependencies), post preview, content-hypotheses workspace, custom-emoji pack dialog and post-history dialog. The two closed dialogs are no longer mounted before their actions are invoked. Calendar/groups/hypotheses route entrypoints therefore defer editor-only code. Focused history/calendar tests pass (3), Web typecheck and production build pass; route ESLint reports legacy findings (14 errors/28 warnings, no diagnostics on the new imports), and the wrapper's focused ESLint passes. Authenticated browser transfer comparison remains unavailable.
- Full Web Vitest run: 372 test files / 1,925 tests passed; 22 files / 45 tests failed. Failures include unrelated legacy Finance account UI and Lead review/router test setup diagnostics in the captured output; this does not replace the focused passing regressions for the current Network and Telegram Posts slices. The full suite is not green and requires a separate failure-by-failure baseline cleanup before it can serve as a global gate.
- Architecture policy unit tests pass (16/16). The whole architecture check remains red on existing unrelated file growth, hard-limit violations and configuration-boundary debt; no allowances were raised. Lowered the Network detail page's stale shrinking-only ceiling to 221 lines after extracting its presentation.
- Internal Finance now requests workspace currency settings only when the Account editor opens. The four editor workflows are conditionally mounted and code-split; untouched account forms adopt the loaded currency preference while preserving edits. Extracting a small editor host reduced the overview file from 818 to 776 lines. Focused modal tests pass (3), Web typecheck and production build pass. The full Web lint still reports 141 errors/166 warnings across the existing codebase; focused lint for the changed Finance files reports three existing React Hook Form incompatibility warnings and no errors. Full architecture check remains blocked by unrelated baseline growth and over-limit files; lowered two stale shrinking-only ceilings for files that have already shrunk in this workstream. No polling or repeated reads were added.
- Telegram Bots' compact persisted configured-bot overview now remains fresh for 15 minutes instead of the four-minute default; profile updates reconcile the cache directly and an explicit refresh remains available for upstream Telegram changes. Its action dialogs are now a separate lazy chunk, and the runtime-delete chooser is loaded only after selecting deletion. Scheduled Tasks also imports and mounts its 271-line edit/history dialogs only after opening the respective action. The dialog/cache-policy regressions pass (46 tests across focused suites), Web typecheck/build and focused lint pass. In the adjacent bot-card suite, 8/9 tests pass; one existing avatar URL assertion fails. No polling or extra runtime reads were added.
- Telegram Channels now code-splits the account panel, export modal, message-template modal and network emoji picker; those chunks are requested only when their tab/action opens. Removed an unused `TelegramTextEditor` import from the route. Web typecheck and production build pass, and the account-panel suite passes (7 tests). The unrelated message-template component suite currently has 5 pre-existing UI/provider assertion failures; page ESLint remains red on existing `any`, React Hook Form compiler and set-state-in-effect findings. `git diff --check` passes; authenticated transfer-size comparison remains pending.
- The app-wide Notification Center still fetches its unread count and opens its realtime stream on mount, but the 272-line panel is now a conditional dynamic import and Push Settings are a second dynamic import mounted only after the Push action. Added a regression proving list rows stay idle until the panel opens and settings stay unmounted until requested. All 9 Notification Center tests, Web typecheck, focused ESLint, production Web build and diff check pass; real browser transfer/timing capture remains pending.
- The persistent AppShell now dynamically imports its 1,100-line `IconPicker`, which is rendered only in the create-workspace form. This removes the picker and its emoji/image-selection dependencies from the shell's initial static import graph; it loads when that form is opened. Web typecheck, focused ESLint and production build pass. The production chunk graph contains a dedicated lazy server chunk for the picker; no authenticated-browser transfer-size comparison is available yet.
- Workspace Settings now dynamically imports its `IconPicker` as well; permission-gated workspace controls begin loading that chunk only after the account access read grants workspace-management access. This removes the picker from the Settings route's static import graph for members without that permission. Web typecheck and production build pass; focused lint has no new finding, but the combined lint run includes the Account component's existing set-state-in-effect error and image-element warning.
- AI Usage now defers the configuration panel until the Configuration tab is selected; usage-only viewers no longer download the settings editor in the initial page chunk. The AI infrastructure suite passes (15 tests), Web typecheck, focused ESLint and production build pass.
- Added a calendar-focused composite index on ad placements `(workspaceId, telegramChannelId, scheduledAt)` to match the workspace/channel/range scan used by the Publication Calendar. The existing service regression now asserts those exact filters; Prisma generation/validation, API typecheck and all 11 calendar service tests pass. The index adds write maintenance on placement updates, and its on-database query-plan effect still needs staging EXPLAIN/browser timing; migration has not been applied.
- App-wide shell reads (`/workspaces` and compact `/account/shell`) now share a 24-hour stale window and persisted workspace cache, preventing route-to-route and browser-restart revalidation storms. Workspace create/switch/delete and profile/workspace settings explicitly invalidate the affected shell reads. No polling or recurring work was introduced; a cold session still performs the two initial reads.
- The full Telegram Posts archive query (`all: true`) stays in React Query's in-memory cache for in-session tab changes but is no longer written into synchronous localStorage persistence; bounded/paginated managed-post lists remain eligible. This avoids repeatedly serializing an unbounded post archive with every persisted-cache update. A policy regression test covers full vs paged query keys.
- Publication Calendar VP lookup filters `CrossPromotionPlan.publisherChannelIds` with PostgreSQL array overlap (`hasSome`) while the column had no supporting index. Added a GIN index for that array, preserving the bounded workspace/status query and per-publisher-date filtering; only index-maintenance work occurs when publisher-channel arrays change. Calendar service regression tests still verify deliveries can differ from the plan anchor and assert the indexed filter contract. Prisma generation, API typecheck/build, 10 calendar-service tests and diff check pass; no database EXPLAIN or authenticated browser timing is available yet.
- Re-ran both affected API read suites together after Prisma generation: calendar plus network list, 23/23 tests pass. The full API suite completed with 533 passed, 25 failed across 13 suites and 16 skipped; observed failures are outside the two changed read suites. An isolated localhost calendar tab confirms the route redirects to sign-in without an authenticated workspace, so browser timings remain unverified.
- Publication Calendar now reuses its workspace/range persisted query for five minutes, refreshes stale data quietly, avoids showing another range's rows, indexes events once per response, and invalidates the calendar root after ad/VP mutations. Provider regression coverage now asserts that the exact range key is persisted and workspace-scoped; calendar, query policy and ad invalidation suites pass (54 tests), and the production web build passes. The browser screenshot supplied for the task showed the calendar API at 2.59s and route RSC at 4.49s/2.11s; a fresh isolated localhost tab redirects to sign-in and has no authenticated workspace, so an after-capture remains pending.
- Telegram Posts loads the full posts list only on the Posts view. Ad Campaigns no longer requests its unused campaign performance summary. The page allowance was reduced to match the smaller orchestration hook.
- Added `/account/shell` as a compact read model for the persistent sidebar instead of downloading full `/account/me` data on every shell load. It retains the selected-workspace member avatar fallback. Account settings and CRM continue using the full read model. Locale changes patch the compact cache; profile changes invalidate it.
- The persisted Dashboard summary cache is now cleared on workspace switches (it was persisted but missing from the workspace-scoped set). Finance transaction, transfer, account, and category mutations invalidate every cached Dashboard period. The invalidation helper and query-provider coverage pass.
- Workspace Members no longer fetches role catalogs and Telegram account catalogs during initial page load; those queries start only when a member editor opens, and assignment changes invalidate the account catalog. CRM reuses the compact shell identity/member ID instead of requesting full `/account/me` for the current member ID.
- Ad Sales calendar availability can now hydrate from workspace-scoped persisted cache for ranges up to45 days and at most30 channels. Larger results stay in memory. It remains fresh for2 minutes; existing sale/post-link mutations invalidate the availability root. The cache policy, workspace isolation and all14 ad-sales invalidation tests pass.
- Direct Mutual Promotion now defers channel and network catalogs until its plan editor is opened; channel options also load when the Promo editor opens. Its component test confirms both catalogs stay idle on initial list load and fetch when needed. File lint still reports an existing `set-state-in-effect` error in the deep-link effect at line83; the new query change introduces no lint diagnostics.
- Mutual Promotion Folders card editing now uses `fetchQuery` with the same workspace-scoped detail key as its detail modal. React Query deduplicates the observer and edit request; regression tests confirm one API read on success and preserve the visible error state on failure. Focused folder-page tests, web typecheck, lint and diff checks pass.
- CRM Lead Discovery source and review-queue lists now honor their existing 60-second query freshness instead of forcing a network refetch on every remount. Explicit refresh and mutation flows already invalidate the workspace-scoped result roots. Reconciled tests with the paginated source table and candidate detail loading contract; Lead Discovery/history/qualification/review suites pass (47 tests).
- Ad Sale saved drafts use a 60-second cache while the checkout dialog is open; create/update/delete still explicitly reread the draft list after the mutation. No idle request is made while the dialog is closed.
- Currency settings now stay fresh for one day and latest exchange rates for15 minutes across all consumers. Saving workspace currency preferences already invalidates both query roots, so the longer settings cache cannot hide those edits. The shared read policy has focused coverage.
- Removed per-component five-minute overrides so Calendar and Ad Sales now share those cross-site currency cache defaults. Ad Sales calendar readiness is derived from the preferences query instead of a follow-up state update, avoiding one extra render while still preventing a transient default-range availability request. Currency policy, calendar preference hydration, and availability invalidation tests pass; touched-file lint, web typecheck, and diff check pass.
- Notification Center now reuses its last list response for30 seconds when reopened. The existing realtime invalidation, closed-panel cache removal, and stream-reconnect reconciliation still force fresh reads when needed; a component regression test covers cache reuse and explicit invalidation. Audit of the calendar waterfall confirms the unread badge is a single workspace-scoped in-memory query; notification SSE coalesces bursts, reconciles on reconnect and stops while hidden, while the larger notification list loads only with the panel open. Center/stream tests pass (14 tests), so the observed unread reads correspond to realtime invalidation/reconnect rather than every route visit.
- Shared Telegram channel selectors now reuse their compact workspace-scoped results for15 minutes across editors and tabs. Channel lifecycle/import/update flows invalidate the selector family; focused query-policy and Telegram invalidation tests pass.
- The follow-up mutation audit found list/detail invalidators that did not yet cover the longer-lived selector family. Channel settings, sync/access refresh, QR login reconciliation, and channel refresh now invalidate selectors too; regression coverage asserts this.
- Mutual Promotion Folder invite-link availability now respects its existing30-second stale window on editor reopen instead of overriding it with an unconditional refetch. The register-link flow retains its explicit post-mutation refetch.
- Telegram Network collection responses now omit detailed per-channel financial summaries that only network detail screens consume. Independent financial-summary preparation and audience-trend reads start concurrently; traffic attribution still waits for trend results. The API regression coverage confirms the compact list/detail response boundary and verifies the reads overlap. The network screenshot's 2,833 kB/5.64 s response is the baseline; an authenticated after-capture is still pending.
- Focused calendar/post/campaign coverage and web typecheck passed in earlier slices. Compact shell API/web tests, API build, web typecheck and `git diff --check` passed. Authenticated runtime comparison remains unavailable because localhost opens the login page and the active Chrome production tab contains an in-progress import; that tab was left untouched. This is an incremental first set of hot paths, not a completed site-wide pass.
- Publication schedule occurrence generation now creates one timezone-aware `Intl.DateTimeFormat` per request instead of rebuilding it for every date/slot. Existing DST regression and full publication-schedule service tests pass (10/10); API typecheck passes. This removes repeated formatter setup while keeping date conversion and recurrence semantics unchanged.
- Publication schedule lists now share a persisted 24-hour cache across the Calendar, channel settings and schedule editor. Schedule create/update/delete already patch or invalidate that query family; assigning a schedule to a channel now invalidates the family too, which also refreshes the Calendar after assignments. Query policy tests pass (36), and the channel schedule-save test passes. The channel-settings file has a separate existing failure in its configuration-percentage assertion (`67%`); it reproduces when run alone and is unrelated to this cache change. Web typecheck, touched-file lint and diff checks pass.
- The calendar's VP placement mapper now uses a `Set` for allowed channel membership instead of scanning the channel ID array for every nested publisher placement. This keeps filtering linear in placement count for the supported 100-channel batch size; the regression fixture also proves placements from outside the requested channels remain excluded. Publication-schedule service tests pass (10/10), API typecheck passes.
- Ran an isolated Playwright browser check against the local Next dev server with a synthetic workspace and intercepted API responses. The cold Calendar route requested the schedule list and calendar once each; after navigating away and back through a full page reload, persisted React Query served both with zero schedule/calendar API calls. This verifies browser persistence and warm navigation only; API interception means it is not a backend latency benchmark. Real authenticated before/after timings are still pending.
- Closed a cache invalidation gap created by the long-lived Network list cache: server-confirmed channel patches, import/delete/archive/restore/test-state changes, channel settings saves, access refreshes and channel-derived summary changes now invalidate `networkKeys.list()`. Optimistic channel patches defer Network invalidation until the server confirms success, so a background fetch cannot overwrite an in-flight optimistic state. Channel cache/invalidation and auto-sync tests pass (15); the channel-settings schedule-save test passes; web typecheck and `git diff --check` pass. Touched-file lint passes except the auto-sync component/test, which already contain explicit `any` lint errors at existing lines and remain outside this slice.
- Completed the long-lived Network cache audit for direct Appearance and Economics saves: both now refresh channel card summaries and Network cards after server success. Network/channel cache helper suites pass (9/9); Appearance and auto-sync component suites pass (14/14); the existing schedule-save case passes. Web typecheck and `git diff --check` pass. Focused lint reports no errors; the Appearance file retains one existing React hook dependency warning. Prettier was applied to touched cache helpers.
- Removed two stale-time overrides that made Ad Sales and Ad Campaigns refetch the large Network collection every minute despite the shared persisted 24-hour policy. Both now use `networkKeys.list()` and rely on existing network/channel mutation invalidation. Network cache defaults and the Ad Campaigns lazy-catalog test pass (37/37); web typecheck, Prettier and diff checks pass. ESLint still reports 30 errors and 11 warnings across the pre-existing large Ad Campaigns/Ad Sales files (mostly explicit `any` and existing effect warnings); no focused diagnostics were added by the network-key edits.
- Ad Sales now keeps compact paginated sale rows fresh for five minutes in the in-session query cache (previously two), while its calendar availability remains at the shorter two-minute freshness. Sale writes continue to reconcile or invalidate list pages, and due-publication lifecycle reads remain active on the Sales tab. Ad Sales cache reconciliation, Sales tab, and status-action suites pass (22/22); web typecheck, Prettier and diff checks pass. A real server timing comparison remains unavailable without an authenticated local workspace.
- The full web suite was rerun after the cache-policy changes: 361/387 files pass, 26 fail; 1,882/1,933 tests pass, 51 fail, plus one unhandled `next/navigation` mock error. The targeted cache, campaign, Sales tab and status-action suites remain green (59 tests across the two focused runs). The full-suite failures span unrelated navigation, Finance, calendar-editor, channel-settings, CRM and campaign tests; they are retained as repository-wide verification debt, not attributed to the cache edits.
- Removed five local 60-second overrides from shared Telegram channel-selector queries in the Calendar event editor, Mutual Promotion folders, Cross-Promotion editor, Ad Sales channel hook and CRM contact deals. These now consistently use the existing 15-minute selector cache; channel creation/import/settings/access/lifecycle paths invalidate the selector family. Query-policy, selector-hook, calendar-editor, campaign-plan and folder-page suites pass (45 tests); web typecheck and diff checks pass. The query-policy regression now asserts the 15-minute default for both general and `owned: true` selector variants.
- Finance Overview's account-option catalog now asks for100 rows per page (the API maximum) before collecting additional pages. This preserves the complete account filter/form choices while reducing the serial request count from one per10 accounts to one per100 on ordinary workspaces; larger catalogs still collect every page. A Finance API regression test asserts the bounded page-size contract; finance modal/account-group tests pass (6 total), web typecheck and ESLint on the changed API/test pass, and `git diff --check` passes. The legacy Finance API file has unrelated existing Prettier differences, so it was not wholesale reformatted.
- Re-audited the full-suite Lead Discovery source-table failure: its test expected cursor page 2 to have loaded before any navigation, contradicting the server-paginated view. The test now verifies one source request on first render, fetches page 2 only after Next, and filters the active cursor page; the focused suite passes (2/2). Running all Lead Discovery UI tests still finds unrelated test setup failures in ToastProvider and Next App Router mocks (19 failures across4 files), so these remain explicit suite debt.
- Extended that pagination regression to navigate away from cursor page 2 and back; the page is served from the 60-second React Query cache with the source API still called only twice total. The focused source-table suite passes (2/2).
- Telegram Posts now keeps the full managed-post archive fresh for 15 minutes in React Query's in-memory cache. The full archive remains excluded from synchronous localStorage persistence due to unbounded metadata size; managed-post mutations invalidate the channel list family. This reduces repeat archive reads during ordinary tab navigation while preserving mutation freshness. Focused post-cache checks pass (39 tests), as do Publication Calendar UI/API checks (11 tests), the calendar event editor/query-policy checks (38 tests), web typecheck and `git diff --check`. The calendar editor now uses the app-wide four-minute default for cross-promotion plans and account selectors instead of 30/60-second overrides; successful plan edits still invalidate the plans query. Authenticated browser timing still requires a local signed-in session.
- CRM Inbox cursor lists now remain fresh for five minutes in memory; the authenticated realtime stream still reconciles active lists on connect/reconnect and pushes list changes, and Inbox content remains excluded from persisted localStorage. A regression test seeds a two-minute-old list and confirms it renders without a page request. CRM Inbox + realtime tests pass (22), web typecheck and `git diff --check` pass. While running the route suite, fixed a stale AI Leads expectation and missing Next `usePathname` mock so the existing behavior test now exercises the current UI without an unhandled test error.
- Telegram channel detail now keeps its high-cost range analytics, audience and financial-summary reads fresh for 15 minutes in memory, so revisiting a channel in the same app session can reuse them immediately. Post manual-metric corrections now invalidate that channel's posts, analytics, audience, financial summary and snapshots together; a focused regression proves another channel's analytics remain untouched. Channel-query invalidation tests pass (5), web typecheck and `git diff --check` pass. ESLint reports no diagnostics in the changed invalidation helper/test; the pre-existing 3,500-line channel-detail page still reports 45 explicit-any errors and 23 warnings, with no lint-clean baseline for that file.
- Dashboard's cost-heavy exact-period summary now stays fresh in memory for 15 minutes; financial, campaign, sales and channel-sync mutation paths invalidate the dashboard root. Persisted storage now admits only a valid month-sized default period, excluding all-time/custom historical breakdowns so arbitrary ranges do not accumulate in synchronous localStorage. A component regression seeds a ten-minute-old current-month response and confirms Dashboard renders it without another API call. Provider policy, Dashboard UI, channel invalidation and finance dashboard invalidation tests pass (48), and web typecheck plus `git diff --check` pass. Focused ESLint has no errors; it reports one pre-existing unused `ChevronDown` warning in the dashboard component. An old Dashboard test that expected an expandable expense row was corrected to match the current summary-only UI. Dashboard backend reads already run concurrently; this slice reduces repeat requests and bounds cache serialization without adding polling or background work.
- Trash remains excluded from persisted local storage because its rows contain sensitive deleted finance data. Its paginated pages stay fresh in the in-memory React Query cache for five minutes, so returning to the screen reuses a recent response. API list now filters by the existing 90-day retention boundary in SQL, reads only the first `page * pageSize` ordered rows from each of its eight source tables, and obtains exact aggregate counts in parallel before globally merging/slicing. Added profile/deletion timestamp indexes for Finance Bot category, transaction and transfer rows; internal Finance tables already had workspace/deletion indexes. Regressions cover cache reuse, bounded per-type reads and exact merged pagination. Focused web and API tests pass, web/API typecheck and API build pass, Prisma validation/generation pass, focused ESLint and `git diff --check` pass. Migration was authored but not applied to a database; no production runtime jobs or polling were added.
- `pnpm architecture:check` policy tests pass (16/16), but the full architecture gate exits nonzero on existing repository debt and allowance drift in unrelated files; the output also reports changes elsewhere in this shared worktree. This Trash slice adds no production file-size or boundary violation.
- Publication Calendar cold loads previously waited for the schedule list to return a default ID before requesting calendar events. The calendar query now starts in parallel with the list using an omitted `scheduleId`; the API resolves the same default (explicit default first, then highest assignment count, then oldest creation) and returns its ID with the calendar. Explicit plan selections keep the existing path. API default-plan/slot and client request regressions pass (11 API service tests, 5 API client tests, 8 calendar utility tests); API/Web typechecks pass. This removes one client request waterfall by code path, though authenticated browser timing has not yet been measured. Focused ESLint remains red on pre-existing `no-unsafe-*` and Prettier diagnostics in the legacy 900-line schedule service/spec; the web touched files lint clean. No recurring work or polling was added; the extra default-plan DB read is parallel to the already-required schedule list request and reads only one plan with its slots/assignments.
- AppShell's System Bot workspace selection now deduplicates across route-level AppShell remounts in the current browser tab. Actual workspace changes remain serialized and applied in order; failures can retry after a later remount/change, and focus-based bot reconciliation is unchanged. A hook regression proves a second route mount with the same workspace makes no extra request. All 6 workspace-sync hook tests pass, Web typecheck, focused ESLint and diff check pass. This removes a redundant mutation request on each navigation without adding persistence, polling, or background work.
- Added a Publication Calendar component integration regression that deliberately leaves the schedules-list promise unresolved and confirms the calendar API request is issued first with no schedule ID. The request-order test passes, as do Web typecheck, focused ESLint and diff check; this proves the client no longer waits on the schedule-list HTTP roundtrip before starting event loading (server-side latency still needs a signed-in runtime benchmark).
- Internal Finance Overview previously fetched expense and income categories independently even though the existing API supports an unfiltered collection. It now makes one combined request and filters locally for the category panel, retaining the same cache root and mutation invalidations. This also avoids duplicate concurrent `ensureSystemCategories` work in the API service. Its full account catalog is now deferred until the user opens the account filter or an account-bearing transaction/transfer editor; the paginated first-page accounts still render immediately and the full selection list is reused from the existing workspace-scoped query cache. Tests verify the combined API call and that the filter triggers catalog loading; focused tests, Web typecheck, ESLint and diff check pass. Existing pagination and category editing behavior is unchanged.
- Ad Sales no longer requests `/auth/me` on the Sales/Clients tabs when timezone data is unused. The workspace-timezone read remains enabled for Calendar, an open Ad Sale editor, or selected sale details. Its 5-minute cache remains intact. A decision regression covers both inactive tabs and all three required surfaces; the Ad Sales query suite passes (15 tests), Web typecheck and ESLint for the page/query helper pass. No extra API request or background work was introduced.
- Telegram Bots now persists only the compact environment-managed bot overview under its workspace-scoped query family. The full bot catalog and paginated Finance user details remain out of persisted storage. This lets the page render cached metrics immediately after browser restart while the existing four-minute stale policy revalidates; policy regression, 37 query-provider tests, Web typecheck and focused ESLint pass.
- Bounded Publication Calendar persistence to exact calendar ranges no longer than 45 days and within 45 days of today; plan lists/assignments remain eligible, while slot-availability reads (including up to 100 channels × 62 days) stay in memory only. Recent calendar ranges still hydrate instantly across browser restarts. Regression coverage verifies recent, distant, oversized, and multi-channel key policies; query-provider suite passes (38), Web typecheck, focused ESLint, Prettier and diff check pass.
- Telegram Posts channel-calendar persistence now uses the same bounded recent-range rule. The current month-sized planner view can hydrate after a browser restart, while old/future navigation ranges no longer accumulate in persistent storage; in-session cache behavior and its 30-second freshness are unchanged. Query-policy regressions cover recent vs distant channel calendars.
- Telegram Posts mutations now invalidate both single-channel and multi-channel publication-slot availability along with the channel post calendar (save/schedule/publish, planner actions, imports, batch post imports, Telegram linking, resets, deletions, and due-state reconciliation). Shared ad-slot selectors reuse availability for 60 seconds instead of 30; own writes invalidate active readers immediately through the exact occurrence-key families. Four focused suites pass (27 tests), Web typecheck and focused ESLint pass. A broader lint run across legacy components still fails on pre-existing React Compiler/hooks diagnostics. No polling or recurring work was added; active invalidation can trigger one batched availability read per mounted selector (up to the API's existing 100-channel ceiling), and idle screens issue none.
- CRM paginated contact lists now share a two-minute in-memory freshness window instead of a component-local 30-second window. Contact create/edit/tag/task/sale/account-sync and realtime paths invalidate the contact-list family; the data remains excluded from localStorage because it contains PII. Query-policy, CRM cache, contact-card and workflow suites pass (58 tests), Web typecheck and focused ESLint pass. No added streams or polling.
- Operations Notification settings now reuse workspace-scoped preferences and push configuration for four minutes instead of one. Preference writes reconcile the canonical cached value immediately, and workspace keys isolate results; a regression seeds two-minute-old settings and verifies reopening performs no API reads. The settings suite passes (24 tests), as do Web typecheck, focused ESLint and `git diff --check`. No polling or background work was added.
- The shared `resolveWorkspaceIdForUser` path now selects only `workspaceId` instead of hydrating role permissions, member avatar and full workspace display data for callers that need only the tenant key. Selected-workspace authorization, repeated-header handling, oldest-membership fallback and RequestContext behavior are unchanged. Five focused regressions pass; Calendar service tests pass (11), API build/typecheck and focused lint pass. Full API suite is 535 passed, 25 failed, 16 skipped; failures reproduce in unrelated existing Telegram/System Bot, Finance and identity suites. This is a source-level payload/query-shape reduction used across workspace-scoped API reads; no authenticated DB timing or EXPLAIN is available, so latency impact remains unmeasured.
- Telegram Channels' Accounts → People catalog now stays fresh in the shared query cache for 15 minutes instead of four, benefiting both the People tab and Ad Campaigns' person selector. The catalog is already persisted and workspace-scoped; its local import/delete mutation paths invalidate the shared key. Query-policy coverage verifies its stale window, persistence and workspace isolation; 42 provider tests, Web typecheck, focused ESLint and `git diff --check` pass.
- Telegram Channels' MTProto/Bot account cards no longer request each source's full channel-access list just to render a count. The query starts when “Channel access” opens; cached results are reused on subsequent opens and existing source-channel invalidation remains connected to sync/import/delete mutations. Regression coverage verifies zero requests on initial card render and one request on open (7 account panel tests pass). The access-list UI was extracted from the 960-line account panel; the panel is now 622 lines and its stale architecture allowance was removed. Web typecheck, focused ESLint and `git diff --check` pass. `pnpm architecture:check` remains blocked by existing unrelated baseline growth and >800-line files elsewhere in the dirty workspace.
- Workspace Roles no longer fetch the member selector catalog on page load. It loads only when “Assign members” opens, reuses the existing workspace-members cache, and preserves the existing invalidation after assignment. The picker now displays loading, empty and retryable error states. Lazy-load and retry regressions pass; Web typecheck, focused ESLint and `git diff --check` pass. One other assertion in the existing roles workspace suite still fails because it expects a removed `lucide-send` icon in the role editor; it is unrelated to the query change.
- Personal Account settings now fetch the workspace Telegram account catalog only while the Profile tab is using the connected-account identity mode. Username-only profiles and the Password tab skip the catalog request; existing assigned accounts still trigger it when needed, and profile edits retain explicit catalog invalidation. The account workspace suite passes (6 tests) and Web typecheck plus `git diff --check` pass. Focused ESLint reports only the pre-existing set-state-in-effect diagnostic and img-element warning in this component; the lazy query adds no lint finding. No polling or background work was added.
- The Personal Account profile now dynamically loads `IconPicker` only when its profile form is rendered. Password-only visits no longer include the large icon-selection module in their static import graph. Account-workspace tests (6), Web typecheck and production build pass; focused ESLint reports the component's pre-existing set-state-in-effect error and image-element warning, with no finding on the new dynamic import.
- VP channel-scope selectors in Publication Calendar and Cross Promotion now use a compact workspace-scoped network-options endpoint (network ID/name/icon plus channel IDs) instead of fetching full network cards with financial/audience analytics. The existing full endpoint remains for network cards. The options query uses the persisted one-day network cache, and existing `networkKeys.list()` prefix invalidations also invalidate it after network/channel mutations. The selector read is bounded to three workspace-level queries (workspace exclusions, network memberships, eligible owned channels), with no per-network/per-channel request fan-out; a 100-channel regression confirms the channel rows are fetched in one batch. API network suites pass (16), Calendar editor tests pass (2), Cross Promotion lazy-loading test passes, API client/cache policy tests pass (47), shared typecheck/build, API build, Web typecheck and production Web build pass. Focused lint reports four existing hook-rule diagnostics in the connected Cross Promotion components; they are on unchanged logic. `git diff --check` passes. Runtime payload bytes are not measurable without the authenticated workspace data.
- Final repository verification for this pass: Web production build, API build, Web typecheck, and `git diff --check` pass. Full Web run: 380/394 files pass, 1,951/1,970 tests pass; the 19 remaining failures are in Consumer Finance, navigation, legacy template/Telegram avatar, Ad Sale lifecycle, and stale Mutual Promotion UI assertions. Full API run: 537 passed, 25 failed, 16 skipped; failures remain in 13 Telegram/System Bot/Finance/identity suites. Focused Lead Discovery/History/Qualification/Review suites pass (47 tests); the Discovery/source-table pair passes (18 tests); roles lazy-loading/permission tests pass (3 tests). Full Web lint remains at 141 errors/164 warnings in the existing repository; focused lint on the added cache and Lead Discovery changes passes. Architecture check still reports unrelated legacy over-limit files and source growth elsewhere; the modified Network detail route is back within its 217-line allowance. No new polling or background jobs were added. Chrome currently has an authenticated workspace session, but the available browser automation surface does not expose it (`createBrowserTab("chrome", ...)` reports Chrome unavailable); the active tab contains ongoing ad-sales work and was left untouched. A separate authenticated calendar before/after capture is therefore still unavailable; code-level cache and request-count regressions are verified, while live latency improvement remains unmeasured.
